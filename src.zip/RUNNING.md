# 运行与部署说明（Run & Deploy）

下面说明如何在本地运行、构建，以及把项目部署到线上服务。说明基于本仓库（lexiquiz）。

**先决条件**
- 已安装 Node.js（建议 v18+）和 npm
- Git（如果从仓库拉取）

**安装依赖**
```bash
cd lexiquiz
npm install
```

**本地开发（调试）**
- 启动开发服务器：
```bash
npm run dev
```
- 打开浏览器访问：http://localhost:3000
  - 说明：`server.ts` 默认把服务监听在 3000 端口并且在开发模式下使用 Vite。

**环境变量**
- 若要启用 AI 功能，请在项目根创建 `.env` 并设置：
```
GEMINI_API_KEY=your_api_key_here
```
- 其他自定义配置也可以放在 `.env` 中。

**使用 Python 脚本直接运行**
- 项目根目录新增 `run_local.py`，它会自动启动开发服务器并打开 `http://localhost:3000`。
- 运行命令：
```bash
python run_local.py
```
- 如果你使用的是 Windows，请确保 Python 已安装，并使用以下命令：
```powershell
python run_local.py
```

**生产构建**
```bash
npm run build
```
- 构建产物会输出到 `dist/`，同时会生成 `dist/server.cjs`（用于启动 Node 服务）。

**启动已构建的服务**
```bash
npm run start
```
- 启动后默认在 http://localhost:3000 提供服务。

**清理构建产物（注意 Windows）**
- package.json 中的 `clean` 脚本使用 `rm -rf`（UNIX），在 Windows PowerShell 上不可用。
- Windows 可用替代命令：
```powershell
rd /s /q dist
if (Test-Path server.js) { del server.js }
```
- 或安装 `rimraf`：
```bash
npm install -g rimraf
rimraf dist server.js
```

**部署建议（可选目标）**
1. 推荐部署到 Render，以获得公开的公网链接。
   - 仓库中已有 `render.yaml`，Render 会自动读取并部署该服务。
   - 在 Render 控制台新建 Web Service，选择你的 GitHub 仓库。
   - 构建命令：`npm install && npm run build`
   - 启动命令：`npm run start`
   - 在 Render 环境变量中添加：
     - `GEMINI_API_KEY` = `<your_api_key>`
   - 部署成功后，Render 会自动生成一个公网 URL，例如：`https://lexiquiz-web.onrender.com`

2. 其他可选平台
   - Railway：
     - 仓库根目录创建 `railway.json`。
     - 构建命令：`npm install && npm run build`
     - 启动命令：`npm run start`
     - 在 Railway 项目设置中添加 `GEMINI_API_KEY`。
   - Heroku：
     - 仓库根目录创建 `Procfile`，内容为 `web: npm run start`。
     - Heroku 会自动检测 Node 源码并使用 `package.json`。
     - 设置 `GEMINI_API_KEY` 为 Heroku Config Var。
   - 这些平台会给你一个公开链接，例如 `https://<your-app>.onrender.com` 或 `https://<your-app>.railway.app`，任何电脑复制链接即可访问。

3. 纯前端静态部署（不推荐当前项目）
   - 如果不需要后端 API，可运行 `npm run build` 并将 `dist/` 内容托管到 Netlify、Vercel 或 GitHub Pages。
   - 但当前项目包含后端 API，因此静态部署会丢失 `/api/*` 功能。

4. Vercel / Serverless 注意
   - 本项目有一个 Node 后端（`server.ts`），直接在 Vercel Serverless 下部署可能需要改造。
   - 如果你想快速上线，Render 或 Railway 这种始终运行的 Node 服务更适合。

**Google Cloud 部署**

4. 推荐部署到 Google Cloud Run，以获得公网访问链接。
   - 使用 `Dockerfile` 构建镜像并部署到 Cloud Run。
   - 或者使用 App Engine 部署 Node.js 代码。

**Cloud Run 部署步骤**
1. 安装并登录 Google Cloud SDK：
```bash
gcloud auth login
```
2. 设置项目：
```bash
gcloud config set project YOUR_PROJECT_ID
```
3. 构建并推送镜像：
```bash
gcloud builds submit --config=cloudbuild.yaml . --substitutions=_SERVICE=lexiquiz-app,_REGION=us-central1
```
4. 设置环境变量：
```bash
gcloud run services update lexiquiz-app --region=us-central1 --platform=managed --update-env-vars GEMINI_API_KEY=YOUR_API_KEY
```
5. 获取公开 URL：
```bash
gcloud run services describe lexiquiz-app --region=us-central1 --platform=managed --format='value(status.url)'
```

**App Engine 部署步骤（备用）**
1. 初始化 App Engine：
```bash
gcloud app create --project=YOUR_PROJECT_ID --region=us-central1
```
2. 部署应用：
```bash
gcloud app deploy app.yaml --project=YOUR_PROJECT_ID
```
3. 可选设置环境变量：
```bash
gcloud app deploy app.yaml --project=YOUR_PROJECT_ID --set-env-vars GEMINI_API_KEY=YOUR_API_KEY
```

**阅读器注意**
- Cloud Run 和 App Engine 都会生成公开 URL，任何人在浏览器中复制该链接即可访问。
- 如果需要更安全的密钥管理，建议使用 Google Secret Manager 并将 `GEMINI_API_KEY` 作为 secret 注入 Cloud Run。

**调试与常见问题**
- 如果 AI 相关接口返回提示未配置 API Key，请检查 `.env` 中 `GEMINI_API_KEY` 是否正确，或确认 Cloud Run / App Engine 环境变量已设置。
- 构建或启动失败时，请先检查依赖是否安装完整（`npm install`）并查看 `npm run build` 的报错信息。

---
如果你希望我为某个托管平台（例如 Render 或 Vercel）生成具体的部署配置步骤或 CI 文件（如 `vercel.json`、`Dockerfile`、或 `render.yaml`），告诉我目标平台，我可以继续帮你生成。