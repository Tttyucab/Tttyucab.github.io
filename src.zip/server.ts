import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import fs from 'fs';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Shared Gemini client setup
  let aiClient: GoogleGenAI | null = null;
  function getAi() {
    if (!aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return null;
      }
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
    return aiClient;
  }

  // API 1: Personalized learning recommendation (Intel advice)
  app.post('/api/analyze', async (req, res) => {
    try {
      const { missedWords, missedWordsDetails, totalAttempts, correctAttempts, completedWords, currentLevel } = req.body;
      const accuracy = totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 100;
      
      const ai = getAi();
      if (!ai) {
        const offlineData = {
          generalRecommendation: "Offline Calibration Mode: Establish satellite linkage via Settings > Secrets with GEMINI_API_KEY for advanced cognitive synthesis.",
          generalRecommendationChinese: "【離線調試模式】目前未配置 GEMINI_API_KEY。請於 Settings > Secrets 中導入密鑰以激活智能化 PRTS 諮詢評估。確定性推薦：請集中攻堅當前關卡中未解密的生字缺陷，保持高強度的複盤練習，以鞏固短期記憶鏈路。",
          missedAnalysis: (missedWordsDetails || []).slice(0, 3).map((w: any) => ({
            word: w.word,
            meaning: w.meaning,
            mnemonic: `聯想記憶：[${w.word}] 連接神經脈衝，劃分音節拼讀，建立心智特徵與核心語義。`,
            sentenceTip: `例句釋義：『${w.sentenceChinese || '戰略例句'}』。關注並理解此詞在戰役段句中的具體搭配和情景用途。`
          })),
          expandWords: [
            {
              word: "STRATEGIC",
              meaning: "adj. 戰略性的、關鍵的",
              example: "The commander made a strategic decision to allocate extra energy channels.",
              translation: "指揮官做出了一個分配額外能量通道的戰略性決策。"
            },
            {
              word: "ANOMALY",
              meaning: "n. 異常、不規則",
              example: "PRTS detected a thermal anomaly in the primary containment chamber.",
              translation: "PRTS 檢測到主安全室中存在熱能異常。"
            }
          ]
        };
        return res.json({
          advice: offlineData.generalRecommendationChinese,
          adviceData: offlineData
        });
      }

      const prompt = `You are the PRTS Tactical Command AI Assistant at Rhodes Island.
Analyze the user's English vocabulary training progress with the following statistics:
- Accuracy (Combat Efficiency): ${accuracy}%
- Level attempted: ${currentLevel}
- Completed word count: ${(completedWords || []).length}
- Here is the list of detailed words the user answered incorrectly and missed:
${JSON.stringify(missedWordsDetails || [])}

Tasks:
1. Provide an encouraging yet highly technical, authoritative military operator command recommendation (generalRecommendation) in English and its highly polished Chinese translation (generalRecommendationChinese). Keep it concise (strictly under 3 sentences). Refer to them as "Doctor" or "Operator". Incorporate Rhodes Island or PRTS jargon.
2. For each missed word in missedWordsDetails, provide an analytical Chinese mnemonic memory hack (mnemonic) and context grammar/syntactic advice (sentenceTip) in Chinese to help them remember this specific word easily.
3. Suggest 2 high-frequency advanced vocabulary words (expandWords) related to the current level or military context, with their meanings, custom example sentences, and direct Chinese translations, so that the user directly expands their vocabulary.

You must return a JSON object sticking exactly to the defined schema.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              generalRecommendation: {
                type: Type.STRING,
                description: "Concise command advice in English."
              },
              generalRecommendationChinese: {
                type: Type.STRING,
                description: "Natural and authoritative Chinese translation of the generalRecommendation."
              },
              missedAnalysis: {
                type: Type.ARRAY,
                description: "Itemized analysis for missed words in Chinese.",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    word: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                    mnemonic: { type: Type.STRING, description: "Chinese memory tip, mnemonic, or association strategy." },
                    sentenceTip: { type: Type.STRING, description: "Chinese syntactic/context guide emphasizing word usage." }
                  },
                  required: ["word", "meaning", "mnemonic", "sentenceTip"]
                }
              },
              expandWords: {
                type: Type.ARRAY,
                description: "Useful related vocabulary words directly translated.",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    word: { type: Type.STRING, description: "English word in uppercase." },
                    meaning: { type: Type.STRING, description: "Chinese meaning and word part of speech." },
                    example: { type: Type.STRING, description: "An elegant example sentence." },
                    translation: { type: Type.STRING, description: "Direct Chinese translation of the example sentence." }
                  },
                  required: ["word", "meaning", "example", "translation"]
                }
              }
            },
            required: ["generalRecommendation", "generalRecommendationChinese", "missedAnalysis", "expandWords"]
          }
        }
      });

      const adviceData = JSON.parse(response.text);
      res.json({
        advice: adviceData.generalRecommendationChinese,
        adviceData: adviceData
      });
    } catch (err: any) {
      console.error('Error in /api/analyze (falling back to offline modes):', err);
      try {
        const { missedWordsDetails } = req.body;
        const offlineData = {
          generalRecommendation: "PRTS Link Congested: Temporary transmission delay of high-dimensional tactical analysis. Local backup database initialized.",
          generalRecommendationChinese: "【PRTS 鏈路擁塞 // 智學備用核心激活】因神經突觸通量超載或配額不足，已啟用本地備用算法：請集中突擊目前未完全解密的生字缺陷，維持高強度複盤，以打通深層短期記憶鍵結。",
          missedAnalysis: (missedWordsDetails || []).slice(0, 3).map((w: any) => ({
            word: w.word,
            meaning: w.meaning,
            mnemonic: `聯想記憶：[${w.word}] 連接神經脈衝，劃分音節拼讀，建立心智特徵與核心語義。`,
            sentenceTip: `例句釋義：『${w.sentenceChinese || '戰略例句'}』。關注並理解此詞在戰役段句中的具體搭配和情景用途。`
          })),
          expandWords: [
            {
              word: "STRATEGIC",
              meaning: "adj. 戰略性的、關鍵的",
              example: "The commander made a strategic decision to allocate extra energy channels.",
              translation: "指揮官做出了一個分配額外能量通道的戰略性決策。"
            },
            {
              word: "ANOMALY",
              meaning: "n. 異常、不規則",
              example: "PRTS detected a thermal anomaly in the primary containment chamber.",
              translation: "PRTS 檢測到主安全室中存在熱能異常。"
            }
          ]
        };
        res.json({
          advice: offlineData.generalRecommendationChinese,
          adviceData: offlineData
        });
      } catch (nestedErr: any) {
        res.status(500).json({ error: err.message || 'Signal transmission interrupted.' });
      }
    }
  });

  // API 4: Explains the quiz sentence and target word in profound detail
  app.post('/api/explain-sentence', async (req, res) => {
    try {
      const { sentence, targetWord, meaning, choices } = req.body;
      const ai = getAi();
      if (!ai) {
        const mockChoicesTranslation: Record<string, string> = {};
        (choices || []).forEach((c: string) => {
          mockChoicesTranslation[c] = "【離線對照釋義】：核心記憶與字根辨析。配置 API Key 可獲取精準釋義。";
        });
        return res.json({
          sentenceTranslation: `【離線仿真翻譯】本句中文含義為：這個句子可以用於評估幹員在戰地環境中的語言理解精度。`,
          grammarBreakdown: [
            { segment: targetWord, grammaticalValue: "目標核心考點單詞 (Target Word)", translation: meaning, tip: "此單詞在句中充當關鍵成分，決定了整個情報指令的意思。請務必著重記憶。" }
          ],
          synonyms: ["EXPEDITE (加速辦理)", "STABILIZE (使穩定)"],
          choicesTranslation: mockChoicesTranslation
        });
      }

      const prompt = `You are the PRTS Tactical Command AI Assistant at Rhodes Island.
Profoundly analyze and translate the following quiz sentence structure:
- Sentence: "${sentence}"
- Target word filling the gap: "${targetWord}"
- Meaning: "${meaning}"
- Distractors/options: ${JSON.stringify(choices)}

Tasks:
1. Provide the MOST DIRECT, clear, and precise Chinese translation of the complete sentence (sentenceTranslation) (要求最直接、無冗餘、語意最精準貼合的中文翻譯).
2. Deconstruct the sentence into 3 to 4 major grammatical segments or vocabulary chunks (grammarBreakdown), explaining:
   - "segment": the segment of the sentence
   - "grammaticalValue": its grammatical component (e.g., 主句、定語從句、後置修飾)
   - "translation": the MOST DIRECT, straightforward Chinese translation of this segment (core Chinese translation free of fluff)
   - "tip": MORE DETAILED AND COMPREHENSIVE APPLICATIONS (更詳細和全面的應用及考點剖析). Include real-world tactical applications, collocation patterns, register choices, and comprehensive tips.
3. Suggest 2 high-value synonyms (synonyms) from military/scientific English vocabulary that could also fit this technical context, with direct, most straightforward Chinese translations in parenthesis.
4. Translate each of the vocabulary choices/options (choicesDistractors) directly into a concise Chinese explanation (choicesTranslation as a key-value object of choice -> translation).

You must return a JSON object sticking exactly to this schema:
{
  "sentenceTranslation": "...",
  "grammarBreakdown": [
    { "segment": "...", "grammaticalValue": "...", "translation": "...", "tip": "..." }
  ],
  "synonyms": ["SYNONYM1 (翻譯1)", "SYNONYM2 (翻譯2)"],
  "choicesTranslation": {
    "CHOICE_A": "中文释义 A",
    "CHOICE_B": "中文释义 B"
  }
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              sentenceTranslation: { type: Type.STRING },
              grammarBreakdown: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    segment: { type: Type.STRING },
                    grammaticalValue: { type: Type.STRING },
                    translation: { type: Type.STRING },
                    tip: { type: Type.STRING }
                  },
                  required: ["segment", "grammaticalValue", "translation", "tip"]
                }
              },
              synonyms: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              choicesTranslation: {
                type: Type.OBJECT,
                description: "Key-value dictionary mapping each option/choice string to its direct concise Chinese meaning."
              }
            },
            required: ["sentenceTranslation", "grammarBreakdown", "synonyms", "choicesTranslation"]
          }
        }
      });

      res.json(JSON.parse(response.text));
    } catch (err: any) {
      console.error('Error in /api/explain-sentence (falling back to offline modes):', err);
      try {
        const { sentence, targetWord, meaning, choices } = req.body;
        const mockChoicesTranslation: Record<string, string> = {};
        (choices || []).forEach((c: string) => {
          mockChoicesTranslation[c] = "【離線對照釋義】：核心記憶與字群結構。配置或恢復 API Key 可獲取詳細智能解析。";
        });
        const offlineSentence = {
          sentenceTranslation: `【PRTS 線路繁忙 // 備用學思翻譯】本句中文大致含義為：這個句子在戰術情境中承載著精準操作。`,
          grammarBreakdown: [
            { 
              segment: targetWord || "TARGET_WORD", 
              grammaticalValue: "目標核心考點單詞 (Target Word)", 
              translation: meaning || "考點釋義", 
              tip: "此單詞在句中充當關鍵成分，決定了戰備情報指令的具體釋義。請務必著重記憶其拼寫和釋義。" 
            }
          ],
          synonyms: ["EXPEDITE (加速辦理)", "STABILIZE (使穩定)"],
          choicesTranslation: mockChoicesTranslation
        };
        res.json(offlineSentence);
      } catch (nestedErr: any) {
        res.status(500).json({ error: err.message || 'Linguistic analysis bypass failed.' });
      }
    }
  });

  // API 2: AI Story reconstruction using missed / selected words
  app.post('/api/reconstruct-story', async (req, res) => {
    try {
      const { missedWords } = req.body; // array of word strings e.g. ["POSTPONE", "CANCEL"]
      
      if (!missedWords || missedWords.length === 0) {
        return res.json({
          story: "No anomalies detected in the memory buffer. Story reconstruction skipped."
        });
      }

      const ai = getAi();
      if (!ai) {
        const joined = missedWords.map((w: string) => `[${w}]`).join(', ');
        return res.json({
          story: `[LOCAL_DECODING_SIMULATOR] (GEMINI_API_KEY offline) - We detected anomalies under terms: ${joined}. Operators must prioritize these sectors in the upcoming combat runs to reconstruct proper neural pathways.`
        });
      }

      const prompt = `Write a short, engaging sci-fi/military-tactical command scenario (exactly 2 to 3 sentences) that naturally uses and highlights these English vocabulary words: ${missedWords.join(', ')}.
Each word must be capitalized or wrapped in brackets e.g. [${missedWords[0]}].
The story theme must match a high-tech combat simulation or operator's log (containment fields, coolant chambers, landship engines, tactical strategies, PRTS system, drones, etc.).
IMPORTANT: You MUST also provide a natural, detailed, fluent and comprehensive Chinese translation of the entire scenario immediately following the English paragraph (separated by double newlines). Output raw text only.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
      });

      res.json({ story: response.text });
    } catch (err: any) {
      console.error('Error in /api/reconstruct-story (falling back to offline modes):', err);
      try {
        const { missedWords } = req.body;
        const joined = (missedWords || []).map((w: string) => `[${w}]`).join(', ');
        res.json({
          story: `[PRTS 數據鏈路過載 // 局部記憶整合模式]\nWe completed localized neural correlation maps for key cognitive terms: ${joined}. Continue systematic training runs to completely stabilize these sectors during deep-level learning sessions.\n\n【PRTS 備用安全日誌析出】\n已為您完成核心單詞的關聯：${joined}。請在後續的實戰及演訓中保持對這些關鍵名詞的高度关注，以建立穩固的認知突觸鏈路！`
        });
      } catch (nestedErr: any) {
        res.status(500).json({ error: err.message || 'Neural path mapping failed.' });
      }
    }
  });

  // ----------------------------------------------------
  // Dynamic Local Dictionary Fallback Engine
  // ----------------------------------------------------
  function getOfflineExplanation(wordStr: string) {
    const rawWord = wordStr.trim();
    const normalized = rawWord.toLowerCase();

    const offlineDict: Record<string, {
      word: string,
      pronunciation: string,
      chineseTranslation: string,
      englishDefinition: string,
      usages: string[],
      quiz: { question: string, options: string[], correctOption: string, explanation: string }
    }> = {
      "augment": {
        word: "AUGMENT",
        pronunciation: "/ɔːɡˈment/",
        chineseTranslation: "v. 增加，提高，擴大",
        englishDefinition: "To make something greater, larger, or more intense by adding to it.",
        usages: [
          "The tactical commander decided to augment our frontline defense with automated drone structures. (戰術指揮官決定使用自動無人機防禦結構來加強我們的陣線防禦。)",
          "Operator can use strategic training vectors to augment cognitive capability. (幹員可以使用策略訓練向量來增強認知能力。)"
        ],
        quiz: {
          question: "To prevent high-intensity neural rupture, we must ________ the cooling fluid levels immediately.",
          options: ["A. cancel", "B. separate", "C. augment", "D. decrease"],
          correctOption: "C",
          explanation: "「augment」意為『增加，提高』。上下文提到「防止高強度神經破裂」，需「增加」冷卻液量，因此選 C 正確。"
        }
      },
      "precarious": {
        word: "PRECARIOUS",
        pronunciation: "/prɪˈkeəriəs/",
        chineseTranslation: "adj. 不穩定的，危險的，未穩固的",
        englishDefinition: "Not securely held or in position; dangerously likely to fall or collapse.",
        usages: [
          "Our current high-ground deployment is set up in a precarious cliffside coordinate. (我們目前的高空部署設置在一個危險的懸崖邊坐標上。)",
          "The integrity of the reactor core remains in a precarious balance. (反應爐核心的完整性依然處於不穩定的平衡狀態。)"
        ],
        quiz: {
          question: "Because the shield generator is damaged, the defender's current posture on the narrow ridge remains extremely ________.",
          options: ["A. resilient", "B. conspicuous", "C. robust", "D. precarious"],
          correctOption: "D",
          explanation: "「precarious」意為『危險的，不穩定的』。護盾發生器受損，因此防禦者的陣勢極其「危險/不穩定」，選 D 正確。"
        }
      },
      "vulnerability": {
        word: "VULNERABILITY",
        pronunciation: "/ˌvʌlnərəˈbɪləti/",
        chineseTranslation: "n. 弱點，易受打擊性，脆弱性",
        englishDefinition: "The quality or state of being exposed to the possibility of being attacked or harmed.",
        usages: [
          "PRTS detected a functional vulnerability in the enemy's rear artillery barricade. (PRTS 在敵方後翼火砲防波堤中檢測到一個功能性弱點。)",
          "A defensive commander's prime task is to patch any systemic vulnerability. (防禦指揮官的首要任務是修補任何系統性弱點。)"
        ],
        quiz: {
          question: "The thermal shield has a minor ________ that could be exploited by dense energy projectiles.",
          options: ["A. vulnerability", "B. integrity", "C. resilience", "D. augmentation"],
          correctOption: "A",
          explanation: "「vulnerability」表示『弱點，易受損處』。防護盾有「弱點」才容易受敵火射擊利用，選 A 正確。"
        }
      },
      "integrity": {
        word: "INTEGRITY",
        pronunciation: "/ɪnˈteɡrəti/",
        chineseTranslation: "n. 完整性，完好性，誠實",
        englishDefinition: "The state of being whole, entire, or undiminished; soundness.",
        usages: [
          "Warning: Hull structural integrity is deteriorating; recommend immediate evacuation. (警告：船體結構完整性正在惡化；建議立即疏散。)",
          "The security system protects data integrity against database unauthorized insertion. (安全系統保護數據完整性，防範數據庫遭未授權插入。)"
        ],
        quiz: {
          question: "Before conducting the high-speed hyper-tunnel warp transmission, checking the structural ________ of the landship is mandatory.",
          options: ["A. vulnerability", "B. integrity", "C. posture", "D. acceleration"],
          correctOption: "B",
          explanation: "「integrity」在工程上常指『結構完整性』。在超時空跳躍傳輸前，必須檢查船艦結構的「完整性/完好」，選 B 正確。"
        }
      },
      "resilient": {
        word: "RESILIENT",
        pronunciation: "/rɪˈzɪliənt/",
        chineseTranslation: "adj. 有彈性的，能迅速恢復的，適應力強的",
        englishDefinition: "Able to withstand or recover quickly from difficult conditions.",
        usages: [
          "Rhodes Island operators are incredibly resilient, adapting quickly to any battlefield anomalies. (羅德島的幹員們適應力極強，能迅速適應任何戰場異常。)",
          "We need a resilient power grid that can absorb continuous electrical pulses. (我們需要一個適應力強/有彈性的電網，能吸收連續的電脈衝。)"
        ],
        quiz: {
          question: "Thanks to the newly developed carbon fiber coating, the tactical shield is remarkably ______ under extreme temperature shocks.",
          options: ["A. conspicuous", "B. resilient", "C. precarious", "D. redundant"],
          correctOption: "B",
          explanation: "「resilient」意為『有韌性的，能適應與迅速恢復的』。碳纖維塗層使其防護盾在溫度外傷下保持「高耐受度/韌性」，選 B 正確。"
        }
      },
      "conspicuous": {
        word: "CONSPICUOUS",
        pronunciation: "/kənˈspɪkjuəs/",
        chineseTranslation: "adj. 顯眼的，明顯的，引人注目的",
        englishDefinition: "Clearly visible or attracting attention; obvious.",
        usages: [
          "The red beacon is conspicuous even in the dense desert sandstorm. (即使在濃密的沙漠沙塵暴中，紅色信標也極其顯眼。)",
          "Avoid placing conspicuous command centers near frontline firing range. (避免在近前線射程處設置過於顯眼的指揮中心。)"
        ],
        quiz: {
          question: "His bright golden battle armor was so ________ that sniper units located his coordinates instantly.",
          options: ["A. precarious", "B. resilient", "C. conspicuous", "D. offline"],
          correctOption: "C",
          explanation: "「conspicuous」表示『顯眼的』。金色戰甲太過「顯眼」，導致狙擊手能立即鎖定其坐標，選 C 正確。"
        }
      }
    };

    if (offlineDict[normalized]) {
      return offlineDict[normalized];
    }

    // Default dynamic mock generator for any other input word
    const cleaned = rawWord.toUpperCase();
    return {
      word: cleaned,
      pronunciation: `/${normalized}-mode/`,
      chineseTranslation: `[PRTS 智能解譯] 對於 "${rawWord}" 的認知路徑正在重構。`,
      englishDefinition: `Tactical parameter definitions for vocabulary term: "${rawWord}".`,
      usages: [
        `The command telemetry has logged the tactical concept parameter: "${rawWord}". (戰術終端已登錄此戰術概念參數: "${rawWord}"。)`,
        `Operator should reinforce conceptual mastery of "${rawWord}" for upcoming simulated runs. (幹員必須針對 "${rawWord}" 加強概念掌握，以應對後續高強度演練。)`
      ],
      quiz: {
        question: `In standard operations, the proper execution of ________ sequence is fundamental to maintain circuit stability.`,
        options: [
          `A. ${cleaned} calibration`,
          "B. bypass security protocols",
          "C. override default safety valve",
          "D. disconnect reactor cooling"
        ],
        correctOption: "A",
        explanation: `選項 A「${cleaned} calibration（校正序列）」契合 PRTS 戰術模組標準安全維護指令，其他選項會造成過度耗損。`
      }
    };
  }

  // API 3: Dialogue analysis for a target English vocabulary word
  app.post('/api/explain-word', async (req, res) => {
    try {
      const { word } = req.body;
      if (!word || typeof word !== 'string' || !word.trim()) {
        return res.status(400).json({ error: 'Please provide a valid English word.' });
      }

      const rawWord = word.trim();
      const ai = getAi();
      if (!ai) {
        // Fallback gracefully to high-quality local dictionary
        const backupData = getOfflineExplanation(rawWord);
        return res.json(backupData);
      }

      const prompt = `You are the PRTS Tactical Command AI Assistant. Your task is to analyze the English word and generate a structured cognitive response:
Word to analyze: "${rawWord}"

Your explanation must be precise, professional, and highly educational.

IMPORTANT TRANSLATION RULE:
- For "chineseTranslation", you MUST provide the MOST DIRECT, clear, and straightforward core Chinese translation first (最直接、最核心難懂的中文直譯), followed by its parts of speech (e.g., "【最直接翻譯】：增強 / 擴大 (词性: v.) | 其他釋義: 增加，提高，增值"). Keep translations absolutely direct, precise, and professional, free from unnecessary fluff.

IMPORTANT APPLICATIONS RULE:
- For "usages", you MUST provide MORE DETAILED AND COMPREHENSIVE APPLICATIONS (更詳細和全面的應用及搭配場景剖析). Each usage string in the array should contain:
  1) A highly realistic English sentence illustrating the core collocation or application of the word in real-world professional contexts (e.g., system operations, technical upgrades, strategic maneuvers, academic/business context).
  2) The DIRECT, most straightforward Chinese translation of the sentence.
  3) An exhaustive, comprehensive breakdown of the application context (詳細應用場景解析) and key collocations/derivatives (詞彙常用搭配說明), showing diverse fields of application. Format this beautifully with clear spacing or bullet points within the string so users gain deep cognitive understanding.

The quiz MUST test the user's understanding of this word in a meaningful sentence context. Choose the correct option so that only it makes absolute sense in the blank.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              word: { type: Type.STRING },
              pronunciation: { type: Type.STRING, description: "Phonetic symbols of the word, e.g., /kənˈspɪkjuəs/" },
              chineseTranslation: { type: Type.STRING, description: "The most direct core Chinese translation and parts of speech, e.g., '【最直接翻譯】：顯眼的 (adj.)'" },
              englishDefinition: { type: Type.STRING, description: "Clear and concise English definition of the word." },
              usages: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Array of 2-3 highly detailed and comprehensive application breakdowns including English sentence, direct translation, and detailed context breakdown as specified in the prompt."
              },
              quiz: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING, description: "A fill-in-the-blank or definition test sentence in English. Example: 'The red warning light on the dashboard was so ______ that no one could ignore it.'" },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "4 multiple choice options. Each option must start with a letter followed by a dot, e.g., 'A. conspicuous'"
                  },
                  correctOption: { type: Type.STRING, description: "The letter of the correct option: 'A', 'B', 'C', or 'D'" },
                  explanation: { type: Type.STRING, description: "Explanation of why this choice is correct and others are incorrect, in Chinese." }
                },
                required: ["question", "options", "correctOption", "explanation"]
              }
            },
            required: ["word", "pronunciation", "chineseTranslation", "englishDefinition", "usages", "quiz"]
          }
        }
      });

      const parsedData = JSON.parse(response.text || '{}');
      res.json(parsedData);
    } catch (err: any) {
      console.error('Error in /api/explain-word, falling back to local dictionaries:', err);
      try {
        const backupData = getOfflineExplanation(req.body.word || '');
        return res.json(backupData);
      } catch (nestedErr) {
        res.status(500).json({ error: err.message || 'PRTS server core is experiencing network turbulence.' });
      }
    }
  });

  // Simple CSV parser and endpoints for local data files
  function parseCsv(text: string) {
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (lines.length === 0) return [];
    const splitLine = (ln: string) => ln.split(/,(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/);
    const headers = splitLine(lines[0]).map(h => h.trim());
    const rows: Record<string, any>[] = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = splitLine(lines[i]).map(c => {
        const v = c.trim();
        if (v.startsWith('"') && v.endsWith('"')) return v.slice(1, -1).replace(/""/g, '"');
        return v;
      });
      const obj: Record<string, any> = {};
      for (let j = 0; j < headers.length; j++) {
        const key = headers[j] || `col${j}`;
        let val = cols[j] ?? '';
        if (val && (val.startsWith('[') || val.startsWith('{'))) {
          try { val = JSON.parse(val.replace(/""/g, '"')); } catch (e) { }
        }
        if (/^\d+$/.test(val)) val = Number(val);
        obj[key] = val;
      }
      rows.push(obj);
    }
    return rows;
  }

  app.get('/api/vocabulary', (req, res) => {
    try {
      console.log('GET /api/vocabulary');
      const csvPath = path.join(__dirname, 'data', 'vocabulary.csv');
      const txt = fs.readFileSync(csvPath, 'utf8');
      const data = parseCsv(txt);
      res.json(data);
    } catch (err: any) {
      console.error('Failed to load vocabulary CSV', err);
      res.status(500).json({ error: 'Failed to load vocabulary data' });
    }
  });

  app.get('/api/sentence-structure', (req, res) => {
    try {
      console.log('GET /api/sentence-structure');
      const csvPath = path.join(__dirname, 'data', 'sentence_structure.csv');
      const txt = fs.readFileSync(csvPath, 'utf8');
      const data = parseCsv(txt);
      res.json(data);
    } catch (err: any) {
      console.error('Failed to load sentence structure CSV', err);
      res.status(500).json({ error: 'Failed to load sentence structure data' });
    }
  });

  app.get('/api/ping', (req, res) => res.json({ ok: true, time: Date.now() }));

  // Vite static assets serving & SPA fallback routers
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[V-TERMINAL] Full-stack Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
