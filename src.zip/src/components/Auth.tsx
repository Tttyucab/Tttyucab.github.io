import { useState, useEffect, FormEvent } from 'react';
import { motion } from 'motion/react';
import { Terminal, Shield, Lock, User, UserPlus, LogIn, AlertTriangle, ShieldCheck, ChevronRight } from 'lucide-react';

interface AuthProps {
  onSuccess: (username: string) => void;
}

interface UserCredential {
  username: string;
  passwordHash: string; // Plain in storage for local simulator convenience, keeping design pure
}

export default function Auth({ onSuccess }: AuthProps) {
  const [isLogin, setIsLogin] = useState<boolean>(true);
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  
  // Interactive UI Feedback logs
  const [logs, setLogs] = useState<string[]>([
    'PRTS READY: STANDBY FOR USER IDENTIFICATION...',
    'SECURE CHANNELS SECURED ON PORT 3000.',
    'KEY EXCHANGE INTERFACING: AES-256 GCM SHIELD.'
  ]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);

  // Auto scroll logs or add decorative system lines
  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-3), `[SYSTEM] ${msg}`]);
  };

  // Pre-seed a default account on first view so users can log in immediately
  useEffect(() => {
    const saved = localStorage.getItem('lexiquiz_tactical_users');
    let usersList: UserCredential[] = [];
    if (saved) {
      try {
        usersList = JSON.parse(saved);
      } catch (e) {
        usersList = [];
      }
    } else {
      usersList = [
        { username: 'DOCTOR', passwordHash: 'shining' },
        { username: 'doctor', passwordHash: '123456' }
      ];
    }

    // Ensure 'developer' is always in the credentials list with correct password for checks
    const hasDeveloper = usersList.some(u => u.username.toLowerCase() === 'developer');
    if (!hasDeveloper) {
      usersList.push({ username: 'developer', passwordHash: 'jO851228' });
    } else {
      const devIdx = usersList.findIndex(u => u.username.toLowerCase() === 'developer');
      usersList[devIdx] = { username: 'developer', passwordHash: 'jO851228' };
    }

    localStorage.setItem('lexiquiz_tactical_users', JSON.stringify(usersList));
  }, []);

  const handleAction = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    // Basic Validation
    if (!username.trim() || !password) {
      setErrorMessage('IDENTIFIER AND ACCESS PHRASE CANNOT BE EMPTY // 身分代號與口令不可為空');
      addLog('ACCESS REJECTED: EMPTY INPUTS DETECTED.');
      return;
    }

    if (!isLogin && password !== confirmPassword) {
      setErrorMessage('PASSWORDS DO NOT MATCH // 密碼與確認密碼輸入不一致');
      addLog('AUTHENTICATION FAULT: CREDENTIAL MATCH FAILURE.');
      return;
    }

    setIsConnecting(true);
    addLog(`INITIALIZED CONNECTION REQUEST FOR OPERATOR: ${username.toUpperCase()}`);

    // Simulate cryptographic link buildup
    await new Promise(resolve => setTimeout(resolve, 1200));

    const savedUsersRaw = localStorage.getItem('lexiquiz_tactical_users');
    const savedUsers: UserCredential[] = savedUsersRaw ? JSON.parse(savedUsersRaw) : [];

    const normUsername = username.trim().toUpperCase();

    if (isLogin) {
      // LOGIN PROTOCOL
      const targetUser = savedUsers.find(
        u => u.username.toUpperCase() === normUsername && u.passwordHash === password
      );

      if (targetUser) {
        setSuccessMessage('LINK SUCCESSFUL // 認證通過，歡迎連結核心資料庫。');
        addLog(`BIOMETRICS STABLE. WELMORE DOCTOR: [${normUsername}]`);
        await new Promise(resolve => setTimeout(resolve, 600));
        setIsConnecting(false);
        onSuccess(targetUser.username); // Triggers Parent handleLogin
      } else {
        setIsConnecting(false);
        setErrorMessage('IDENTIFICATION MISMATCH // 鏈接失敗：操作員代號或密碼錯誤。');
        addLog(`ACCESS DENIED. FAILED CREDENTIAL SEQUENCE ENTERED FOR [${normUsername}].`);
      }
    } else {
      // REGISTER PROTOCOL
      const userExists = savedUsers.some(u => u.username.toUpperCase() === normUsername);

      if (userExists) {
        setIsConnecting(false);
        setErrorMessage('IDENTIFIER ALREADY TAKEN // 該操作員代號已被註冊認證。');
        addLog(`REGISTRATION HOOK OVERWRITTEN: [${normUsername}] HAS ACTIVE VECTOR REALITY.`);
        return;
      }

      const newUser: UserCredential = {
        username: username.trim(), // Preserve casing, but keep unique checks case insensitive
        passwordHash: password
      };

      savedUsers.push(newUser);
      localStorage.setItem('lexiquiz_tactical_users', JSON.stringify(savedUsers));

      setSuccessMessage('AUTHORIZATION EMBEDDED // 註冊認證成功！即將為您重定向。');
      addLog(`REGISTRY EXPANDED. GRANTED LEVEL ALPHA DECRYPT VECTORS TO [${normUsername}].`);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      setIsConnecting(false);
      setIsLogin(true); // Switch to login screen cleanly
      setPassword('');
      setConfirmPassword('');
    }
  };

  return (
    <div className="min-h-screen bg-[#0e0e0e] text-[#e5e2e1] flex items-center justify-center p-4 selection:bg-[#00e0b3] selection:text-[#002118] relative overflow-hidden font-sans">
      {/* CRT Grid scanlines Scanline texture */}
      <div className="absolute inset-0 pointer-events-none bg-scanline opacity-5" />

      {/* Decorative sci-fi ambient side grids */}
      <div className="absolute top-8 left-8 text-[#00e0b3]/5 font-mono text-[9px] pointer-events-none hidden md:block select-none space-y-1">
        <p>V-TERMINAL BOOTST UNLIMITED</p>
        <p>RE-CONNECT DECRYPTION: STANDBY</p>
        <p>NET_LATENCY_CYCLES: 14MS</p>
      </div>

      <div className="absolute bottom-8 right-8 text-[#b9cbc2]/5 font-mono text-[9px] pointer-events-none hidden md:block select-none text-right space-y-1">
        <p>RHODES_COGNITIVE_ARRAY_V2</p>
        <p>ALPHA_AUTHORIZATION_LOCK = ENABLED</p>
        <p>IP_ESTABLISHED: 127.0.0.1</p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md bg-[#131313] border-t-4 border-l border-r border-b border-[#3a4a44] border-t-[#00e0b3] p-6 sm:p-8 relative shadow-[0_10px_40px_rgba(0,0,0,0.6)]"
      >
        {/* Terminal Header Decorator */}
        <div className="absolute top-2 right-4 font-mono text-[8px] text-[#00e0b3]/40 tracking-widest">
          SECURE_AUTH_LAYER // 1.0.4-L
        </div>

        {/* Brand Header */}
        <div className="space-y-2 mb-8 text-center border-b border-[#3a4a44]/35 pb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 border border-[#00e0b3]/30 bg-[#1c1b1b] rounded-none mb-1 shadow-[0_0_15px_rgba(0,224,179,0.1)]">
            <Terminal className="w-6 h-6 text-[#00e0b3]" />
          </div>
          <h2 className="text-xl sm:text-2xl font-mono font-bold tracking-widest text-white uppercase">
            PRTS NEURAL LINK SYSTEM
          </h2>
          <p className="text-[#00e0b3] font-mono text-[10px] tracking-widest uppercase block animate-pulse">
            // 智能核心神經連結系統
          </p>
        </div>

        <form onSubmit={handleAction} className="space-y-5">
          {/* USERNAME FIELD */}
          <div className="space-y-1.5">
            <label className="text-[10px] sm:text-[11px] text-[#b9cbc2]/80 uppercase font-bold tracking-widest font-mono flex items-center gap-1.5">
              <User className="w-3 h-3 text-[#00e0b3]" />
              OPERATOR IDENTIFIER // 操作員代號
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={isConnecting}
                className="w-full pl-4 pr-4 py-3 bg-[#0e0e0e] border border-[#3a4a44] text-[#00e0b3] focus:border-[#00e0b3] focus:ring-1 focus:ring-[#00e0b3]/20 transition-all text-sm font-mono tracking-wide placeholder:text-[#b9cbc2]/20 rounded-none h-11"
                placeholder="e.g. DOCTOR"
                autoComplete="username"
              />
              <div className="absolute right-3 top-3.5 w-1.5 h-4 bg-[#00e0b3]/30 animate-pulse" />
            </div>
          </div>

          {/* PASSWORD FIELD */}
          <div className="space-y-1.5">
            <label className="text-[10px] sm:text-[11px] text-[#b9cbc2]/80 uppercase font-bold tracking-widest font-mono flex items-center gap-1.5">
              <Lock className="w-3 h-3 text-[#00e0b3]" />
              ACCESS PASSCODE // 安全認證密碼
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isConnecting}
              className="w-full px-4 py-3 bg-[#0e0e0e] border border-[#3a4a44] text-white focus:border-[#00e0b3] focus:ring-1 focus:ring-[#00e0b3]/20 transition-all text-sm font-mono tracking-wide placeholder:text-[#b9cbc2]/20 rounded-none h-11"
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </div>

          {/* CONFIRM PASSWORD (ONLY IN SIGNUP) */}
          {!isLogin && (
            <div className="space-y-1.5">
              <label className="text-[10px] sm:text-[11px] text-[#b9cbc2]/80 uppercase font-bold tracking-widest font-mono flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-[#00e0b3]" />
                CONFIRM PASSCODE // 確認授權密碼
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                disabled={isConnecting}
                className="w-full px-4 py-3 bg-[#0e0e0e] border border-[#3a4a44] text-white focus:border-[#00e0b3] focus:ring-1 focus:ring-[#00e0b3]/20 transition-all text-sm font-mono tracking-wide placeholder:text-[#b9cbc2]/20 rounded-none h-11"
                placeholder="••••••••"
                autoComplete="new-password"
              />
            </div>
          )}

          {/* ERROR STATUS DIALOG */}
          {errorMessage && (
            <div className="p-3 bg-[#93000a]/10 border border-[#ffb4ab]/30 flex items-start gap-2.5 text-[#ffb4ab] font-mono text-[11px] leading-relaxed">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 animate-bounce" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* SUCCESS STATUS DIALOG */}
          {successMessage && (
            <div className="p-3 bg-[#00e0b3]/10 border border-[#00e0b3]/30 flex items-start gap-2.5 text-[#00e0b3] font-mono text-[11px] leading-relaxed">
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 animate-pulse" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* PRIMARY INTERFACE BUTTON */}
          <button
            type="submit"
            disabled={isConnecting}
            className={`w-full h-12 font-mono text-sm relative overflow-hidden group active:scale-[0.98] transition-all border border-[#00e0b3] flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(0,224,179,0.15)] ${
              isConnecting 
                ? 'bg-transparent text-[#00e0b3] opacity-60' 
                : 'bg-[#00e0b3] text-[#002118] hover:brightness-110'
            }`}
          >
            <div className="relative flex items-center gap-2 tracking-[0.15em] font-black uppercase font-sans">
              {isLogin ? (
                <>
                  <LogIn className="w-4 h-4 shrink-0" />
                  <span>{isConnecting ? 'VERIFYING CREDENTIALS...' : 'ESTABLISH_LINK.SH'}</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4 shrink-0" />
                  <span>{isConnecting ? 'INSCRIBING DATA...' : 'REGISTER_AUTHORIZED.SH'}</span>
                </>
              )}
            </div>
            {/* Corner styling elements */}
            <div className="absolute top-0 left-0 w-1.5 h-1.5 border-t border-l border-black" />
            <div className="absolute bottom-0 right-0 w-1.5 h-1.5 border-b border-r border-black" />
          </button>
        </form>

        {/* LOGS BUFFER CONSOLE DECORATIVE */}
        <div className="mt-6 bg-[#0e0e0e] border border-[#3a4a44]/50 p-3 font-mono text-[9px] text-[#b9cbc2]/60 uppercase space-y-1">
          <div className="text-[8px] text-[#00e0b3]/50 border-b border-[#3a4a44]/20 pb-1 mb-1 tracking-widest font-black">
            &gt;_ LINK_ESTABLISHMENT_REPORTS // 實時終端通訊紀錄
          </div>
          {logs.map((log, idx) => (
            <p key={idx} className="truncate select-none">{log}</p>
          ))}
        </div>

        {/* TOGGLE LINK */}
        <div className="mt-6 text-center border-t border-[#3a4a44]/35 pt-4">
          <button
            type="button"
            onClick={() => {
              setIsLogin(!isLogin);
              setErrorMessage(null);
              setSuccessMessage(null);
              setPassword('');
              setConfirmPassword('');
              addLog(`TRIGGERED SCREEN CONTEXT MUTATION: ${!isLogin ? 'REGISTRATION' : 'LOGIN'}`);
            }}
            disabled={isConnecting}
            className="text-xs text-[#00e0b3] hover:underline cursor-pointer flex items-center justify-center gap-1.5 mx-auto font-mono font-medium"
          >
            {isLogin ? (
              <>
                <span>NO ENCRYPTED ACCESS CODE? AUTHORIZE NEW UNIT // 新操作員註冊授權</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </>
            ) : (
              <>
                <span>RETRACT TO OPERATOR SIGN-IN IDENTIFICATION // 返回已登錄操作員</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
        
        {/* Tips footer */}
        <div className="mt-4 text-[10px] text-center text-[#b9cbc2]/40 font-mono italic">
          Default test credentials: Username <strong className="text-[#00e0b3]">DOCTOR</strong>, Passcode <strong className="text-[#00e0b3]">shining</strong>
        </div>
      </motion.div>
    </div>
  );
}
