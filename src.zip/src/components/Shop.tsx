import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Award, Eye, Megaphone, ShieldCheck, Cpu, ShoppingBag, Coins, Sparkles, CheckCircle2, Lock, Feather, HelpCircle, PackageOpen, User,
  Dices, RefreshCw
} from 'lucide-react';
import { UserProgress } from '../types';
import AvatarWithFrame, { AVATAR_FRAMES, AvatarFrame } from './AvatarWithFrame';
import { GACHA_AVATARS, GachaItem, GACHA_ITEMS, getRandomGachaItem } from '../avatarData';

export interface ShopSkin {
  id: string;
  name: string;
  nameChinese: string;
  price: number;
  primaryColor: string;
  bgColor: string;
  glowColor: string;
  description: string;
  isGachaOnly?: boolean;
}

export const SHOP_SKINS: ShopSkin[] = [
  {
    id: 'CLASSIC',
    name: 'PRTS Classic',
    nameChinese: 'PRTS 經典青色',
    price: 0,
    primaryColor: '#00e0b3',
    bgColor: 'rgba(0, 224, 179, 0.1)',
    glowColor: 'rgba(0, 224, 179, 0.25)',
    description: 'Rhodes Island standard tactical HUD color configuration. High efficiency and high contrast.'
  },
  {
    id: 'AMBER',
    name: 'Rhodes Amber',
    nameChinese: '羅德島暖陽琥珀',
    price: 600,
    primaryColor: '#ffb870',
    bgColor: 'rgba(255, 184, 112, 0.1)',
    glowColor: 'rgba(255, 184, 112, 0.25)',
    description: 'Warmer HUD emission spectra, suitable for reading terminal logs in low-light environments.'
  },
  {
    id: 'CRIMSON',
    name: 'Syracuse Crimson',
    nameChinese: '敘拉古深紅戰意',
    price: 1200,
    primaryColor: '#ff4b4b',
    bgColor: 'rgba(255, 75, 75, 0.1)',
    glowColor: 'rgba(255, 75, 75, 0.25)',
    description: 'High-intensity tactical color array from Syracuse command outposts. Keeps operator awareness sharp.'
  },
  {
    id: 'GOLD',
    name: 'Victoria Royal Gold',
    nameChinese: '維多利亞皇家金',
    price: 2000,
    primaryColor: '#ffd700',
    bgColor: 'rgba(255, 215, 0, 0.1)',
    glowColor: 'rgba(255, 215, 0, 0.25)',
    description: 'Extravagant Royal Guard interface. Gilded chrome outlines optimized for elite personnel.'
  },
  {
    id: 'PURPLE',
    name: 'Laterano Neon Purple',
    nameChinese: '拉特蘭聖潔霓虹紫',
    price: 3000,
    primaryColor: '#cc55ff',
    bgColor: 'rgba(204, 85, 255, 0.1)',
    glowColor: 'rgba(204, 85, 255, 0.25)',
    description: 'Experimental halo-resonant wavelength system. High-energy violet spectrum for advanced operators.'
  },
  {
    id: 'LUNGMEN',
    name: 'Lungmen Guard Emblem',
    nameChinese: '龍門近衛局·鱗火',
    price: 0,
    primaryColor: '#ff6a00',
    bgColor: 'rgba(255, 106, 0, 0.08)',
    glowColor: 'rgba(255, 106, 0, 0.22)',
    description: 'Special administrative edition inspired by Wei Yenwu\'s traditional smoky office and the L.G.D. cyber-dragon. Emits a rich amber scale glow with crimson embers.'
  },
  // GACHA EXCLUSIVE SPECIAL SKINS (isGachaOnly: true)
  {
    id: 'SKIN_YATO_SHADOW',
    name: 'Yato Shadow Matte',
    nameChinese: '夜刀 · 影刃墨灰系統UI',
    price: 0,
    primaryColor: '#707070',
    bgColor: 'rgba(112, 112, 112, 0.08)',
    glowColor: 'rgba(112, 112, 112, 0.25)',
    description: '【普通】啞光鋼硬灰。設計源自先鋒幹員夜刀的戰術遮光面覆，追求無冗餘的高穩定性。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_PLUME_SWIFT',
    name: 'Plume Messenger Swift',
    nameChinese: '翎羽 · 迅捷守衛護甲UI',
    price: 0,
    primaryColor: '#556b2f',
    bgColor: 'rgba(85, 107, 47, 0.08)',
    glowColor: 'rgba(85, 107, 47, 0.25)',
    description: '【普通】守衛暗綠與黑灰戰術HUD。結合拉特蘭邊境突防翎毛盾與特製機動哨兵鋼甲色澤。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_MELANTHA_ROSE',
    name: 'Melantha Midnight Violet',
    nameChinese: '玫蘭莎 · 薔薇幽暗紫UI',
    price: 0,
    primaryColor: '#8a2be2',
    bgColor: 'rgba(138, 43, 226, 0.08)',
    glowColor: 'rgba(138, 43, 226, 0.35)',
    description: '【稀有】優雅玫色紫羅蘭戰術控制介面。流露淡淡的花香底襯與凌厲的劍技切割，極致感性。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_FANG_CHARGE',
    name: 'Fang Vanguard Charge',
    nameChinese: '芬 · 先鋒挺進極速綠UI',
    price: 0,
    primaryColor: '#20b2aa',
    bgColor: 'rgba(32, 178, 170, 0.08)',
    glowColor: 'rgba(32, 178, 170, 0.35)',
    description: '【稀有】預備兵行動小隊極速綠HUD。洋溢着青春活力與一往無前的突進指示，操作回饋機敏。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_AMIYA_CHIMERA',
    name: 'Amiya Chimera Azure',
    nameChinese: '阿米婭 · 奇美拉晶藍UI',
    price: 0,
    primaryColor: '#00ccff',
    bgColor: 'rgba(0, 204, 255, 0.1)',
    glowColor: 'rgba(0, 204, 255, 0.45)',
    description: '【史詩】阿米婭與羅德島意志共震的晶透深海藍。呼吸晶面背景，點綴源石黑色阻解物微域。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_CHEN_DRAGON',
    name: 'Ch\'en Dragon Scale',
    nameChinese: '陳 · 龍炎赤霄重載UI',
    price: 0,
    primaryColor: '#ff2255',
    bgColor: 'rgba(255, 34, 85, 0.1)',
    glowColor: 'rgba(255, 34, 85, 0.45)',
    description: '【史詩】督察官冷肅紅玄警示色彩。赤霄刀芒的熾烈波長，帶來最純粹的臨戰執法回饋與威懾。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_TEXAS_WOLF',
    name: 'Texas Wild Rain',
    nameChinese: '德克薩斯 · 荒野雨夜UI',
    price: 0,
    primaryColor: '#ffaa00',
    bgColor: 'rgba(255, 170, 0, 0.12)',
    glowColor: 'rgba(255, 170, 0, 0.55)',
    description: '【傳說】企鵝物流首席司機與荒野雙刃之狼的主題。附帶夜雨街區流光、金黃警示燈帶與呼吸殘影。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_MOSTIMA_TIME',
    name: 'Mostima Chronos Flux',
    nameChinese: '莫斯提馬 · 歲月晶弦UI',
    price: 0,
    primaryColor: '#6f00ff',
    bgColor: 'rgba(111, 0, 255, 0.12)',
    glowColor: 'rgba(111, 0, 255, 0.55)',
    description: '【傳說】時空倒演星塵法陣之環。底盤加載動態圓環時差運轉刻線，展現莫斯提馬至尊尊貴信使色彩。',
    isGachaOnly: true
  },
  {
    id: 'SKIN_W_EMBER',
    name: 'W Fiery Ember Revelation',
    nameChinese: 'W · 烈焰啟示錄動態系統UI',
    price: 0,
    primaryColor: '#ff3000',
    bgColor: 'rgba(255, 48, 0, 0.18)',
    glowColor: 'rgba(255, 48, 0, 0.75)',
    description: '【★限定★/至高】W爆裂烈焰金火主介面。擁有最頂尖戰術質感，邊緣升騰熔岩微粒與高溫熱輻射。',
    isGachaOnly: true
  }
];

export interface SouvenirItem {
  id: string;
  name: string;
  nameChinese: string;
  price: number;
  description: string;
  descriptionChinese: string;
  rarity: 3 | 4 | 5 | 6; 
  iconName: string;
}

export const SOUVENIRS: SouvenirItem[] = [
  {
    id: 'AMIYA_RING',
    name: "Amiya's Ring",
    nameChinese: '阿米婭的指環',
    price: 500,
    description: "Rhodes Island Leader's constraint ring. Inhibits immense originium arts potential.",
    descriptionChinese: "羅德島領袖阿米婭所戴的約束指環。能有效壓制與穩定體內的源石能量與法術意念。",
    rarity: 5,
    iconName: 'Feather'
  },
  {
    id: 'KAL_SIGNAL',
    name: "Dr. Kal'tsit's Mon3tr Signal",
    nameChinese: '凱爾希的 Mon3tr 訊號器',
    price: 1200,
    description: "Summons a monstrous crystalline lifeform. Handles tactical threats efficiently.",
    descriptionChinese: "凱爾希醫生的特定召喚訊號器。可在戰場重組並召喚強勁的晶體獸體 Mon3tr 執行清障與壓制任務。",
    rarity: 6,
    iconName: 'ShieldCheck'
  },
  {
    id: 'ELITE_CERT',
    name: "Elite II Promotion Certificate",
    nameChinese: '精英二階段晉升證書',
    price: 1800,
    description: "Ultimate tactical acknowledgment. Operator limit parameters released.",
    descriptionChinese: "幹員精英二階段晉升認證證書。代表對操作員最高等級戰術能力的授權肯定與上限突破。",
    rarity: 6,
    iconName: 'Award'
  },
  {
    id: 'DOBERMANN_WHISTLE',
    name: "Dobermann's Tactical Whistle",
    nameChinese: '杜賓的教官哨笛',
    price: 300,
    description: "Keeps recruits in absolute order. Standard discipline vector.",
    descriptionChinese: "教官杜賓隨身攜帶的金屬哨子。能在嘈雜、混亂的模擬對戰中迅速集結新人，保持絕對紀律。",
    rarity: 4,
    iconName: 'Megaphone'
  },
  {
    id: 'SLIME_CONTAINER',
    name: "Originium Slime Jar",
    nameChinese: '源石蟲標本罐',
    price: 200,
    description: "A secure quarantine container with a common Ursus wasteland fauna. Harmless if sealed.",
    descriptionChinese: "一個內部密封有源石蟲高純度結晶標本的防漏罐。如果蓋子保持鎖緊狀態，通常是安全的。",
    rarity: 3,
    iconName: 'Eye'
  },
  {
    id: 'PRTS_CORE',
    name: "PRTS Memory Core Mk.I",
    nameChinese: 'PRTS 核心記憶體一型',
    price: 800,
    description: "Contains early diagnostic telemetry data of Doctor's cognitive synclink.",
    descriptionChinese: "PRTS 內部快閃虛擬記憶體。記錄了博士與本系統進行神經同步早期，最純粹的診斷回流軌跡。",
    rarity: 5,
    iconName: 'Cpu'
  }
];

interface ShopProps {
  progress: UserProgress;
  onUpdateProgress: (updated: UserProgress) => void;
}

export default function Shop({ progress, onUpdateProgress }: ShopProps) {
  const [activeSubTab, setActiveSubTab] = useState<'DASHBOARD' | 'SKINS' | 'SOUVENIRS' | 'FRAMES' | 'GACHA'>('DASHBOARD');
  const [purchaseFeedback, setPurchaseFeedback] = useState<string | null>(null);

  // Gacha System states
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawnGachaItems, setDrawnGachaItems] = useState<{ item: GachaItem; isNew: boolean; refundOrundum: number }[]>([]);
  const [showDrawModal, setShowDrawModal] = useState(false);

  // Safe fetch of currency and stores
  const orundum = progress.orundum !== undefined ? progress.orundum : 1200;
  const ownedSkins = progress.ownedSkins || ['CLASSIC'];
  const activeSkin = progress.activeSkin || 'CLASSIC';
  const ownedSouvenirs = progress.ownedSouvenirs || [];
  const ownedFrames = progress.ownedFrames || ['CLASSIC'];
  const activeFrame = progress.activeFrame || 'CLASSIC';
  const ownedAvatars = progress.ownedAvatars || ['DEFAULT'];
  const activeAvatar = progress.activeAvatar || 'DEFAULT';

  const handleGachaDraw = (count: 1 | 10) => {
    const cost = count === 1 ? 600 : 5800;
    if (orundum < cost) {
      showFeedback(`INSUFFICIENT ORUNDUM COGNITIVE VECTORS // 餘額不足：合成玉數量不足以尋訪！需 ${cost} 合成玉。`);
      return;
    }

    setIsDrawing(true);
    showFeedback(`CONNECTING TO NEURAL COGNITIVE DECRYPTOR // 正在同步並引導高維解碼鏈物資尋訪...`);

    setTimeout(() => {
      const results: { item: GachaItem; isNew: boolean; refundOrundum: number }[] = [];
      const currentOwnedSkins = [...ownedSkins];
      const currentOwnedFrames = [...ownedFrames];
      let runningOrundum = orundum - cost;

      for (let i = 0; i < count; i++) {
        const item = getRandomGachaItem();
        
        let alreadyOwned = false;
        if (item.type === 'SKIN') {
          alreadyOwned = currentOwnedSkins.includes(item.id);
        } else {
          alreadyOwned = currentOwnedFrames.includes(item.id);
        }

        let refund = 0;

        if (alreadyOwned) {
          switch (item.rarity) {
            case 'COMMON': refund = 150; break;
            case 'RARE': refund = 300; break;
            case 'EPIC': refund = 800; break;
            case 'LEGENDARY': refund = 1500; break;
            case 'LIMITED': refund = 2500; break;
          }
          runningOrundum += refund;
        } else {
          if (item.type === 'SKIN') {
            currentOwnedSkins.push(item.id);
          } else {
            currentOwnedFrames.push(item.id);
          }
        }

        results.push({
          item,
          isNew: !alreadyOwned,
          refundOrundum: refund
        });
      }

      const updated: UserProgress = {
        ...progress,
        orundum: runningOrundum,
        ownedSkins: currentOwnedSkins,
        ownedFrames: currentOwnedFrames
      };

      onUpdateProgress(updated);
      setDrawnGachaItems(results);
      setIsDrawing(false);
      setShowDrawModal(true);

      const highlights = results.filter(r => r.item.rarity === 'LIMITED' || r.item.rarity === 'LEGENDARY');
      if (highlights.length > 0) {
        showFeedback(`ALERT: ACQUIRED HIGH-DIMENSIONAL DECODED DATA // 警告：譯碼程序解鎖了極地傳說或本期限定套裝！`);
      } else {
        showFeedback(`NEURAL DECODER OUTPUT SUCCESSFUL // 幹員通訊數據解碼成功，解鎖 ${count} 次全新介面/外框。`);
      }
    }, 1600);
  };

  const handleEquipGachaItem = (item: GachaItem) => {
    let updated: UserProgress = { ...progress };
    if (item.type === 'SKIN') {
      if (!ownedSkins.includes(item.id)) {
        showFeedback(`ERROR: SKIN NOT OWNED // 錯誤：對應的系統介面尚未被尋訪解密！`);
        return;
      }
      updated.activeSkin = item.id;
      showFeedback(`ACTIVATED CORE THEME SKIN: [${item.nameChinese}] // 系統全局UI皮膚已成功裝配。`);
    } else {
      if (!ownedFrames.includes(item.id)) {
        showFeedback(`ERROR: FRAME NOT OWNED // 錯誤：對應的外框模組尚未被尋訪解密！`);
        return;
      }
      updated.activeFrame = item.id;
      showFeedback(`ACTIVATED CORE TERMINAL FRAME: [${item.nameChinese}] // 頭像外邊框已成功更換。`);
    }
    onUpdateProgress(updated);
  };

  const handleBuyFrame = (frame: AvatarFrame) => {
    const isFrameGachaOnly = frame.id.startsWith('FRAME_') && frame.id !== 'CLASSIC';
    if (isFrameGachaOnly && !ownedFrames.includes(frame.id)) {
      setActiveSubTab('GACHA');
      showFeedback(`SEC_DEPT DECONSTRUCT: GACHA EXCLUSIVE FRAME // 該頭像框為尋訪池解碼獨佔！正在引導中樞同步...`);
      return;
    }

    if (ownedFrames.includes(frame.id)) {
      // Already owned, just equip
      const updated: UserProgress = {
        ...progress,
        activeFrame: frame.id,
        ownedSkins, // assure array stability
        ownedFrames
      };
      onUpdateProgress(updated);
      showFeedback(`SUCCESSFULLY INSTALLED AVATAR FRAME [${frame.name}] // 成功裝配【${frame.nameChinese}】。`);
      return;
    }

    if (orundum < frame.price) {
      showFeedback(`INSUFFICIENT ORUNDUM COGNITIVE VECTORS // 餘額不足：合成玉數量不足以兌換此頭像框！`);
      return;
    }

    // Purchase Frame
    const updatedFrames = [...ownedFrames, frame.id];
    const updated: UserProgress = {
      ...progress,
      orundum: orundum - frame.price,
      ownedFrames: updatedFrames,
      activeFrame: frame.id
    };
    onUpdateProgress(updated);
    showFeedback(`SECURED COGNITIVE SYMMETRY FRAME [${frame.name}] // 成功消耗 ${frame.price} 合成玉，解鎖並啟用【${frame.nameChinese}】。`);
  };

  const handleBuySkin = (skin: ShopSkin) => {
    if (skin.isGachaOnly && !ownedSkins.includes(skin.id)) {
      setActiveSubTab('GACHA');
      showFeedback(`SEC_DEPT DECONSTRUCT: GACHA EXCLUSIVE SKIN // 該系統介面為尋訪池解碼獨佔！正在對齊定製載入接口...`);
      return;
    }

    if (ownedSkins.includes(skin.id)) {
      // Already owned, just equip
      const updated: UserProgress = {
        ...progress,
        activeSkin: skin.id,
        ownedSkins: ownedSkins // assure array stability
      };
      onUpdateProgress(updated);
      showFeedback(`SUCCESSFULLY TUNED COGNITIVE SPECTRUM TO [${skin.name}] // 界面皮膚已成功切換至【${skin.nameChinese}】。`);
      return;
    }

    if (orundum < skin.price) {
      showFeedback(`INSUFFICIENT ORUNDUM COGNITIVE VECTORS // 餘額不足：合成玉數量不足以兌換此皮膚！`);
      return;
    }

    // Purchase Skin
    const updatedSkins = [...ownedSkins, skin.id];
    const updated: UserProgress = {
      ...progress,
      orundum: orundum - skin.price,
      ownedSkins: updatedSkins,
      activeSkin: skin.id
    };
    onUpdateProgress(updated);
    showFeedback(`SECURED HUD SKIN AUTHORIZATION for [${skin.name}] // 成功消耗 ${skin.price} 合成玉，解鎖並啟用【${skin.nameChinese}】皮膚。`);
  };

  const handleBuySouvenir = (item: SouvenirItem) => {
    if (ownedSouvenirs.includes(item.id)) {
      showFeedback(`SOUVENIR ALREADY STORED IN ARCHIVE STORAGE // 您已擁有【${item.nameChinese}】紀念道具，不可重複兌換。`);
      return;
    }

    if (orundum < item.price) {
      showFeedback(`INSUFFICIENT ORUNDUM COGNITIVE VECTORS // 餘額不足：合成玉數量不足以兌換此紀念道具。`);
      return;
    }

    // Purchase Souvenir
    const updatedSouvenirs = [...ownedSouvenirs, item.id];
    const updated: UserProgress = {
      ...progress,
      orundum: orundum - item.price,
      ownedSouvenirs: updatedSouvenirs
    };
    onUpdateProgress(updated);
    showFeedback(`SOUVENIR RETRIEVED: [${item.name}] SECURED // 成功消耗 ${item.price} 合成玉，【${item.nameChinese}】已收入您的核心檔案模組。`);
  };

  const showFeedback = (msg: string) => {
    setPurchaseFeedback(msg);
    setTimeout(() => {
      setPurchaseFeedback(null);
    }, 5000);
  };

  const getRarityStars = (rarity: number) => {
    return '★'.repeat(rarity);
  };

  const renderSouvenirIcon = (iconName: string) => {
    switch (iconName) {
      case 'Feather':
        return <Feather className="w-8 h-8 text-[#ffb870]" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-8 h-8 text-[#ff4b4b]" />;
      case 'Award':
        return <Award className="w-8 h-8 text-[#ffd700]" />;
      case 'Megaphone':
        return <Megaphone className="w-8 h-8 text-[#b9cbc2]" />;
      case 'Eye':
        return <Eye className="w-8 h-8 text-[#00e0b3]" />;
      case 'Cpu':
        return <Cpu className="w-8 h-8 text-[#cc55ff]" />;
      default:
        return <Cpu className="w-8 h-8 text-[#00e0b3]" />;
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Header */}
      <div className="border-l-4 border-[var(--theme-color,#00e0b3)] pl-6 py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl text-white font-bold tracking-tighter uppercase">
            PROCUREMENT CENTER // 採購中心
          </h2>
          <p className="text-[#b9cbc2] text-xs uppercase tracking-widest mt-1">
            Exchange Orundum memory sync gems for advanced tactical HUD skins and souvenirs. ┃ 幹員物資採購與紀念品兌換。
          </p>
        </div>

        {/* Currency Display Widget */}
        <div className="bg-[#1c1b1b] border border-[#3a4a44] px-4 py-2 flex items-center gap-3 shadow-[0_0_15px_rgba(0,0,0,0.4)] shrink-0 self-start sm:self-center">
          <div className="w-7 h-7 bg-[#ff4242]/10 border border-[#ff4242]/30 flex items-center justify-center animate-spin-slow">
            <Coins className="w-4 h-4 text-[#ff4242]" />
          </div>
          <div className="font-mono">
            <p className="text-[9px] text-[#b9cbc2]/40 tracking-widest uppercase">Orundum Balance // 持有合成玉</p>
            <p className="text-xl font-bold text-white tracking-widest flex items-center gap-1.5 mt-0.5">
              <span className="text-[#ff4242] font-black">{orundum}</span>
              <span className="text-xs text-[#b9cbc2]/60">玉</span>
            </p>
          </div>
        </div>
      </div>

      {/* Internal Subtabs for Shop categories */}
      <div className="flex border-b border-[#3a4a44]/60 overflow-x-auto scrollbar-thin">
        <button
          onClick={() => {
            setActiveSubTab('DASHBOARD');
            showFeedback('RETURNING TO PROCUREMENT DASHBOARD // 正在返回採購中心指引總部...');
          }}
          className={`px-6 py-3 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center gap-2 shrink-0 ${
            activeSubTab === 'DASHBOARD'
              ? 'border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>OVERVIEW // 採購首頁</span>
        </button>

        <button
          onClick={() => {
            setActiveSubTab('SKINS');
            showFeedback('OPENING INTERFACE RE-DYE PROTOCOLS // 正在加載終端系統客製化皮膚面板...');
          }}
          className={`px-6 py-3 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center gap-2 shrink-0 ${
            activeSubTab === 'SKINS'
              ? 'border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>UI SKINS // 終端皮膚</span>
        </button>

        <button
          onClick={() => {
            setActiveSubTab('SOUVENIRS');
            showFeedback('RETRIEVING HISTORICAL MEMORY ARTIFACTS // 正在拉取羅德島紀念幹員道具檔案...');
          }}
          className={`px-6 py-3 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center gap-2 shrink-0 ${
            activeSubTab === 'SOUVENIRS'
              ? 'border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <PackageOpen className="w-3.5 h-3.5" />
          <span>SOUVENIRS // 紀念常駐庫</span>
        </button>

        <button
          onClick={() => {
            setActiveSubTab('FRAMES');
            showFeedback('ACCESSING AVATAR FRAME ENCRYPTORS // 正在聯網同步外層頭像框編譯接口...');
          }}
          className={`px-6 py-3 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center gap-2 shrink-0 ${
            activeSubTab === 'FRAMES'
              ? 'border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>AVATAR FRAMES // 頭像外框</span>
        </button>

        <button
          onClick={() => {
            setActiveSubTab('GACHA');
            showFeedback('CONNECTING TO NEURAL DECODER // 正在連接擬真尋訪解碼器...');
          }}
          className={`px-6 py-3 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center gap-2 shrink-0 ${
            activeSubTab === 'GACHA'
              ? 'border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <Dices className="w-3.5 h-3.5" />
          <span>LUCKY DRAW // 尋訪抽獎池</span>
        </button>
      </div>

      {/* Diagnostic log notifications */}
      {purchaseFeedback && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3.5 bg-[#171717] border-l-2 border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] font-mono text-xs leading-relaxed uppercase flex items-center gap-2 shadow-lg"
        >
          <Sparkles className="w-4 h-4 text-[var(--theme-color,#00e0b3)] animate-pulse shrink-0" />
          <span>{purchaseFeedback}</span>
        </motion.div>
      )}

      {/* SHOP DASHBOARD PORTAL */}
      {activeSubTab === 'DASHBOARD' && (
        <div className="space-y-6">
          {/* Welcome Alert */}
          <div className="bg-[#171717]/90 border border-[#3a4a44]/50 border-l-2 border-l-[var(--theme-color,#00e0b3)] p-4 text-xs font-mono text-[#b9cbc2] leading-relaxed uppercase shadow-[0_0_20px_rgba(0,0,0,0.5)]">
            <span className="text-[var(--theme-color,#00e0b3)] font-extrabold mr-2">✦ WELCOME TO PROCUREMENT // 採購分流中樞</span>
            請選擇需要進入的特定幹員採購部門。各部門提供獨立且高精度的戰略自訂模組與核心物资。
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-8">
            {/* 1. Skins Card */}
            <motion.div 
              whileHover={{ scale: 1.01, borderColor: 'var(--theme-color, #00e0b3)' }}
              className="bg-[#171717]/80 border border-[#3a4a44] p-6 relative flex flex-col justify-between group transition-all"
            >
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div className="w-12 h-12 bg-black/40 border border-[#3a4a44]/60 flex items-center justify-center text-[var(--theme-color,#00e0b3)]">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-mono text-[#b9cbc2]/40 tracking-wider">SEC_DEPT_01</span>
                </div>
                <div className="space-y-1">
                  <h3 className="text-xl font-bold text-white tracking-tight uppercase group-hover:text-[var(--theme-color,#00e0b3)] transition-colors">
                    UI SKINS // 終端皮膚
                  </h3>
                  <p className="text-xs text-[#00e0b3] font-bold tracking-wider">
                    終端介面客製化重燃方案
                  </p>
                </div>
                <p className="text-xs text-[#b9cbc2]/70 leading-relaxed min-h-[40px]">
                  變更全局戰術控制台光譜偏頻。提供包括「羅德島標準青色」、「維多利亞皇家金」、「龍門近衛局·鱗火」等特殊配置。
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#3a4a44]/35 flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#b9cbc2]/30 uppercase">6 SKINS AVAILABLE</span>
                <button 
                  onClick={() => {
                    setActiveSubTab('SKINS');
                    showFeedback('OPENING INTERFACE RE-DYE PROTOCOLS // 正在加載終端系統客製化皮膚面板...');
                  }}
                  className="cursor-pointer text-xs font-mono font-bold tracking-widest text-[var(--theme-color,#00e0b3)] border border-[var(--theme-color,#00e0b3)]/30 bg-[var(--theme-color,#00e0b3)]/5 px-4 py-2 hover:bg-[var(--theme-color,#00e0b3)] hover:text-black transition-colors"
                >
                  ENTER // 進入部門 &rarr;
                </button>
              </div>
            </motion.div>

            {/* 2. Souvenirs Card */}
            <motion.div 
              whileHover={{ scale: 1.01, borderColor: '#ffb870' }}
              className="bg-[#171717]/80 border border-[#3a4a44] p-6 relative flex flex-col justify-between group transition-all"
            >
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div className="w-12 h-12 bg-black/40 border border-[#3a4a44]/60 flex items-center justify-center text-amber-500">
                    <PackageOpen className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-mono text-[#b9cbc2]/40 tracking-wider">SEC_DEPT_02</span>
                </div>
                <div className="space-y-1">
                  <h3 className="text-xl font-bold text-white tracking-tight uppercase group-hover:text-amber-500 transition-colors">
                    SOUVENIRS // 紀念常駐庫
                  </h3>
                  <p className="text-xs text-amber-500 font-bold tracking-wider">
                    羅德島歷史與幹員隨身紀念品
                  </p>
                </div>
                <p className="text-xs text-[#b9cbc2]/70 leading-relaxed min-h-[40px]">
                  兌換獨一無二的羅德島特定指令標本、凱爾希醫生的 Mon3tr 訊號器及阿米婭約束指環，豐富歷史回憶錄。
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#3a4a44]/35 flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#b9cbc2]/30 uppercase">6 ARTIFACTS STORED</span>
                <button 
                  onClick={() => {
                    setActiveSubTab('SOUVENIRS');
                    showFeedback('RETRIEVING HISTORICAL MEMORY ARTIFACTS // 正在拉取羅德島紀念幹員道具檔案...');
                  }}
                  className="cursor-pointer text-xs font-mono font-bold tracking-widest text-amber-500 border border-amber-500/30 bg-amber-500/5 px-4 py-2 hover:bg-amber-500 hover:text-black transition-colors"
                >
                  ENTER // 進入部門 &rarr;
                </button>
              </div>
            </motion.div>

            {/* 3. Avatar Frames Card */}
            <motion.div 
              whileHover={{ scale: 1.01, borderColor: '#3cb371' }}
              className="bg-[#171717]/80 border border-[#3a4a44] p-6 relative flex flex-col justify-between group transition-all"
            >
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div className="w-12 h-12 bg-black/40 border border-[#3a4a44]/60 flex items-center justify-center text-emerald-400">
                    <User className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-mono text-[#b9cbc2]/40 tracking-wider">SEC_DEPT_03</span>
                </div>
                <div className="space-y-1">
                  <h3 className="text-xl font-bold text-white tracking-tight uppercase group-hover:text-emerald-400 transition-colors">
                    AVATAR FRAMES // 头像外框
                  </h3>
                  <p className="text-xs text-emerald-400 font-bold tracking-wider">
                    外層神經網絡特供編譯邊框
                  </p>
                </div>
                <p className="text-xs text-[#b9cbc2]/70 leading-relaxed min-h-[40px]">
                  編譯您在通訊總線下展示的頭像外框，提供特殊的高級裝飾，亮面偏振與多維粒子光譜效果。
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#3a4a44]/35 flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#b9cbc2]/30 uppercase">4 CONFIGURATIONS AVAILABLE</span>
                <button 
                  onClick={() => {
                    setActiveSubTab('FRAMES');
                    showFeedback('ACCESSING AVATAR FRAME ENCRYPTORS // 正在聯網同步外層頭像框編譯接口...');
                  }}
                  className="cursor-pointer text-xs font-mono font-bold tracking-widest text-emerald-400 border border-emerald-400/30 bg-emerald-400/5 px-4 py-2 hover:bg-emerald-400 hover:text-black transition-colors"
                >
                  ENTER // 進入部門 &rarr;
                </button>
              </div>
            </motion.div>

            {/* 4. Lucky Draw Card */}
            <motion.div 
              whileHover={{ scale: 1.01, borderColor: '#ffd700' }}
              className="bg-[#151515] border border-[#ffd700]/30 p-6 relative flex flex-col justify-between group transition-all"
            >
              <div className="absolute top-2 right-2 border border-[#ffd700]/20 bg-[#ffd700]/5 text-[7px] text-[#ffd700] px-1.5 py-0.5 tracking-widest font-mono">
                RECOMMENDED // 強烈推薦
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div className="w-12 h-12 bg-black/40 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700]">
                    <Dices className="w-6 h-6 text-[#ffd700] animate-bounce-slow" />
                  </div>
                  <span className="text-[10px] font-mono text-[#ffd700]/40 tracking-wider">SEC_DEPT_04</span>
                </div>
                <div className="space-y-1">
                  <h3 className="text-xl font-bold text-white tracking-tight uppercase group-hover:text-[#ffd700] transition-colors">
                    LUCKY DRAW // 尋尋訪抽獎池
                  </h3>
                  <p className="text-xs text-[#ffd700] font-bold tracking-wider">
                    中樞神經投影定向定向解譯
                  </p>
                </div>
                <p className="text-xs text-[#b9cbc2]/70 leading-relaxed min-h-[40px]">
                  消耗合成玉解碼PRTS神經元網格。高概率解鎖傳說級「年·熔金歲月「或本期限定級「PRTS·終極超腦中樞」動態特效頭像。
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#ffd700]/20 flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#ffd700]/40 uppercase animate-pulse">LIMITED TIME EVENT // 限期開放</span>
                <button 
                  onClick={() => {
                    setActiveSubTab('GACHA');
                    showFeedback('CONNECTING TO NEURAL DECODER // 正在連接擬真尋訪解碼器...');
                  }}
                  className="cursor-pointer text-xs font-mono font-bold tracking-widest text-[#ffd700] border border-[#ffd700]/40 bg-[#ffd700]/5 px-4 py-2 hover:bg-[#ffd700] hover:text-black transition-colors"
                >
                  DECODE POOL // 啟動尋訪 &rarr;
                </button>
              </div>
            </motion.div>
          </div>
        </div>
      )}

      {/* SKINS SECTION */}
      {activeSubTab === 'SKINS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SHOP_SKINS.map((skin) => {
            const isOwned = ownedSkins.includes(skin.id);
            const isActive = activeSkin === skin.id;

            return (
              <div 
                key={skin.id}
                className={`bg-[#171717]/80 border transition-all p-5 relative flex flex-col justify-between group ${
                  isActive 
                    ? 'border-2 border-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5 shadow-[0_0_20px_rgba(0,224,179,0.06)]' 
                    : isOwned 
                      ? 'border-[#3a4a44]/80 hover:border-[#b9cbc2]/40' 
                      : 'border-[#3a4a44] opacity-90'
                }`}
              >
                {/* Visual skin indicator on top right */}
                <div 
                  className="absolute top-4 right-4 w-3.5 h-3.5 rounded-full border border-white/20 shadow-md flex items-center justify-center spinner-slow"
                  style={{ backgroundColor: skin.primaryColor }}
                />

                <div className="space-y-2.5">
                  <div className="space-y-0.5">
                    <p className="text-[9px] text-[#b9cbc2]/40 font-mono tracking-widest uppercase">HUD_SPECTRUM_ID // 變焦模式</p>
                    <h3 className="text-lg font-bold text-white tracking-tight uppercase" style={{ color: isActive ? skin.primaryColor : '#ffffff' }}>
                      {skin.name}
                    </h3>
                    <p className="text-xs text-[#00e0b3] font-bold tracking-wider" style={{ color: skin.primaryColor }}>
                      {skin.nameChinese}
                    </p>
                  </div>

                  <p className="text-[#b9cbc2] text-xs leading-relaxed font-sans min-h-[48px]">
                    {skin.description}
                  </p>
                  
                  {/* Color preview bar */}
                  <div className="flex items-center gap-1.5 h-1.5 bg-[#121212] w-full" style={{ outline: '1px solid #222' }}>
                    <div className="h-full w-[40%]" style={{ backgroundColor: skin.primaryColor }} />
                    <div className="h-full w-[30%] opacity-65" style={{ backgroundColor: skin.primaryColor }} />
                    <div className="h-full w-[15%] opacity-30" style={{ backgroundColor: skin.primaryColor }} />
                  </div>

                  {skin.id === 'LUNGMEN' && (
                    <div className="mt-2.5 p-2.5 bg-black/60 border border-[#ff6a00]/30 rounded-sm relative overflow-hidden flex items-center gap-3">
                      <div className="w-11 h-11 shrink-0 text-[#ff6a00] opacity-90">
                        {/* Mini Lungmen Guard Dragon Emblem vector */}
                        <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full text-current">
                          <path d="M50 10 L54 35 L46 35 Z" fill="currentColor" opacity="0.3" />
                          <path d="M50 10 L50 35" />
                          <path d="M42 22 L36 8 L32 20 L24 14 L28 32 L16 28 L22 41" />
                          <path d="M58 22 L64 8 L68 20 L76 14 L72 32 L84 28 L78 41" />
                          <path d="M22 55 L16 57 L28 65 L22 67 M78 55 L84 57 L72 65 L78 67" />
                          <polygon points="44,52 35,50 42,46" fill="currentColor" />
                          <polygon points="56,52 65,50 58,46" fill="currentColor" />
                          <path d="M38 42 L50 48 L62 42" fill="currentColor" opacity="0.1" />
                          <path d="M46 25 L50 21 L54 25 L50 35 Z" />
                          <path d="M44 73 L50 85 L56 73" />
                        </svg>
                      </div>
                      <div className="flex-1 min-w-0 text-left space-y-0.5">
                        <span className="text-[8px] uppercase font-black text-amber-500 font-mono tracking-wider block">L.G.D. COLLABORATION SPECIAL</span>
                        <p className="text-[10px] text-gray-400 font-sans leading-tight">基于【龙门总督府】与【近卫局徽记】联合设计。</p>
                        <span className="text-[8px] uppercase font-mono bg-[#ff6a00]/20 text-[#ff6a00] px-1 py-0.2 border border-[#ff6a00]/30 rounded-sm">FREE REDEMPTION // 零玉兑换</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-6 pt-4 border-t border-[#3a4a44]/35 flex items-center justify-between gap-2">
                  {/* Price info or owned state */}
                  {isOwned ? (
                    <span className="text-[10px] text-[#00e0b3] font-mono tracking-widest font-black uppercase flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" style={{ color: skin.primaryColor }} />
                      <span style={{ color: skin.primaryColor }}>OWNED // 已擁有</span>
                    </span>
                  ) : (
                    <div className="flex items-center gap-1.5 font-mono">
                      <Coins className="w-3.5 h-3.5 text-[#ff4242]" />
                      <span className="text-white font-bold text-sm tracking-wider">{skin.price}</span>
                      <span className="text-[9px] text-[#b9cbc2]/40">合成玉</span>
                    </div>
                  )}

                  {/* Operational Button */}
                  <button
                    onClick={() => handleBuySkin(skin)}
                    className={`text-xs px-4 py-2 font-mono font-bold tracking-widest cursor-pointer transition-all active:scale-95 ${
                      isActive
                        ? 'bg-[#1a2e26]/30 text-[#b9cbc2]/50 border border-[#3a4a44] cursor-not-allowed'
                        : isOwned
                          ? 'border border-[#b9cbc2]/30 hover:border-white text-white hover:bg-white hover:text-black font-semibold'
                          : orundum >= skin.price
                            ? 'bg-transparent text-[#ff4242] border border-[#ff4242]/50 hover:bg-[#ff4242] hover:text-white'
                            : 'border border-[#3a4a44] text-[#b9cbc2]/30 cursor-not-allowed bg-transparent'
                    }`}
                    disabled={isActive}
                  >
                    {isActive 
                      ? 'ACTIVE / 啟用中' 
                      : isOwned 
                        ? 'EQUIP / 裝配使用' 
                        : '兑换 / EXCHANGE'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* SOUVENIRS SECTION */}
      {activeSubTab === 'SOUVENIRS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SOUVENIRS.map((item) => {
            const isOwned = ownedSouvenirs.includes(item.id);

            return (
              <div 
                key={item.id}
                className={`bg-[#171717]/80 border p-5 relative flex flex-col justify-between group h-full ${
                  isOwned 
                    ? 'border-[#00e0b3]/30 bg-[#00e0b3]/[0.01]' 
                    : 'border-[#3a4a44] hover:border-[#3a4a44]/80'
                }`}
              >
                {/* Rarity stars upper right decorator */}
                <div className="absolute top-4 right-4 text-right">
                  <div className="text-[10px] text-[#ffb870] font-mono tracking-widest font-black leading-none">
                    {getRarityStars(item.rarity)}
                  </div>
                  <p className="text-[8px] text-[#b9cbc2]/30 font-mono tracking-widest uppercase mt-0.5">{item.rarity}★ SOUVENIR</p>
                </div>

                <div className="space-y-3.5">
                  {/* Big visual icon representing the object */}
                  <div className="w-14 h-14 bg-[#121212] border border-[#3a4a44] flex items-center justify-center relative shadow-inner group-hover:scale-105 transition-all">
                    {renderSouvenirIcon(item.iconName)}
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 border-r border-b border-[#3a4a44]" />
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-base font-bold text-white tracking-tight uppercase group-hover:text-[#00e0b3] transition-colors">
                      {item.name}
                    </h3>
                    <p className="text-xs text-[#00e0b3] font-bold tracking-wider">
                      {item.nameChinese}
                    </p>
                  </div>

                  <div className="space-y-1.5 font-sans">
                    <p className="text-[#b9cbc2] text-xs leading-relaxed italic border-l border-[#3a4a44] pl-2">
                      "{item.description}"
                    </p>
                    <p className="text-[#b9cbc2]/70 text-[11px] leading-relaxed">
                      {item.descriptionChinese}
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#3a4a44]/35 flex items-center justify-between gap-2">
                  {/* Cost/Requirement info */}
                  {isOwned ? (
                    <span className="text-[10px] text-[#ffb870] font-mono tracking-widest font-black uppercase flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-[#ffb870]" />
                      <span>IN_VAULT // 已收藏</span>
                    </span>
                  ) : (
                    <div className="flex items-center gap-1.5 font-mono">
                      <Coins className="w-3.5 h-3.5 text-[#ff4242]" />
                      <span className="text-white font-bold text-sm tracking-wider">{item.price}</span>
                      <span className="text-[9px] text-[#b9cbc2]/40">合成玉</span>
                    </div>
                  )}

                  {/* Operational Button */}
                  <button
                    onClick={() => handleBuySouvenir(item)}
                    className={`text-xs px-4 py-2 font-mono font-bold tracking-widest cursor-pointer transition-all active:scale-95 ${
                      isOwned
                        ? 'border border-[#3a4a44] text-[#b9cbc2]/30 cursor-not-allowed bg-[#131313]'
                        : orundum >= item.price
                          ? 'bg-[#ff4242] text-white hover:brightness-110 shadow-lg'
                          : 'border border-[#3a4a44] text-[#b9cbc2]/30 cursor-not-allowed bg-transparent'
                    }`}
                    disabled={isOwned}
                  >
                    {isOwned ? 'ARCHIVED' : '兑换 / EXCHANGE'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* FRAMES SECTION */}
      {activeSubTab === 'FRAMES' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {AVATAR_FRAMES.map((frame) => {
            const isOwned = ownedFrames.includes(frame.id);
            const isActive = activeFrame === frame.id;
            const previewAvatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDZ6YNg8nUcZfJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJfaf6u8lJAVk31dqqxLgKyzHFqIhluOD5a2BU4y33e9DWb3jSwcEu";

            return (
              <div 
                key={frame.id}
                className={`bg-[#171717]/80 border transition-all p-5 relative flex flex-col justify-between group ${
                  isActive 
                    ? 'border-2 border-[#ffd700] bg-[#ffd700]/5 shadow-[0_0_20px_rgba(255,215,0,0.06)]' 
                    : isOwned 
                      ? 'border-[#3a4a44]/80 hover:border-[#b9cbc2]/40' 
                      : 'border-[#3a4a44] opacity-90'
                }`}
              >
                {/* Visual skin indicator on top right */}
                <div className="absolute top-4 right-4">
                  <span className="text-[9px] text-[#ffd700] font-mono font-bold tracking-wider" style={{ color: frame.borderColor }}>
                    {frame.id === 'CLASSIC' ? 'STANDARD' : 'EXCLUSIVE // 特供'}
                  </span>
                </div>

                <div className="space-y-4">
                  {/* Live Avatar Preview */}
                  <div className="flex items-center gap-3">
                    <AvatarWithFrame 
                      avatarUrl={previewAvatarUrl}
                      activeFrameId={frame.id}
                      size="lg"
                    />
                    <div>
                      <p className="text-[9px] text-[#b9cbc2]/40 font-mono tracking-widest uppercase">COGNITIVE_FRAME // 頭像邊框</p>
                      <h3 className="text-base font-bold text-white tracking-tight uppercase group-hover:text-[#ffd700] transition-colors">
                        {frame.name}
                      </h3>
                      <p className="text-xs text-[#b9cbc2] font-semibold" style={{ color: frame.borderColor }}>
                        {frame.nameChinese}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-1.5 font-sans">
                    <p className="text-[#b9cbc2]/70 text-[11px] leading-relaxed">
                      {frame.descriptionChinese}
                    </p>
                    <p className="text-[#b9cbc2]/40 text-[9px] leading-relaxed">
                      {frame.description}
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#3a4a44]/35 flex items-center justify-between gap-2">
                  {/* Price info or owned state */}
                  {isOwned ? (
                    <span className="text-[10px] text-[#ffd700] font-mono tracking-widest font-black uppercase flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" style={{ color: frame.borderColor }} />
                      <span style={{ color: frame.borderColor }}>OWNED // 已擁有</span>
                    </span>
                  ) : (
                    <div className="flex items-center gap-1.5 font-mono">
                      <Coins className="w-3.5 h-3.5 text-[#ff4242]" />
                      <span className="text-white font-bold text-sm tracking-wider">{frame.price}</span>
                      <span className="text-[9px] text-[#b9cbc2]/40">合成玉</span>
                    </div>
                  )}

                  {/* Operational Button */}
                  <button
                    onClick={() => handleBuyFrame(frame)}
                    className={`text-xs px-4 py-2 font-mono font-bold tracking-widest cursor-pointer transition-all active:scale-95 ${
                      isActive
                        ? 'bg-[#1a2b25]/10 text-[#b9cbc2]/40 border border-[#3a4a44]/50 cursor-not-allowed'
                        : isOwned
                          ? 'border border-[#ffd700]/50 hover:border-[#ffd700] text-[#ffd700] hover:bg-[#ffd700] hover:text-black'
                          : orundum >= frame.price
                            ? 'bg-transparent text-[#ff4242] border border-[#ff4242]/50 hover:bg-[#ff4242] hover:text-white'
                            : 'border border-[#3a4a44] text-[#b9cbc2]/30 cursor-not-allowed bg-transparent'
                    }`}
                    disabled={isActive}
                  >
                    {isActive 
                      ? 'ACTIVE / 啟用中' 
                      : isOwned 
                        ? 'EQUIP / 裝配使用' 
                        : '兑换 / EXCHANGE'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* GACHA DRAW PANEL */}
      {activeSubTab === 'GACHA' && (
        <div className="space-y-6">
          {/* Main Visual Gacha Hero Banner */}
          <div className="bg-[#151515] border border-[#ffd700]/30 relative p-6 sm:p-8 overflow-hidden">
            {/* Visual background grids */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_20%,rgba(0,255,216,0.06),transparent_60%)] pointer-events-none" />
            <div className="absolute top-2 right-2 border border-[#ffd700]/20 bg-[#ffd700]/5 text-[8px] text-[#ffd700] px-2 py-0.5 tracking-widest font-mono select-none">
              PRTS_NET_DECODE_v12.0
            </div>

            <div className="max-w-2xl space-y-4 relative z-10">
              <div>
                <span className="text-[9px] text-[#ffd700] font-mono tracking-widest uppercase font-bold bg-[#ffd700]/10 border border-[#ffd700]/30 px-2 py-0.5 rounded-sm">
                  NEW RECRUIT_POOL // 限期定向解碼尋訪
                </span>
                <h3 className="text-2xl sm:text-3xl font-black text-white tracking-widest uppercase mt-2">
                  NEURAL COMPENDIUM // 中樞神經投影
                </h3>
              </div>

              <p className="text-xs text-[#b9cbc2]/80 leading-relaxed font-sans">
                消耗合成玉重連羅德島主控終端，解碼PRTS底層數據資訊，獲取高級戰略操作頭像！
                本期限定幹員模組 <span className="text-[#00ffd8] font-bold">【PRTS · 終極超腦中樞】</span> 限時解譯，包含絢爛彩虹特效與動態頻譜。
              </p>

              {/* Probabilities Rate display */}
              <div className="flex flex-wrap gap-2 text-[10px] font-mono uppercase bg-[#1a1a1a] p-3 border border-[#3a4a44]/30">
                <span className="text-[#b1b1b1] font-bold">機率分佈 ➔</span>
                <span className="text-gray-400">普通 (70%)</span>
                <span className="text-[#3cb371]">稀有 (20%)</span>
                <span className="text-[#00ccff]">史詩 (6%)</span>
                <span className="text-[#ffd700] font-bold animate-pulse">傳說 (3%)</span>
                <span className="text-[#00ffd8] font-black tracking-widest animate-pulse border-b border-[#00ffd8]/40">限定 (1%)</span>
              </div>

              {/* Draw Action Triggers */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4 shrink-0">
                {/* Single draw 600 */}
                <button
                  onClick={() => handleGachaDraw(1)}
                  disabled={isDrawing}
                  className={`flex-1 flex justify-between items-center bg-transparent border py-4 px-6 font-mono text-xs font-bold tracking-widest uppercase transition-all duration-200 active:scale-95 ${
                    isDrawing 
                      ? 'bg-[#181818] border-[#3a4a44] text-gray-500 cursor-not-allowed' 
                      : orundum >= 600
                        ? 'border-[#00ffd8]/40 text-[#00ffd8] hover:bg-[#00ffd8] hover:text-black hover:border-transparent hover:shadow-[0_0_15px_rgba(0,255,216,0.15)] cursor-pointer'
                        : 'border-[#ff4242]/20 text-[#ff4242]/50 hover:bg-[#ff4242]/5 bg-transparent cursor-pointer'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <RefreshCw className={`w-4 h-4 ${isDrawing ? 'animate-spin' : ''}`} />
                    DECODE x1 // 解碼乙次
                  </span>
                  <span className="font-extrabold flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" />
                    600 玉
                  </span>
                </button>

                {/* Tenfold draw 5800 */}
                <button
                  onClick={() => handleGachaDraw(10)}
                  disabled={isDrawing}
                  className={`flex-1 flex justify-between items-center bg-transparent border py-4 px-6 font-mono text-xs font-bold tracking-widest uppercase transition-all duration-200 active:scale-95 ${
                    isDrawing 
                      ? 'bg-[#181818] border-[#3a4a44] text-gray-500 cursor-not-allowed' 
                      : orundum >= 5800
                        ? 'border-[#ffd700]/40 text-[#ffd700] hover:bg-[#ffd700] hover:text-black hover:border-transparent hover:shadow-[0_0_15px_rgba(255,215,0,0.15)] cursor-pointer'
                        : 'border-[#ff4242]/20 text-[#ff4242]/50 hover:bg-[#ff4242]/5 bg-transparent cursor-pointer'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Dices className="w-4 h-4 animate-bounce-slow" />
                    DECODE x10 // 十連解碼
                  </span>
                  <span className="font-extrabold flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" />
                    5800 玉 <span className="text-[10px] text-red-500 bg-red-500/10 px-1 py-0.5 line-through">6000</span>
                  </span>
                </button>
              </div>
            </div>

            {/* Simulated Cyber Decoding screen overlay during draw */}
            {isDrawing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-black/95 z-30 flex flex-col items-center justify-center space-y-4"
              >
                <div className="relative w-20 h-20 border border-[var(--theme-color,#00e0b3)] flex items-center justify-center animate-spin-slow">
                  <div className="absolute inset-2 border border-dashed border-[var(--theme-color,#00e0b3)]/60 animate-ping" />
                  <div className="absolute inset-4 bg-[var(--theme-color,#00e0b3)]/10 animate-pulse" />
                  <Cpu className="w-8 h-8 text-[var(--theme-color,#00e0b3)]" />
                </div>
                <div className="text-center font-mono space-y-1">
                  <p className="text-xs text-[var(--theme-color,#00e0b3)] tracking-widest uppercase animate-pulse font-bold">
                    DECRYPTING NEURAL SYNC DATASTREAM /* 解譯神經數據流 */
                  </p>
                  <p className="text-[9px] text-[#b9cbc2]/50">
                    DECODER STATUS: BUSY // DECODING ENCRYPTED VECTORS
                  </p>
                </div>
              </motion.div>
            )}
          </div>

          {/* Gacha Collectors Catalog Table */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#3a4a44]/40 pb-2 gap-2">
              <h4 className="text-xs font-mono font-bold text-white uppercase tracking-widest">
                COGNITIVE INDEX // 尋訪池解密圖鑑 ({
                  GACHA_ITEMS.filter(item => item.type === 'SKIN' ? ownedSkins.includes(item.id) : ownedFrames.includes(item.id)).length
                } / {GACHA_ITEMS.length})
              </h4>
              <span className="text-[10px] font-mono text-[#b9cbc2]/50 text-right uppercase">
                重複項目回收: 普通 +150 | 稀有 +300 | 史詩 +800 | 傳說 +1500 | 限定 +2500 合成玉
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {GACHA_ITEMS.map((item) => {
                const isSkin = item.type === 'SKIN';
                const isOwned = isSkin ? ownedSkins.includes(item.id) : ownedFrames.includes(item.id);
                const isActive = isSkin ? activeSkin === item.id : activeFrame === item.id;

                return (
                  <div 
                    key={item.id}
                    className={`p-4 border transition-all flex items-center gap-4 relative overflow-hidden ${
                      isActive 
                        ? 'border-2 bg-black/40' 
                        : isOwned 
                          ? 'border-[#3a4a44] bg-[#141414] hover:border-[#b9cbc2]/30' 
                          : 'border-[#3a4a44]/20 bg-[#121212]/30 opacity-50'
                    }`}
                    style={{ borderColor: isActive ? item.color : undefined }}
                  >
                    {/* Visual Item type preview */}
                    <div className="w-12 h-12 relative flex items-center justify-center shrink-0">
                      {isSkin ? (
                        /* Styled terminal dashboard preview box */
                        <div 
                          className="w-11 h-11 border flex flex-col items-center justify-center p-0.5 rounded-[2px]"
                          style={{ 
                            borderColor: isOwned ? item.color : '#3a4a44', 
                            backgroundColor: isOwned ? `${item.color}05` : 'transparent' 
                          }}
                        >
                          <div className="w-6 h-1 w-full rounded-[1px] mb-1" style={{ backgroundColor: isOwned ? item.color : '#3a4a44' }} />
                          <span className="text-[6px] font-mono" style={{ color: isOwned ? item.color : '#b9cbc2' }}>UI SKIN</span>
                        </div>
                      ) : (
                        /* Live actual frame decoration layout on default avatar */
                        <AvatarWithFrame 
                          avatarUrl="https://lh3.googleusercontent.com/aida-public/AB6AXuDZ6YNg8nUcZfJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJfaf6u8lJAVk31dqqxLgKyzHFqIhluOD5a2BU4y33e9DWb3jSwcEu"
                          activeFrameId={item.id}
                          size="md"
                        />
                      )}
                    </div>

                    {/* Metadata details */}
                    <div className="flex-1 space-y-0.5 min-w-0">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="text-xs uppercase font-black text-white tracking-widest truncate">
                          {item.nameChinese}
                        </span>
                        {isActive && (
                          <span className="text-[8px] text-black font-black px-1 leading-none uppercase shrink-0" style={{ backgroundColor: item.color }}>
                            ON
                          </span>
                        )}
                        {!isOwned && (
                          <span className="text-[8px] bg-[#93000a]/10 border border-[#ffb4ab]/30 text-[#ffb4ab] font-black px-1.5 py-0.5 leading-none uppercase tracking-wider flex items-center gap-0.5 shrink-0 select-none">
                            <Lock className="w-2.5 h-2.5" /> LOCKED
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 font-mono text-[9px]">
                        <span 
                          className="font-bold uppercase tracking-wider text-[8px] px-1 py-0.5 rounded-[1px]" 
                          style={{ color: item.color, backgroundColor: `${item.color}15`, border: `1px solid ${item.color}35` }}
                        >
                          {item.rarity}
                        </span>
                        <span className="text-[#b9cbc2]/40 truncate">{item.name}</span>
                      </div>

                      <p className="text-[10px] text-[#b9cbc2]/60 line-clamp-1 leading-normal" title={item.description}>
                        {isOwned ? item.description : '解密此尋尋訪池節點可查看背景日誌。'}
                      </p>
                    </div>

                    {/* Action buttons */}
                    <div className="shrink-0">
                      {isActive ? (
                        <span className="text-[9px] font-mono tracking-widest font-black uppercase" style={{ color: item.color }}>ACTIVE</span>
                      ) : isOwned ? (
                        <button
                          onClick={() => handleEquipGachaItem(item)}
                          className="cursor-pointer text-[10px] text-white hover:text-black border border-[#ffd700] text-[#ffd700] hover:bg-[#ffd700] hover:text-black px-2.5 py-1.5 font-mono tracking-widest-sm"
                        >
                          EQUIP // 裝配
                        </button>
                      ) : (
                        <span className="text-[9px] text-[#b9cbc2]/30 font-mono tracking-widest uppercase">LOCKED</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* GACHA RESULTS MODAL */}
      {showDrawModal && (
        <div id="gacha-results-modal" className="fixed inset-0 bg-[#070707]/95 z-50 overflow-y-auto flex items-center justify-center p-4">
          <div className="max-w-4xl w-full bg-[#111111] border border-[#3a4a44]/60 p-6 sm:p-8 space-y-6 relative shadow-[0_0_50px_rgba(0,0,0,0.8)]">
            <div className="absolute top-4 right-4 text-[8px] text-[#b9cbc2]/30 font-mono">
              SECURE_NEURAL_LINK_RESULT
            </div>

            <div className="border-b border-[#3a4a44]/30 pb-3 text-center sm:text-left">
              <h3 className="text-xl font-black text-[#ffd700] uppercase tracking-widest flex items-center justify-center sm:justify-start gap-2">
                <Sparkles className="w-5 h-5 animate-spin-slow text-[#ffd700]" />
                DECODING RESULTS // 譯碼與尋訪簽收單
              </h3>
              <p className="text-xs text-[#b9cbc2]/60 uppercase tracking-widest mt-1">
                The targeted central neural channels have been completely decoded and synchronized securely. Click on any item to equip it.
              </p>
            </div>

            {/* Results Grid layout */}
            <div className={`grid gap-4 ${drawnGachaItems.length === 1 ? 'grid-cols-1 max-w-sm mx-auto' : 'grid-cols-2 md:grid-cols-5'}`}>
              {drawnGachaItems.map((res, idx) => {
                const item = res.item;
                const r = item.rarity;
                const isSkin = item.type === 'SKIN';
                const isCurrentlyActive = isSkin ? activeSkin === item.id : activeFrame === item.id;
                
                return (
                  <motion.div
                    key={idx}
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: idx * 0.08 }}
                    className={`p-4 border text-center flex flex-col items-center justify-between space-y-3 relative overflow-hidden bg-black/40 ${
                      r === 'LIMITED' 
                        ? 'border-[#ff3000]/60 shadow-[0_0_20px_rgba(255,48,0,0.25)]' 
                        : r === 'LEGENDARY' 
                          ? 'border-[#ffaa00]/50 shadow-[0_0_15px_rgba(255,170,0,0.15)]' 
                          : r === 'EPIC' 
                            ? 'border-[#00ccff]/30 shadow-[0_0_10px_rgba(0,204,255,0.05)]' 
                            : r === 'RARE' 
                              ? 'border-[#8a2be2]/30' 
                              : 'border-zinc-800'
                    }`}
                  >
                    {/* Glowing highlight ribbon for limited */}
                    {r === 'LIMITED' && (
                      <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-[#ff3000] via-[#ffd700] to-[#ff3000] animate-pulse" />
                    )}

                    {/* Rarity banner top */}
                    <div className="font-mono text-[8px] uppercase tracking-widest leading-none font-bold py-0.5 px-1.5 bg-black/60 border border-[#3a4a44]/40" style={{ color: item.color }}>
                      {item.rarity}
                    </div>

                    {/* Visual Item type preview */}
                    <div className="w-16 h-16 relative flex items-center justify-center shrink-0">
                      {isSkin ? (
                        /* Beautiful mock themed system UI visual */
                        <div 
                          className="w-14 h-14 border flex flex-col items-center justify-center p-1 rounded-[2px]"
                          style={{ 
                            borderColor: item.color, 
                            backgroundColor: `${item.color}05`,
                            boxShadow: `inset 0 0 10px ${item.color}15, 0 0 10px ${item.color}10` 
                          }}
                        >
                          <div className="w-8 h-2 rounded-[1px] mb-1 animate-pulse" style={{ backgroundColor: item.color }} />
                          <span className="text-[7px] font-mono tracking-tighter" style={{ color: item.color }}>HUD SKIN</span>
                          <span className="text-[6px] text-gray-500 font-mono leading-none">V-CORE</span>
                        </div>
                      ) : (
                        /* Live actual frame decoration layout on default avatar */
                        <AvatarWithFrame 
                          avatarUrl="https://lh3.googleusercontent.com/aida-public/AB6AXuDZ6YNg8nUcZfJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJfaf6u8lJAVk31dqqxLgKyzHFqIhluOD5a2BU4y33e9DWb3jSwcEu"
                          activeFrameId={item.id}
                          size="lg"
                        />
                      )}
                    </div>

                    {/* Text values */}
                    <div>
                      <span className="text-[7px] font-mono uppercase tracking-wider text-gray-500 block leading-none mb-0.5">
                        {isSkin ? 'SYSTEM_UI_SKIN // 系統皮膚' : 'TERMINAL_FRAME // 頭像邊框'}
                      </span>
                      <h4 className="text-xs font-black text-white tracking-widest truncate max-w-[130px]" style={{ color: item.color }}>
                        {item.nameChinese}
                      </h4>
                      <p className="text-[8px] text-gray-500 font-mono mt-0.5 truncate max-w-[130px]">
                        {item.name}
                      </p>
                    </div>

                    {/* Status marker & Instant Equip */}
                    <div className="text-[9px] font-mono select-none w-full space-y-1">
                      {res.isNew ? (
                        <span className="text-[#00ffd8] bg-[#00ffd8]/10 border border-[#00ffd8]/30 px-1 py-0.5 rounded-[1px] font-bold tracking-widest animate-pulse block text-[8px]">
                          [ NEW // 新解鎖 ]
                        </span>
                      ) : (
                        <div className="text-[#ff4b4b] bg-[#ff4b4b]/10 border border-[#ff4b4b]/20 px-1 py-0.5 rounded-[1px] text-[8px] font-black block leading-none">
                          DUPLICATE +{res.refundOrundum}玉
                        </div>
                      )}

                      {isCurrentlyActive ? (
                        <span className="text-[8px] text-[#00ffd8] bg-[#00ffd8]/20 border border-[#00ffd8]/40 font-black tracking-wider py-0.5 px-1.5 block uppercase rounded-[1px]">
                          ACTIVE // 已裝配
                        </span>
                      ) : (
                        <button
                          onClick={() => handleEquipGachaItem(item)}
                          className="w-full cursor-pointer bg-white text-black hover:bg-[#00ffd8] hover:text-black border border-transparent font-sans font-black text-[8px] tracking-wider py-1 uppercase rounded-[2px]"
                        >
                          EQUIP // 裝配
                        </button>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Total duplicate refund metrics */}
            {drawnGachaItems.some(r => !r.isNew) && (
              <div className="bg-[#181818] border border-red-500/10 p-3 flex justify-between items-center text-xs font-mono">
                <span className="text-gray-400 font-medium flex items-center gap-1">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  DUPL_RECOVERY_PROTOCOL /* 重複數據回收 */
                </span>
                <span className="text-[#ff4b4b] font-black tracking-wider bg-red-950/20 px-3 py-1 border border-red-500/20">
                  REFUND TOTAL: +{drawnGachaItems.reduce((acc, r) => acc + r.refundOrundum, 0)} 合成玉
                </span>
              </div>
            )}

            {/* Action buttons for modal closure or immediate reroll */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-[#3a4a44]/30 font-mono text-xs">
              <button
                onClick={() => setShowDrawModal(false)}
                className="flex-1 cursor-pointer py-3 border border-[#b9cbc2]/40 hover:border-white text-white hover:bg-white hover:text-black font-bold uppercase tracking-widest text-center"
              >
                SIGN & CONFIRM // 簽收並關閉
              </button>

              {/* Reroll single button */}
              {drawnGachaItems.length === 1 && (
                <button
                  onClick={() => {
                    setShowDrawModal(false);
                    handleGachaDraw(1);
                  }}
                  disabled={orundum < 600}
                  className={`flex-1 py-3 text-center border font-bold uppercase tracking-widest transition-all ${
                    orundum >= 600
                      ? 'border-[#00ffd8] text-[#00ffd8] hover:bg-[#00ffd8] hover:text-black hover:border-transparent cursor-pointer'
                      : 'border-zinc-800 text-gray-600 cursor-not-allowed'
                  }`}
                >
                  DECODE AGAIN (600玉) // 再次解碼一次
                </button>
              )}

              {/* Reroll tenfold button */}
              {drawnGachaItems.length === 10 && (
                <button
                  onClick={() => {
                    setShowDrawModal(false);
                    handleGachaDraw(10);
                  }}
                  disabled={orundum < 5800}
                  className={`flex-1 py-3 text-center border font-bold uppercase tracking-widest transition-all ${
                    orundum >= 5800
                      ? 'border-[#ffd700] text-[#ffd700] hover:bg-[#ffd700] hover:text-black hover:border-transparent cursor-pointer'
                      : 'border-zinc-800 text-gray-600 cursor-not-allowed'
                  }`}
                >
                  DECODE AGAIN (5800玉) // 再次十連解碼
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Rules explanation banner */}
      <footer className="bg-[#121212] border border-[#3a4a44]/55 p-4 flex gap-4 items-start">
        <HelpCircle className="w-5 h-5 text-[#b9cbc2]/50 shrink-0 mt-0.5" />
        <div className="text-xs font-mono text-[#b9cbc2]/70 space-y-1.5 leading-relaxed">
          <p className="font-bold text-white uppercase tracking-wider">&gt;_ COGNITIVE REGENERATION & PROCUREMENT GUIDELINES // 購置規則說明</p>
          <ul className="list-disc pl-4 space-y-1">
            <li><strong>Daily Neural Link (每日登入):</strong> Initiating connection to standard operator servers once per day allocates a high-vibe link bonus of <span className="text-[#ff4242] font-bold">600 Orundum (合成玉)</span>.</li>
            <li><strong>Operation Synchronizations (完成學習計劃):</strong> Completing a customized tactical training run awards <span className="text-[#00e0b3] font-bold">+10 Orundum (合成玉)</span> for each correct answer multiplied by the difficulty index (<span className="text-[#00e0b3] font-bold">100% / 110% / 120% / 130%</span>, 答對每題 +10，並根據分析等級係數加成，於完成後發放).</li>
            <li><strong>Skin Dynamic Recalibrations:</strong> Purchased visual skins automatically re-dye layout highlights dynamically and safe-injects ambient styling elements.</li>
          </ul>
        </div>
      </footer>
    </div>
  );
}
