import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  User, Award, ShieldCheck, Flame, Cpu, Sparkles, CheckCircle2, Lock, ShoppingBag, 
  HelpCircle, Archive, Paintbrush, Calendar, TrendingUp, History, Compass, ArrowRight, RefreshCw, Dices
} from 'lucide-react';
import { UserProgress } from '../types';
import AvatarWithFrame, { AVATAR_FRAMES } from './AvatarWithFrame';
import { GACHA_AVATARS } from '../avatarData';
import { SHOP_SKINS } from './Shop';
import { SOUVENIRS } from './Shop';
import { TACTICAL_BADGES } from '../data';

interface ProfileProps {
  progress: UserProgress;
  currentUser: string;
  onUpdateProgress: (updated: UserProgress) => void;
  onNavigateToShop: () => void;
}

export default function Profile({
  progress,
  currentUser,
  onUpdateProgress,
  onNavigateToShop
}: ProfileProps) {
  const [activeSubTab, setActiveSubTab] = useState<'AVATARS' | 'FRAMES' | 'SKINS' | 'SOUVENIRS' | 'BADGES'>('AVATARS');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Fallback defaults for progress values
  const ownedFrames = progress.ownedFrames || ['CLASSIC'];
  const activeFrame = progress.activeFrame || 'CLASSIC';
  const ownedSkins = progress.ownedSkins || ['CLASSIC'];
  const activeSkin = progress.activeSkin || 'CLASSIC';
  const ownedSouvenirs = progress.ownedSouvenirs || [];
  const orundum = progress.orundum !== undefined ? progress.orundum : 1200;
  const ownedAvatars = progress.ownedAvatars || ['DEFAULT'];
  const activeAvatar = progress.activeAvatar || 'DEFAULT';

  const currentStreak = progress.currentStreak || 0;
  const combatEfficiency = progress.combatEfficiency || 0;
  const reEducationCount = progress.reEducationCount || 0;
  const totalAttempts = progress.totalAttempts || 0;
  const correctAttempts = progress.correctAttempts || 0;

  const showFeedback = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => {
      setFeedback(null);
    }, 4000);
  };

  const handleEquipAvatar = (avatarId: string) => {
    if (!ownedAvatars.includes(avatarId)) {
      showFeedback(`ERROR: AVATAR [${avatarId}] IS LOCKED // 錯誤：該頭像尚未解鎖。`);
      return;
    }
    const updated: UserProgress = {
      ...progress,
      activeAvatar: avatarId
    };
    onUpdateProgress(updated);
    if (avatarId === 'DEFAULT') {
      showFeedback(`RESET AVATAR TO STANDARD // 恢復默認羅德島通訊頭像。`);
    } else {
      const av = GACHA_AVATARS.find(a => a.id === avatarId);
      showFeedback(`ACTIVATED OPTIMIZED PROJECTION: [${av?.nameChinese || avatarId}] // 已裝配全新解鎖頭像。`);
    }
  };

  const handleEquipFrame = (frameId: string) => {
    if (!ownedFrames.includes(frameId)) {
      showFeedback(`ERROR: FRAME [${frameId}] NOT UNLOCKED IN VAULT // 錯誤：該頭像框尚未解鎖，請前往採購中心兌換。`);
      return;
    }
    const updated: UserProgress = {
      ...progress,
      activeFrame: frameId
    };
    onUpdateProgress(updated);
    const frameObj = AVATAR_FRAMES.find(f => f.id === frameId);
    showFeedback(`EQUIPPED AVATAR FRAME: [${frameObj?.nameChinese || frameId}] // 已成功更換頭像框。`);
  };

  const handleEquipSkin = (skinId: string) => {
    if (!ownedSkins.includes(skinId)) {
      showFeedback(`ERROR: SKIN [${skinId}] NOT UNLOCKED IN VAULT // 錯誤：該終端皮膚尚未解鎖，請前往採購中心兌換。`);
      return;
    }
    const updated: UserProgress = {
      ...progress,
      activeSkin: skinId
    };
    onUpdateProgress(updated);
    const skinObj = SHOP_SKINS.find(s => s.id === skinId);
    showFeedback(`TUNED COGNITIVE SPECTRUM TO: [${skinObj?.nameChinese || skinId}] // 界面UI皮膚更換成功。`);
  };

  const avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDZ6YNg8nUcZfJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJfaf6u8lJAVk31dqqxLgKyzHFqIhluOD5a2BU4y33e9DWb3jSwcEu";

  return (
    <div className="space-y-6 font-sans">
      
      {/* Header definition block */}
      <div className="border-l-4 border-[var(--theme-color,#00e0b3)] pl-6 py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl text-white font-bold tracking-tighter uppercase">
            OPERATOR ARCHIVES // 個人檔案
          </h2>
          <p className="text-[#b9cbc2] text-xs uppercase tracking-widest mt-1">
            Display operational intelligence telemetry, adjust visual avatar frames, dynamic HUD skins and souvenirs.
          </p>
        </div>

        {/* Dynamic Orundum readout */}
        <div className="bg-[#1c1b1b] border border-[#3a4a44] px-4 py-2 flex items-center gap-3 shadow-md self-start sm:self-center">
          <div className="text-xs uppercase tracking-widest text-[#b9cbc2]/50 font-mono">
            Orundum玉 // {orundum}
          </div>
        </div>
      </div>

      {/* Main Interactive Tactical Operator Card */}
      <div className="bg-[#121212] border border-[#3a4a44] relative overflow-hidden p-6 sm:p-8 flex flex-col md:flex-row gap-6 items-center md:items-start">
        
        {/* Futuristic grids */}
        <div className="absolute top-0 right-0 w-32 h-32 border-r border-[#3a4a44]/20 opacity-25 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-16 h-16 border-b border-[#3a4a44]/20 opacity-25 pointer-events-none" />
        <div className="absolute top-6 right-6 bg-[#00e0b3]/5 text-[8px] text-[var(--theme-color,#00e0b3)] font-mono px-2 py-0.5 border border-[#00e0b3]/20 tracking-wider">
          RHODES ISLAND CORE LOGISTICS // ID: 2026-NEXUS
        </div>

        {/* Large Avatar display wrapped with activeFrame */}
        <div className="relative shrink-0 select-none flex flex-col items-center">
          <AvatarWithFrame 
            avatarUrl={avatarUrl}
            activeFrameId={activeFrame}
            activeAvatarId={activeAvatar}
            size="xl"
          />
          <span className="text-[10px] mt-3 uppercase tracking-widest text-[#00e0b3] font-mono bg-[#00e0b3]/10 px-2 py-0.5 border border-[#00e0b3]/20">
            {AVATAR_FRAMES.find(f => f.id === activeFrame)?.nameChinese || "標準通訊框"}
          </span>
        </div>

        {/* Operator Profile information */}
        <div className="space-y-4 text-center md:text-left w-full">
          <div>
            <div className="flex flex-col md:flex-row md:items-center gap-2">
              <h3 className="text-2xl font-black text-white tracking-widest uppercase">
                {currentUser.toUpperCase()} // 博士
              </h3>
              <span className="self-center md:self-auto bg-[#ffb870]/10 border border-[#ffb870]/30 text-[#ffb870] font-mono text-[9px] tracking-widest px-2 py-0.5 uppercase">
                Level 2 Elite Promoted // 精英二
              </span>
            </div>
            <p className="text-xs text-[#b9cbc2]/60 mt-1 font-mono uppercase tracking-widest">
              Security Authority: Administrator // 羅德島最高指揮權限
            </p>
          </div>

          {/* Core learning record stats banner in bento style */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-[#191919] border border-[#3a4a44]/50 p-4 w-full">
            
            <div className="space-y-1">
              <span className="text-[9px] text-[#b9cbc2]/40 uppercase tracking-widest block font-bold">
                Combat Streak // 學習連勝
              </span>
              <div className="flex items-baseline gap-1">
                <Flame className="w-4 h-4 text-[#ff4b4b] self-center shrink-0" />
                <span className="text-xl font-bold font-mono text-white">{currentStreak}</span>
                <span className="text-[9px] text-[#b9cbc2]/60">天</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[9px] text-[#b9cbc2]/40 uppercase tracking-widest block font-bold">
                Synclink Ef. // 戰術效率
              </span>
              <div className="flex items-baseline gap-1">
                <TrendingUp className="w-4 h-4 text-[#00e0b3] self-center shrink-0" />
                <span className="text-xl font-bold font-mono text-white">{combatEfficiency}%</span>
              </div>
            </div>

            <div className="space-y-1 bg-[#252520]/20 border border-[#ffd700]/10 p-1.5 rounded-sm">
              <span className="text-[9px] text-[#ffd700]/70 uppercase tracking-widest block font-bold">
                COGNITIVE POINTS // 戰術積分
              </span>
              <div className="flex items-baseline gap-1">
                <Sparkles className="w-4 h-4 text-[#ffd700] self-center shrink-0 animate-pulse" />
                <span className="text-xl font-bold font-mono text-[#ffd700]">{progress.points !== undefined ? progress.points : 30}</span>
                <span className="text-[9px] text-[#b9cbc2]/60">分</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[9px] text-[#b9cbc2]/40 uppercase tracking-widest block font-bold">
                Telemetry Log // 探索題次
              </span>
              <div className="flex items-baseline gap-1">
                <Award className="w-4 h-4 text-[#ffd700] self-center shrink-0" />
                <span className="text-xl font-bold font-mono text-white">{totalAttempts}</span>
                <span className="text-[9px] text-[#b9cbc2]/60">回次</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[9px] text-[#b9cbc2]/40 uppercase tracking-widest block font-bold">
                Accuracy Rate // 答對概率
              </span>
              <div className="flex items-baseline gap-1">
                <ShieldCheck className="w-4 h-4 text-[#cc55ff] self-center shrink-0" />
                <span className="text-xl font-bold font-mono text-white">
                  {totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 0}%
                </span>
              </div>
            </div>

          </div>

          <div className="text-[11px] font-mono text-[#b9cbc2]/70 leading-relaxed">
            <span className="text-[#00e0b3] font-bold">// SYSTEM REPORT:</span> 當前神經認知同步完整度優化在案。未解鎖高階單詞已轉交 PRTS 作戰中繼終端。隨時可通过採購中心獲取高熱模組提升與聲望外框。
          </div>
        </div>

      </div>

      {/* Profile subsections feedback */}
      {feedback && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3.5 bg-[#171717] border-l-2 border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] font-mono text-xs leading-relaxed uppercase flex items-center gap-2 shadow-lg"
        >
          <Sparkles className="w-4 h-4 text-[var(--theme-color,#00e0b3)] animate-pulse shrink-0" />
          <span>{feedback}</span>
        </motion.div>
      )}

      {/* Tabs segment: 0. Avatar Selection, 1. User Avatar Frame, 2. Interface UI Skin, 3. Souvenirs buttons */}
      <div className="flex flex-wrap border-b border-[#3a4a44]/55 bg-[#121212]">
        
        {/* TAB 0: TACTICAL AVATARS */}
        <button
          onClick={() => setActiveSubTab('AVATARS')}
          className={`flex-1 sm:flex-initial px-6 py-3.5 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center justify-center gap-2 ${
            activeSubTab === 'AVATARS'
              ? 'border-[#00ffd8] text-[#00ffd8] bg-[#00ffd8]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <Dices className="w-4 h-4 text-[#00ffd8]" />
          <span>AVATARS // 戰術頭像 ({ownedAvatars.length - 1})</span>
        </button>

        {/* TAB 1: AVATAR FRAMES */}
        <button
          onClick={() => setActiveSubTab('FRAMES')}
          className={`flex-1 sm:flex-initial px-6 py-3.5 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center justify-center gap-2 ${
            activeSubTab === 'FRAMES'
              ? 'border-[#ffd700] text-[#ffd700] bg-[#ffd700]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <User className="w-4 h-4 text-[#ffd700]" />
          <span>AVATAR FRAMES // 頭像外框 ({ownedFrames.length})</span>
        </button>

        {/* TAB 2: UI SKINS */}
        <button
          onClick={() => setActiveSubTab('SKINS')}
          className={`flex-1 sm:flex-initial px-6 py-3.5 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center justify-center gap-2 ${
            activeSubTab === 'SKINS'
              ? 'border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <Paintbrush className="w-4 h-4 text-[var(--theme-color,#00e0b3)]" />
          <span>UI SKINS // 界面UI皮膚 ({ownedSkins.length})</span>
        </button>

        {/* TAB 3: SOUVENIRS */}
        <button
          onClick={() => setActiveSubTab('SOUVENIRS')}
          className={`flex-1 sm:flex-initial px-6 py-3.5 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center justify-center gap-2 ${
            activeSubTab === 'SOUVENIRS'
              ? 'border-[#ffb870] text-[#ffb870] bg-[#ffb870]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <Archive className="w-4 h-4 text-[#ffb870]" />
          <span>SOUVENIRS // 紀念品庫 ({ownedSouvenirs.length})</span>
        </button>

        {/* TAB 4: BADGES */}
        <button
          onClick={() => setActiveSubTab('BADGES')}
          className={`flex-1 sm:flex-initial px-6 py-3.5 font-mono text-xs font-bold tracking-widest uppercase cursor-pointer transition-all border-b-2 flex items-center justify-center gap-2 ${
            activeSubTab === 'BADGES'
              ? 'border-[#00ffd8] text-[#00ffd8] bg-[#00ffd8]/5'
              : 'border-transparent text-[#b9cbc2]/50 hover:text-white hover:bg-[#1c1b1b]'
          }`}
        >
          <Award className="w-4 h-4 text-[#00ffd8]" />
          <span>BADGES // 戰術徽章 ({(progress.unlockedBadges || ['INIT_LINK']).length})</span>
        </button>

      </div>

      {/* TAB CONTENTS */}
      <div className="bg-[#121212]/30 border border-[#3a4a44]/60 p-6">

        {/* 0. ARCHIVE AVATARS GRID & EQUIPPING */}
        {activeSubTab === 'AVATARS' && (
          <div className="space-y-6">
            <div className="text-xs font-mono text-[#b9cbc2]/60 uppercase tracking-widest flex items-center justify-between flex-wrap gap-2">
              <span>ACTIVE USER AVATAR DETECTED // 當前戰術投影: {activeAvatar === 'DEFAULT' ? '標配通訊頭像' : GACHA_AVATARS.find(a => a.id === activeAvatar)?.nameChinese}</span>
              <span className="text-[#00e0b3] cursor-pointer hover:underline" onClick={onNavigateToShop}>
                ACCESS PRTS RECRUITMENT INTERFACE // 前往解碼抽獎池 &rarr;
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Default option */}
              <div 
                className={`p-4 border transition-all flex items-center gap-4 relative overflow-hidden ${
                  activeAvatar === 'DEFAULT' 
                    ? 'border-2 border-[#00ffd8] bg-[#00ffd8]/5' 
                    : 'border-[#3a4a44] bg-[#141414] hover:border-[#b9cbc2]/30'
                }`}
              >
                <div className="w-14 h-14 shrink-0 flex items-center justify-center bg-[#171717] relative">
                  <AvatarWithFrame 
                    avatarUrl={avatarUrl}
                    activeFrameId={activeFrame}
                    activeAvatarId="DEFAULT"
                    size="sm"
                  />
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-white uppercase tracking-wider">標配通訊頭像</span>
                    <span className="text-[8px] bg-gray-600 text-white font-mono px-1 py-0.5">DEFAULT</span>
                  </div>
                  <p className="text-[10px] text-[#b9cbc2]/60 font-sans">羅德島製式通訊終端上傳的初始圖像。</p>
                </div>
                <div className="shrink-0">
                  {activeAvatar === 'DEFAULT' ? (
                    <span className="text-[9px] text-[#00ffd8] font-mono tracking-widest font-black uppercase">EQUIPPED</span>
                  ) : (
                    <button
                      onClick={() => handleEquipAvatar('DEFAULT')}
                      className="cursor-pointer text-[10px] text-white hover:text-black border border-[#b9cbc2]/40 bg-zinc-900 hover:bg-white px-2.5 py-1.5 font-mono tracking-widest-sm"
                    >
                      EQUIP // 裝配
                    </button>
                  )}
                </div>
              </div>

              {GACHA_AVATARS.map((av) => {
                const isOwned = ownedAvatars.includes(av.id);
                const isActive = activeAvatar === av.id;

                return (
                  <div 
                    key={av.id}
                    className={`p-4 border transition-all flex items-center gap-4 relative overflow-hidden ${
                      isActive 
                        ? 'border-2 border-[#00ffd8] bg-[#00ffd8]/5' 
                        : isOwned 
                          ? 'border-[#3a4a44] bg-[#141414] hover:border-[#b9cbc2]/30' 
                          : 'border-[#3a4a44]/20 bg-[#121212]/30 opacity-40'
                    }`}
                  >
                    <div className="w-14 h-14 shrink-0 flex items-center justify-center bg-[#171717] relative">
                      <AvatarWithFrame 
                        avatarUrl={avatarUrl}
                        activeFrameId={activeFrame}
                        activeAvatarId={isOwned ? av.id : 'DEFAULT'}
                        size="sm"
                      />
                    </div>

                    <div className="flex-1 space-y-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs uppercase font-black text-white tracking-widest truncate">
                          {av.nameChinese}
                        </span>
                        {isActive && (
                          <span className="text-[8px] bg-[#00ffd8] text-black font-black px-1 leading-none uppercase shrink-0">
                            ON
                          </span>
                        )}
                        {!isOwned && (
                          <span className="text-[8px] bg-[#93000a]/10 border border-[#ffb4ab]/30 text-[#ffb4ab] font-black px-1.5 py-0.5 leading-none uppercase tracking-wider flex items-center gap-0.5 shrink-0 select-none">
                            <Lock className="w-2.5 h-2.5" /> LOCKED
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 font-mono text-[9px]">
                        <span 
                          className="font-bold uppercase tracking-wider text-[8px] px-1 py-0.5 rounded-[1px]" 
                          style={{ color: av.color, backgroundColor: `${av.color}15`, border: `1px solid ${av.color}35` }}
                        >
                          {av.rarityChinese}
                        </span>
                        <span className="text-[#b9cbc2]/40 truncate">{av.name}</span>
                      </div>

                      <p className="text-[10px] text-[#b9cbc2]/60 line-clamp-1 leading-normal font-sans">
                        {isOwned ? av.descriptionChinese : '解鎖此節點即可載入中樞頻譜。'}
                      </p>
                    </div>

                    <div className="shrink-0">
                      {isActive ? (
                        <span className="text-[9px] text-[#00ffd8] font-mono tracking-widest font-black uppercase">ACTIVE</span>
                      ) : isOwned ? (
                        <button
                          onClick={() => handleEquipAvatar(av.id)}
                          className="cursor-pointer text-[10px] border border-[#ffd700] text-[#ffd700] bg-zinc-950 hover:bg-[#ffd700] hover:text-black px-2.5 py-1.5 font-mono tracking-widest-sm"
                        >
                          EQUIP // 裝配
                        </button>
                      ) : (
                        <span className="text-[9px] text-[#b9cbc2]/30 font-mono tracking-widest uppercase">LOCKED</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 1. ARCHIVE FRAMES GRID & EQUIPPING */}
        {activeSubTab === 'FRAMES' && (
          <div className="space-y-6">
            <div className="text-xs font-mono text-[#b9cbc2]/60 uppercase tracking-widest flex items-center justify-between">
              <span>ACTIVE PROFILE FRAME: {AVATAR_FRAMES.find(f => f.id === activeFrame)?.nameChinese}</span>
              <span className="text-[#00e0b3] cursor-pointer hover:underline" onClick={onNavigateToShop}>
                PURCHASE MORE AT SHOP // 採購全新頭像框 &rarr;
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {AVATAR_FRAMES.map((frame) => {
                const isOwned = ownedFrames.includes(frame.id);
                const isActive = activeFrame === frame.id;

                return (
                  <div 
                    key={frame.id}
                    className={`p-4 border transition-all flex items-center gap-4 relative overflow-hidden ${
                      isActive 
                        ? 'border-2 border-[#ffd700] bg-[#ffd700]/5' 
                        : isOwned 
                          ? 'border-[#3a4a44] bg-[#141414] hover:border-[#b9cbc2]/30' 
                          : 'border-[#3a4a44]/30 bg-[#121212]/50 opacity-60'
                    }`}
                  >
                    
                    {/* Visual frame preview */}
                    <div className="w-14 h-14 shrink-0 flex items-center justify-center bg-[#171717] relative">
                      <AvatarWithFrame 
                        avatarUrl={avatarUrl}
                        activeFrameId={frame.id}
                        size="sm"
                      />
                    </div>

                    {/* Frame descriptions */}
                    <div className="flex-1 space-y-1.5 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs uppercase font-black text-white tracking-widest leading-none truncate">
                          {frame.name}
                        </span>
                        {isActive && (
                          <span className="text-[8px] bg-[#ffd700] text-black font-black px-1.5 py-0.5 leading-none uppercase tracking-wider">
                            ACTIVE // 啟用中
                          </span>
                        )}
                        {!isOwned && (
                          <span className="text-[8px] bg-[#93000a]/10 border border-[#ffb4ab]/30 text-[#ffb4ab] font-black px-1 py-0.5 leading-none uppercase tracking-wider flex items-center gap-0.5">
                            <Lock className="w-2.5 h-2.5" /> LOCKED
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] font-bold text-[#b9cbc2]" style={{ color: frame.borderColor }}>
                        {frame.nameChinese}
                      </p>
                      <p className="text-[10px] text-[#b9cbc2]/60 leading-tight">
                        {frame.descriptionChinese}
                      </p>
                    </div>

                    {/* Action Equip button or unlock trigger */}
                    <div className="shrink-0 self-center">
                      {isActive ? (
                        <span className="text-[9px] text-[#ffd700] font-mono tracking-widest font-black uppercase">
                          EQUIPPED
                        </span>
                      ) : isOwned ? (
                        <button
                          onClick={() => handleEquipFrame(frame.id)}
                          className="cursor-pointer text-[10px] hover:text-[#002118] px-3 py-1.5 border border-[#ffd700] text-[#ffd700] hover:bg-[#ffd700] font-mono tracking-wider font-bold"
                        >
                          EQUIP // 使用
                        </button>
                      ) : (
                        <button
                          onClick={onNavigateToShop}
                          className="cursor-pointer text-[10px] px-3 py-1.5 border border-[#ff4242]/50 text-[#ff4242] hover:bg-[#ff4242] hover:text-white font-mono tracking-wider font-bold flex items-center gap-1"
                        >
                          {frame.price}玉
                        </button>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. UI SKINS TAB - LIST OWNED & SWITCH ON-DEMAND */}
        {activeSubTab === 'SKINS' && (
          <div className="space-y-6">
            <div className="text-xs font-mono text-[#b9cbc2]/60 uppercase tracking-widest flex items-center justify-between">
              <span>ACTIVE SYSTEM HIGHLIGHT SPECTRUM: {SHOP_SKINS.find(s => s.id === activeSkin)?.nameChinese}</span>
              <span className="text-[#00e0b3] cursor-pointer hover:underline" onClick={onNavigateToShop}>
                PURCHASE MORE SKINS AT PROCUREMENT &rarr;
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {SHOP_SKINS.map((skin) => {
                const isOwned = ownedSkins.includes(skin.id);
                const isActive = activeSkin === skin.id;

                return (
                  <div 
                    key={skin.id}
                    className={`p-4 border transition-all flex items-center gap-4 relative overflow-hidden ${
                      isActive 
                        ? 'border-2 border-[var(--theme-color,#00e0b3)] bg-[#00e0b3]/5' 
                        : isOwned 
                          ? 'border-[#3a4a44] bg-[#141414] hover:border-[#b9cbc2]/30' 
                          : 'border-[#3a4a44]/30 bg-[#121212]/50 opacity-60'
                    }`}
                  >
                    
                    {/* Circle Color Accent Indicator */}
                    <div 
                      className="w-10 h-10 border border-white/10 shrink-0 flex items-center justify-center relative"
                      style={{ backgroundColor: `${skin.primaryColor}15` }}
                    >
                      <div className="w-5 h-5 rounded-full" style={{ backgroundColor: skin.primaryColor }} />
                    </div>

                    {/* Skin description */}
                    <div className="flex-1 space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs uppercase font-black text-white tracking-widest truncate">
                          {skin.name}
                        </span>
                        {isActive && (
                          <span className="text-[8px] bg-[var(--theme-color,#00e0b3)] text-[#002118] font-black px-1.5 py-0.5 leading-none uppercase tracking-wider">
                            ACTIVE
                          </span>
                        )}
                        {!isOwned && (
                          <span className="text-[8px] bg-[#93000a]/10 border border-[#ffb4ab]/30 text-[#ffb4ab] font-black px-1 py-0.5 leading-none uppercase tracking-wider flex items-center gap-0.5">
                            <Lock className="w-2.5 h-2.5" /> LOCKED
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] font-bold text-[#b9cbc2]">
                        {skin.nameChinese}
                      </p>
                      <p className="text-[10px] text-[#b9cbc2]/60 line-clamp-1">
                        {skin.description}
                      </p>
                    </div>

                    {/* Equip switch button */}
                    <div className="shrink-0 self-center">
                      {isActive ? (
                        <span className="text-[9px] text-[var(--theme-color,#00e0b3)] font-mono tracking-widest font-black uppercase">
                          EQUIPPED
                        </span>
                      ) : isOwned ? (
                        <button
                          onClick={() => handleEquipSkin(skin.id)}
                          className="cursor-pointer text-[10px] hover:text-[#002118] px-3 py-1.5 border border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] hover:bg-[var(--theme-color,#00e0b3)] font-mono tracking-wider font-bold"
                        >
                          EQUIP // 裝配
                        </button>
                      ) : (
                        <button
                          onClick={onNavigateToShop}
                          className="cursor-pointer text-[10px] px-3 py-1.5 border border-[#ff4242]/50 text-[#ff4242] hover:bg-[#ff4242] hover:text-white font-mono tracking-wider font-bold"
                        >
                          {skin.price}玉
                        </button>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. SOUVENIRS DISPLAY PANEL */}
        {activeSubTab === 'SOUVENIRS' && (
          <div className="space-y-6">
            <div className="text-xs font-mono text-[#b9cbc2]/60 uppercase tracking-widest flex items-center justify-between">
              <span>COLLECTED MEMORY SOUVENIRS ({ownedSouvenirs.length} / {SOUVENIRS.length})</span>
              <span className="text-[#00e0b3] cursor-pointer hover:underline" onClick={onNavigateToShop}>
                EXCHANGE ARCHIVES AT PROCUREMENT CENTER &rarr;
              </span>
            </div>

            {ownedSouvenirs.length === 0 ? (
              <div className="p-8 border border-dashed border-[#3a4a44] text-center text-xs font-mono text-[#b9cbc2]/40 space-y-4 rounded-sm">
                <HelpCircle className="w-8 h-8 text-[#b9cbc2]/20 mx-auto animate-bounce-slow" />
                <p>NO VALUABLE HISTORIC MEMORY LABELS SECURED IN VAULT // 您的紀念密室目前空空如也。</p>
                <button
                  onClick={onNavigateToShop}
                  className="cursor-pointer text-[11px] px-4 py-2 border border-[#ffb870] text-[#ffb870] hover:bg-[#ffb870] hover:text-black font-bold uppercase tracking-widest transition-all"
                >
                  Retrieve First Artifact // 獲取第一件紀念品
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {SOUVENIRS.filter(item => ownedSouvenirs.includes(item.id)).map((item) => (
                  <div 
                    key={item.id}
                    className="p-4 border border-[#ffd700]/30 bg-[#ffd700]/[0.01] hover:border-[#ffd700]/60 relative overflow-hidden flex flex-col justify-between"
                  >
                    <div className="absolute top-2 right-2 text-[#ffb870] font-mono text-[8px] font-bold tracking-widest">
                      {item.rarity}★ VALUABLE
                    </div>

                    <div className="space-y-3">
                      <div className="space-y-1">
                        <h4 className="text-xs font-black text-white uppercase tracking-wider">
                          {item.name}
                        </h4>
                        <p className="text-[10px] text-[#ffd700] font-bold font-mono">
                          {item.nameChinese}
                        </p>
                      </div>

                      <p className="text-[10px] text-[#b9cbc2] leading-relaxed italic border-l border-[#3a4a44] pl-2">
                        "{item.description}"
                      </p>
                      <p className="text-[10px] text-[#b9cbc2]/70 leading-normal">
                        {item.descriptionChinese}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#3a4a44]/30 mt-4 flex items-center justify-between">
                      <span className="text-[9px] text-[#ffb870] font-mono tracking-widest font-black uppercase">
                        IN_VAULT // 永久珍藏
                      </span>
                      <span className="text-[8px] bg-[#111] border border-[#3a4a44]/50 text-[#b9cbc2]/55 px-1.5 py-0.5 uppercase tracking-wider font-mono">
                        SECURED_ID_{item.id}
                      </span>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 4. TACTICAL BADGES DISPLAY GRID */}
        {activeSubTab === 'BADGES' && (
          <div className="space-y-6">
            <div className="text-xs font-mono text-[#b9cbc2]/60 uppercase tracking-widest flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-[#3a4a44]/35 pb-3">
              <span>TACTICAL MILESTONE SHIELDS // 戰術榮譽勳章 ({(progress.unlockedBadges || ['INIT_LINK']).length} / {TACTICAL_BADGES.length})</span>
              <span className="text-[var(--theme-color,#00e0b3)] font-semibold">
                COMPLETE TELEMETRY QUIZZES TO UNLOCK MORE // 積極參與演練以鎖定高階戰力認證
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {TACTICAL_BADGES.map((badge) => {
                const isUnlocked = (progress.unlockedBadges || ['INIT_LINK']).includes(badge.id);
                
                // Map Lucide icons dynamically
                let IconElement = Award;
                if (badge.iconName === 'Sparkles') IconElement = Sparkles;
                else if (badge.iconName === 'Flame') IconElement = Flame;
                else if (badge.iconName === 'Crown') IconElement = Cpu;
                else if (badge.iconName === 'BookOpen') IconElement = HelpCircle;
                else if (badge.iconName === 'Shield') IconElement = ShieldCheck;
                else if (badge.iconName === 'Trophy') IconElement = Award;
                else if (badge.iconName === 'Activity') IconElement = TrendingUp;
                else if (badge.iconName === 'Coins') IconElement = ShoppingBag;

                return (
                  <div 
                    key={badge.id}
                    className={`p-4 border transition-all flex flex-col justify-between relative overflow-hidden rounded-sm ${
                      isUnlocked 
                        ? 'bg-[#141414] hover:shadow-[0_0_15px_rgba(0,224,179,0.05)]' 
                        : 'border-[#3a4a44]/20 bg-[#121212]/50 opacity-60'
                    }`}
                    style={{ borderColor: isUnlocked ? badge.borderColor : '#212a26' }}
                  >
                    {/* Top corner color dynamic banner */}
                    <div className="absolute top-0 right-0 w-8 h-8 opacity-25 pointer-events-none" 
                         style={{ background: isUnlocked ? `linear-gradient(135deg, transparent 50%, ${badge.borderColor} 50%)` : 'transparent' }} />
                    
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        {/* Custom decorative outer frame based on unlock state */}
                        <div 
                          className={`w-12 h-12 border shrink-0 flex items-center justify-center relative rounded-md transition-all ${
                            isUnlocked ? 'bg-[#181818]' : 'bg-[#111] border-[#3a4a44]/40 text-[#b9cbc2]/30'
                          }`}
                          style={{ borderColor: isUnlocked ? badge.borderColor : '#3a4a44/40', color: isUnlocked ? badge.borderColor : '#b9cbc2/30' }}
                        >
                          {isUnlocked ? (
                            <IconElement className="w-6 h-6 animate-pulse" style={{ color: badge.borderColor }} />
                          ) : (
                            <Lock className="w-5 h-5 text-gray-600" />
                          )}
                        </div>

                        <div className="space-y-1.5 min-w-0 flex-1">
                          <span className="text-[9px] font-mono tracking-widest text-[#b9cbc2]/50 uppercase leading-none block">
                            {badge.name}
                          </span>
                          <h4 className="text-sm font-black text-white leading-tight uppercase tracking-wider block">
                            {badge.nameChinese}
                          </h4>
                        </div>
                      </div>

                      <div className="space-y-1 text-xs">
                        <p className={isUnlocked ? 'text-[#e5e2e1]' : 'text-[#b9cbc2]/40'}>
                          {badge.descriptionChinese}
                        </p>
                        <p className="text-[10px] text-[#b9cbc2]/50 italic pl-2 border-l border-[#3a4a44]/60 leading-relaxed mt-1">
                          "{badge.description}"
                        </p>
                      </div>
                    </div>

                    {/* Bottom unlock conditions */}
                    <div className="pt-3 border-t border-[#3a4a44]/30 mt-5 flex items-center justify-between font-mono text-[9px] tracking-wide">
                      {isUnlocked ? (
                        <span className="font-extrabold uppercase flex items-center gap-1.5" style={{ color: badge.borderColor }}>
                          <CheckCircle2 className="w-3.5 h-3.5" /> SYNCED // 已授勳
                        </span>
                      ) : (
                        <span className="text-[#ff4e4e]/70 font-semibold uppercase flex items-center gap-1.5">
                          <Lock className="w-3.5 h-3.5" /> LOCKED // 待解鎖
                        </span>
                      )}
                      
                      <span className="text-[9px] text-[#b9cbc2]/50 truncate max-w-[160px]" title={badge.requirementTextChinese}>
                        {badge.requirementTextChinese}
                      </span>
                    </div>

                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>

    </div>
  );
}
