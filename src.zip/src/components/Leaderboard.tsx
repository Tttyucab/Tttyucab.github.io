import { useState, useEffect } from 'react';
import { Award, ShieldCheck, Flame, RefreshCw, Sparkles, BookOpen, User, Coins, ChevronRight, Swords, Trophy, Activity, Radio, X } from 'lucide-react';
import { UserProgress, WordLevel } from '../types';
import AvatarWithFrame from './AvatarWithFrame';

interface LeaderboardProps {
  progress: UserProgress;
  currentUser: string | null;
  onStartChallenge: (level: WordLevel) => void;
}

interface LeaderboardEntry {
  username: string;
  isCurrentUser: boolean;
  orundum: number;
  combatEfficiency: number;
  masteredWordsCount: number;
  currentStreak: number;
  title: string;
  quote: string;
  levelCode: string;
  avatarChar: string;
  points?: number;
  badgeCount?: number;
}

export default function Leaderboard({ progress, currentUser, onStartChallenge }: LeaderboardProps) {
  const [boardType, setBoardType] = useState<'ORUNDUM' | 'EFFICIENCY' | 'MASTERY' | 'POINTS'>('POINTS');
  const [leaderboardList, setLeaderboardList] = useState<LeaderboardEntry[]>([]);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [selectedEntry, setSelectedEntry] = useState<LeaderboardEntry | null>(null);

  const calculateFullList = () => {
    // 1. Gather simulated Rhodes Island operators
    const list: LeaderboardEntry[] = [];

    // 2. Fetch actually registered other local storage accounts
    const localUsersRaw = localStorage.getItem('lexiquiz_tactical_users');
    if (localUsersRaw) {
      try {
        const localUsers = JSON.parse(localUsersRaw);
        localUsers.forEach((u: { username: string }) => {
          const normName = u.username.trim();
          if (normName.toUpperCase() === 'DEVELOPER') {
            return;
          }
          
          // Retrieve progress for this local account
          const savedProgRaw = localStorage.getItem(`lexiquiz_tactical_progress_${normName}`);
          let savedProg: UserProgress;
          if (savedProgRaw) {
            savedProg = JSON.parse(savedProgRaw);
          } else {
            savedProg = {
              orundum: 1200,
              points: 30,
              completedWordIds: [],
              currentStreak: 0,
              totalAttempts: 0,
              correctAttempts: 0,
              unlockedBadges: ['INIT_LINK'],
              activeFrame: 'CLASSIC',
              missedWords: {},
              lastSyncTimes: {},
              combatEfficiency: 0,
              reEducationCount: 0
            };
          }
          const isMe = currentUser?.toUpperCase() === normName.toUpperCase();
          
          // Check if player is already included
          const alreadyExists = list.some(entry => entry.username.toUpperCase() === normName.toUpperCase());
          if (!alreadyExists) {
            const totalAtt = savedProg.totalAttempts || 0;
            const corrAtt = savedProg.correctAttempts || 0;
            let calcEfficiency = 0;
            if (totalAtt > 0) {
              calcEfficiency = Math.round((corrAtt / totalAtt) * 100);
            }

            list.push({
              username: u.username,
              isCurrentUser: isMe,
              orundum: savedProg.orundum !== undefined ? savedProg.orundum : 1200,
              combatEfficiency: calcEfficiency,
              masteredWordsCount: savedProg.completedWordIds ? savedProg.completedWordIds.length : 0,
              currentStreak: savedProg.currentStreak || 0,
              title: isMe ? "DOCTOR // 核心通訊鏈接操作員(您)" : "ASSOCIATE_DOCTOR // 協同聯合作戰助理",
              quote: isMe ? "這是我自己在此安全終端留存的神經同步戰術通訊協定。" : "共同追求認知升階、推進源石塵埃淨化計程。鏈接完好。",
              levelCode: "DOCTOR_PRO",
              avatarChar: (u.username[0] || "D").toUpperCase(),
              points: savedProg.points !== undefined ? savedProg.points : 30,
              badgeCount: savedProg.unlockedBadges ? savedProg.unlockedBadges.length : 1
            });
          }
        });
      } catch (err) {
        console.error('Failed reading registered users for leader board computation', err);
      }
    }

    // 3. Make sure current user's runtime statistics are accurately updated in the list!
    const activeNick = currentUser || "DOCTOR";
    const isDeveloper = activeNick.toUpperCase() === 'DEVELOPER';

    if (!isDeveloper) {
      const myEntryIdx = list.findIndex(e => e.isCurrentUser || e.username.toUpperCase() === activeNick.toUpperCase());
      
      // Compute current user dynamic metrics
      const totalAtt = progress.totalAttempts || 0;
      const corrAtt = progress.correctAttempts || 0;
      let dynamicEfficiency = 0;
      if (totalAtt > 0) {
        dynamicEfficiency = Math.round((corrAtt / totalAtt) * 100);
      }
      const currentOrundum = progress.orundum !== undefined ? progress.orundum : 1200;
      const myWordsCount = progress.completedWordIds ? progress.completedWordIds.length : 0;
      const myPoints = progress.points !== undefined ? progress.points : 30;
      const myBadges = progress.unlockedBadges ? progress.unlockedBadges.length : 1;

      const myNewEntry: LeaderboardEntry = {
        username: activeNick,
        isCurrentUser: true,
        orundum: currentOrundum,
        combatEfficiency: dynamicEfficiency,
        masteredWordsCount: myWordsCount,
        currentStreak: progress.currentStreak || 0,
        title: "DOCTOR // 核心通訊鏈接操作員(您)",
        quote: "當前在本終端建立連結構建。正在引領全體幹員進行神經認知同步培訓。",
        levelCode: "DOCTOR_PRO",
        avatarChar: (activeNick[0] || "D").toUpperCase(),
        points: myPoints,
        badgeCount: myBadges
      };

      if (myEntryIdx >= 0) {
        list[myEntryIdx] = myNewEntry;
      } else {
        list.push(myNewEntry);
      }
    }

    // Filter duplicates one last time just in case
    const uniqueMap = new Map<string, LeaderboardEntry>();
    list.forEach(entry => {
      const key = entry.username.toUpperCase();
      if (key === 'DEVELOPER') return;
      // Keep CurrentUser marker prioritised
      if (!uniqueMap.has(key) || entry.isCurrentUser) {
        uniqueMap.set(key, entry);
      }
    });

    const finalizedList = Array.from(uniqueMap.values());

    // Sort based on boardType
    finalizedList.sort((a, b) => {
      if (boardType === 'POINTS') {
        const pA = a.points !== undefined ? a.points : 30;
        const pB = b.points !== undefined ? b.points : 30;
        if (pB !== pA) return pB - pA;
        return b.combatEfficiency - a.combatEfficiency;
      } else if (boardType === 'ORUNDUM') {
        if (b.orundum !== a.orundum) return b.orundum - a.orundum;
        return b.combatEfficiency - a.combatEfficiency;
      } else if (boardType === 'EFFICIENCY') {
        if (b.combatEfficiency !== a.combatEfficiency) return b.combatEfficiency - a.combatEfficiency;
        return b.orundum - a.orundum;
      } else {
        if (b.masteredWordsCount !== a.masteredWordsCount) return b.masteredWordsCount - a.masteredWordsCount;
        return b.combatEfficiency - a.combatEfficiency;
      }
    });

    setLeaderboardList(finalizedList);
  };

  useEffect(() => {
    calculateFullList();
  }, [progress, currentUser, boardType]);

  const handleSyncClick = () => {
    setIsSyncing(true);
    // Simulate PRTS signal recalibration
    setTimeout(() => {
      calculateFullList();
      setIsSyncing(false);
    }, 1000);
  };

  return (
    <div className="space-y-6 max-w-[800px] mx-auto font-mono text-[#e5e2e1]">
      
      {/* Top Banner introducing telemetry ranking */}
      <section className="relative overflow-hidden bg-[#201f1f] border-b-2 border-b-[#00e0b3] p-5 sm:p-6 shadow-md rounded-none">
        <div className="absolute top-0 right-0 w-3 h-3 bg-[#0e0e0e] rotate-45 transform translate-x-1.5 -translate-y-1.5 border-b border-[#3a4a44]" />
        
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-[#00e0b3] text-xs font-bold uppercase tracking-widest">
              <Radio className="w-4 h-4 text-[#00e0b3] animate-pulse" />
              <span>PRTS // NETWORK LEADERBOARD</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-wider text-white">
              羅德島神經同步排行系统
            </h2>
            <p className="text-[#b9cbc2]/70 text-[10px] sm:text-[11px] leading-relaxed max-w-xl">
              本終端收集並記錄了目前所有鏈接 Rhodes Island PRTS 記憶矩陣演練之操作員的認知資料。
              數據會隨訓練完成、購物券消費情況和作戰演練動態刷新。
            </p>
          </div>

          <button
            onClick={handleSyncClick}
            disabled={isSyncing}
            className={`cursor-pointer px-4 py-2 border text-[11px] font-bold tracking-widest flex items-center gap-2 h-10 transition-all ${
              isSyncing 
                ? 'bg-transparent border-[#00e0b3]/30 text-[#00e0b3]/50' 
                : 'bg-[#1c1b1b] border-[#3a4a44] text-[#00e0b3] hover:border-[#00e0b3] hover:bg-[#141414]'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? "SYNC_REPORTS..." : "RECALIBRATE // 刷新排行"}</span>
          </button>
        </div>
      </section>

      {/* Selector Sorting Toggles */}
      <div className="flex bg-[#141414] border border-[#3a4a44]/60 p-1 sm:p-1.5 gap-1.5">
        <button
          onClick={() => setBoardType('POINTS')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold transition-all cursor-pointer ${
            boardType === 'POINTS'
              ? 'bg-[#00e0b3] text-[#002118] font-black'
              : 'text-[#b9cbc2] hover:bg-[#1c1b1b]'
          }`}
        >
          <Sparkles className="w-4 h-4 animate-pulse" />
          <span className="hidden sm:inline">COGNITIVE //</span> 戰術積分
        </button>
        <button
          onClick={() => setBoardType('ORUNDUM')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold transition-all cursor-pointer ${
            boardType === 'ORUNDUM'
              ? 'bg-[#00e0b3] text-[#002118] font-black'
              : 'text-[#b9cbc2] hover:bg-[#1c1b1b]'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span className="hidden sm:inline">ORUNDUM //</span> 合成玉存量
        </button>
        <button
          onClick={() => setBoardType('EFFICIENCY')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold transition-all cursor-pointer ${
            boardType === 'EFFICIENCY'
              ? 'bg-[#00e0b3] text-[#002118] font-black'
              : 'text-[#b9cbc2] hover:bg-[#1c1b1b]'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span className="hidden sm:inline">EFFICIENCY //</span> 戰術正確率
        </button>
        <button
          onClick={() => setBoardType('MASTERY')}
          className={`flex-1 flex items-center justify-center gap-4 py-2 px-3 text-xs font-bold transition-all cursor-pointer ${
            boardType === 'MASTERY'
              ? 'bg-[#00e0b3] text-[#002118] font-black'
              : 'text-[#b9cbc2] hover:bg-[#1c1b1b]'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span className="hidden sm:inline">MASTERY //</span> 已備字詞量
        </button>
      </div>

      {/* Main Leaderboard Rankings list container */}
      <div className="space-y-2.5">
        {leaderboardList.map((entry, index) => {
          const rank = index + 1;
          const isTop3 = rank <= 3;
          
          let rankBadge = '';
          let itemStyle = 'border-[#3a4a44] bg-[#1a1a1a]';
          let textStyle = 'text-[#e5e2e1]';

          if (entry.isCurrentUser) {
            itemStyle = 'border-[#00e0b3] bg-[#14231f] shadow-[inset_0_0_12px_rgba(0,224,179,0.08)]';
          } else if (rank === 1) {
            itemStyle = 'border-[#ffd700] bg-[#1d1b11] shadow-[inset_0_0_10px_rgba(255,215,0,0.05)]';
            rankBadge = '🥇';
          } else if (rank === 2) {
            itemStyle = 'border-[#c0c0c0] bg-[#161717]';
            rankBadge = '🥈';
          } else if (rank === 3) {
            itemStyle = 'border-[#cd7f32] bg-[#181513]';
            rankBadge = '🥉';
          }

          return (
            <div
              key={entry.username}
              className={`p-3.5 sm:p-4 border relative overflow-hidden transition-all flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 group ${itemStyle}`}
            >
              
              {/* Highlight background lines for currentUser */}
              {entry.isCurrentUser && (
                <div className="absolute top-0 right-0 h-full w-1.5 bg-[#00e0b3] animate-pulse" />
              )}
              
              {/* Left Rank + Avatar + Name Details */}
              <div className="flex items-center gap-3.5 flex-1 min-w-0">
                
                {/* Ranking Position Badge */}
                <div className="w-10 flex items-center justify-center font-sans">
                  {isTop3 ? (
                    <span className="text-xl">{rankBadge}</span>
                  ) : (
                    <span className="font-mono text-xs text-[#b9cbc2]/40 font-bold bg-[#141414] px-2.5 py-1 border border-[#3a4a44]/40">
                      #{rank}
                    </span>
                  )}
                </div>

                {/* Avatar Icon */}
                {entry.isCurrentUser ? (
                  <div className="shrink-0 overflow-visible scale-95 pr-1">
                    <AvatarWithFrame 
                      avatarUrl="https://lh3.googleusercontent.com/aida-public/AB6AXuDZ6YNg8nUcZfJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJfaf6u8lJAVk31dqqxLgKyzHFqIhluOD5a2BU4y33e9DWb3jSwcEu"
                      activeFrameId={progress.activeFrame || 'CLASSIC'}
                      activeAvatarId={progress.activeAvatar || 'DEFAULT'}
                      size="md"
                    />
                  </div>
                ) : (
                  <div className={`w-10 h-10 border shrink-0 flex items-center justify-center text-sm font-bold shadow-inner ${
                    isTop3 
                      ? rank === 1 ? 'bg-[#ffd700]/10 border-[#ffd700] text-[#ffd700]' : 'bg-[#252525] border-[#b9cbc2]/50 text-white'
                      : 'bg-[#141414] border-[#3a4a44]/60 text-[#b9cbc2]/80'
                  }`}>
                    {entry.avatarChar}
                  </div>
                )}

                {/* Operator Identity text */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm tracking-wide font-bold font-sans truncate ${
                      entry.isCurrentUser ? 'text-[#00e0b3]' : 'text-white hover:text-[#00e0b3] transition-colors cursor-pointer'
                    }`}
                    onClick={() => setSelectedEntry(entry)}
                    >
                      {entry.username}
                    </span>
                    {entry.isCurrentUser && (
                      <span className="bg-[#00e0b3] text-[#002118] text-[8px] px-1 py-0.5 font-mono font-black scale-90 tracking-tighter">
                        YOU // 本機
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-[#b9cbc2]/50 lowercase truncate block mt-0.5 font-mono leading-none">
                    {entry.title}
                  </span>
                </div>
              </div>

              {/* Statistics Metrics segment columns */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center md:text-right shrink-0 font-mono text-xs w-full md:w-auto">
                
                {/* Cognitive Points */}
                <div className={`border md:border-0 border-[#3a4a44]/30 px-2 py-1.5 rounded-sm ${boardType === 'POINTS' ? 'bg-[#ffd700]/10 border-[#ffd700]/40' : 'bg-[#121212] md:bg-transparent'}`}>
                  <span className="block md:hidden text-[9px] text-[#b9cbc2]/40 uppercase tracking-tighter mb-0.5">POINTS</span>
                  <div className="flex items-center justify-center md:justify-end gap-1 text-[#ffd700]">
                    <Sparkles className="w-3 h-3 animate-pulse" />
                    <span className="font-bold">{entry.points !== undefined ? entry.points : 30} Pt</span>
                  </div>
                </div>

                {/* Synthesized Orundum */}
                <div className={`border md:border-0 border-[#3a4a44]/30 px-2 py-1.5 rounded-sm ${boardType === 'ORUNDUM' ? 'bg-[#ffbf81]/10 border-[#ffbf81]/40' : 'bg-[#121212] md:bg-transparent'}`}>
                  <span className="block md:hidden text-[9px] text-[#b9cbc2]/40 uppercase tracking-tighter mb-0.5">ORUNDUM</span>
                  <div className="flex items-center justify-center md:justify-end gap-1 text-[#ffbf81]">
                    <Coins className="w-3 h-3" />
                    <span className="font-bold">{entry.orundum}</span>
                  </div>
                </div>

                {/* Correct Efficiency percentage */}
                <div className={`border md:border-0 border-[#3a4a44]/30 px-2 py-1.5 rounded-sm ${boardType === 'EFFICIENCY' ? 'bg-[#00e0b3]/10 border-[#00e0b3]/40' : 'bg-[#121212] md:bg-transparent'}`}>
                  <span className="block md:hidden text-[9px] text-[#b9cbc2]/40 uppercase tracking-tighter mb-0.5">ACCURACY</span>
                  <div className="flex items-center justify-center md:justify-end gap-1 text-[#00e0b3]">
                    <Activity className="w-3 h-3" />
                    <strong>{entry.combatEfficiency}%</strong>
                  </div>
                </div>

                {/* Mastered word loop segment counts */}
                <div className={`border md:border-0 border-[#3a4a44]/30 px-2 py-1.5 rounded-sm ${boardType === 'MASTERY' ? 'bg-[#00ffd8]/10 border-[#00ffd8]/40' : 'bg-[#121212] md:bg-transparent'}`}>
                  <span className="block md:hidden text-[9px] text-[#b9cbc2]/40 uppercase tracking-tighter mb-0.5">DICT_WORDS</span>
                  <div className="flex items-center justify-center md:justify-end gap-1 text-[#b9cbc2]">
                    <BookOpen className="w-3 h-3 text-[#00ffd8]" />
                    <span className="font-semibold">{entry.masteredWordsCount}字</span>
                  </div>
                </div>
              </div>

              {/* Action buttons (Profile Detail prompt) */}
              <div className="flex items-center gap-2 justify-end border-t md:border-t-0 border-[#3a4a44]/30 pt-2.5 md:pt-0 shrink-0">
                <button
                  onClick={() => setSelectedEntry(entry)}
                  className="px-2.5 py-1.5 border border-[#3a4a44] hover:border-[#00e0b3] hover:bg-[#141414] text-[10px] sm:text-[11px] leading-relaxed select-none transition-colors duration-150 cursor-pointer text-[#b9cbc2]/80 hover:text-white flex items-center gap-1.5"
                >
                  <User className="w-3 h-3 text-[#00e0b3]" />
                  <span>研擬對策</span>
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Target simulated combat challenge vectors */}
      <section className="bg-[#131313] border border-[#ffb4ab]/20 p-5 mt-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-2 h-2 bg-[#ffb4ab] opacity-20" />
        <div className="flex items-start gap-4 flex-col md:flex-row">
          <div className="p-2.5 bg-[#93000a]/10 border border-[#ffb4ab]/30 text-[#ffb4ab]">
            <Swords className="w-6 h-6 shrink-0" />
          </div>
          <div className="space-y-2 flex-1">
            <h3 className="font-mono text-sm font-bold text-[#ffb4ab] tracking-wider uppercase">
              COGNITIVE ATTACK CHANNELS // 神經認知演練突破
            </h3>
            <p className="text-[#b9cbc2]/70 text-[11px] leading-relaxed font-sans">
              要突破並挑戰您個人的學習記錄极限，請直接開啟特定難度演練！
              完成對應難度更可獲得高額加權合成玉回報。
            </p>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[10px]">
              {(['BASIC', 'INTERMEDIATE', 'TOEIC', 'TOEFL'] as WordLevel[]).map((lv) => {
                let badgeCol = "border-[#3a4a44] text-[#b9cbc2]/80 hover:border-[#00e0b3] hover:text-white";
                if (lv === 'TOEFL') badgeCol = "border-[#ffb4ab]/40 text-[#ffb4ab] hover:bg-[#93000a]/25";
                
                return (
                  <button
                    key={lv}
                    onClick={() => onStartChallenge(lv)}
                    className={`cursor-pointer px-2.5 py-2 border text-center font-bold tracking-widest transition-all uppercase rounded-none ${badgeCol}`}
                  >
                    DEPLOY_{lv} SHIELD
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Operator detailed Profile drawer/modal */}
      {selectedEntry && (
        <div className="fixed inset-0 bg-black/85 flex items-center justify-center p-4 z-[9999] backdrop-blur-sm font-mono animate-fade-in">
          <div className="relative w-full max-w-lg bg-[#141414] border border-[#3a4a44] border-t-4 border-t-[#00e0b3] p-5 sm:p-7 shadow-[0_0_50px_rgba(0,224,179,0.2)] animate-in fade-in zoom-in-95 duration-150">
            
            {/* Top decorative navigation rail */}
            <div className="flex justify-between items-center pb-3.5 border-b border-[#3a4a44]/50 mb-5">
              <span className="text-xs font-bold text-[#00e0b3] tracking-widest flex items-center gap-2">
                <Trophy className="w-4 h-4 text-[#ffd700]" />
                PRTS // COGNITIVE DOSSIER FILE_702
              </span>
              <button 
                onClick={() => setSelectedEntry(null)}
                className="text-[#b9cbc2]/40 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            {/* Profile body column */}
            <div className="space-y-5">
              <div className="flex items-center gap-4">
                {selectedEntry.isCurrentUser ? (
                  <AvatarWithFrame 
                    avatarUrl="https://lh3.googleusercontent.com/aida-public/AB6AXuDZ6YNg8nUcZfJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJfaf6u8lJAVk31dqqxLgKyzHFqIhluOD5a2BU4y33e9DWb3jSwcEu"
                    activeFrameId={progress.activeFrame || 'CLASSIC'}
                    activeAvatarId={progress.activeAvatar || 'DEFAULT'}
                    size="lg"
                  />
                ) : (
                  <div className="w-16 h-16 bg-[#252525] border border-[#00e0b3] text-2xl font-black text-[#00e0b3] flex items-center justify-center shrink-0">
                    {selectedEntry.avatarChar}
                  </div>
                )}
                <div>
                  <h4 className="text-base font-bold text-white tracking-widest font-sans">
                    {selectedEntry.username}
                  </h4>
                  <p className="text-xs text-[#00e0b3] lowercase font-mono tracking-tight mt-0.5">
                    {selectedEntry.title}
                  </p>
                  <p className="text-[9px] text-[#b9cbc2]/40 uppercase mt-1">
                    Status: Verified Operator (羅德島數據鏈路已核對)
                  </p>
                </div>
              </div>

              {/* Data dashboard breakdown rows */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0d0d0d] p-3 border border-[#3a4a44]/40 text-center">
                <div className="space-y-0.5">
                  <span className="block text-[8px] text-[#b9cbc2]/40 uppercase tracking-tighter">COMBAT_ACCURACY</span>
                  <span className="text-[#00e0b3] text-sm font-black font-mono">{selectedEntry.combatEfficiency}%</span>
                </div>
                <div className="space-y-0.5">
                  <span className="block text-[8px] text-[#b9cbc2]/40 uppercase tracking-tighter">ORUNDUM_BALANCE</span>
                  <span className="text-[#ffd700] text-sm font-black font-mono">{selectedEntry.orundum}玉</span>
                </div>
                <div className="space-y-0.5">
                  <span className="block text-[8px] text-[#b9cbc2]/40 uppercase tracking-tighter">MASTERED_MODULES</span>
                  <span className="text-white text-sm font-black font-mono">{selectedEntry.masteredWordsCount}段</span>
                </div>
                <div className="space-y-0.5">
                  <span className="block text-[8px] text-[#b9cbc2]/40 uppercase tracking-tighter">LINK_STREAK</span>
                  <span className="text-[#ff9800] text-sm font-black font-mono flex items-center justify-center gap-0.5">
                    <Flame className="w-3.5 h-3.5 fill-[#ff9800]/20" />
                    {selectedEntry.currentStreak || 0}
                  </span>
                </div>
              </div>

              {/* Character inspirational quote block */}
              <div className="bg-[#1b1919] border-l-2 border-[#ffd700] p-4 text-xs text-[#b9cbc2] leading-relaxed italic relative">
                <span className="absolute top-2 right-3 font-mono text-[8px] text-[#ffd700]/30 font-bold">MOTIVATIONAL_LOG</span>
                <p>&ldquo;{selectedEntry.quote}&rdquo;</p>
              </div>
            </div>

            {/* Bottom confirm / cancel triggers */}
            <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-[#3a4a44]/30 font-mono text-[11px] tracking-wider">
              {selectedEntry.isCurrentUser ? (
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="w-full text-center py-2 bg-[#00e0b3] text-[#002118] font-black hover:brightness-110 transition-colors uppercase rounded cursor-pointer"
                >
                  DISMISS // 關閉資料系統
                </button>
              ) : (
                <>
                  <button
                    onClick={() => setSelectedEntry(null)}
                    className="px-4 py-2 border border-[#3a4a44] text-[#b9cbc2] hover:bg-[#1c221f] transition-all cursor-pointer rounded"
                  >
                    BACK // 返回
                  </button>
                  <button
                    onClick={() => {
                      setSelectedEntry(null);
                      // Start a custom challenge with this operator's levels
                      let levelToStart: WordLevel = 'BASIC';
                      if (selectedEntry.masteredWordsCount > 90) levelToStart = 'TOEFL';
                      else if (selectedEntry.masteredWordsCount > 60) levelToStart = 'TOEIC';
                      else if (selectedEntry.masteredWordsCount > 40) levelToStart = 'INTERMEDIATE';
                      onStartChallenge(levelToStart);
                    }}
                    className="px-4 py-2 bg-[#00e0b3] text-[#002118] hover:scale-102 hover:shadow-[0_0_15px_rgba(0,224,179,0.35)] transition-all cursor-pointer font-bold rounded flex items-center gap-1.5"
                  >
                    <Swords className="w-3.5 h-3.5" />
                    <span>CHALLENGE // 開啟相同認證演練</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
