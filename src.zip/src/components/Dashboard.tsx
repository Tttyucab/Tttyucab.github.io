import { RefreshCw, Award, ShieldAlert, Zap, BookOpen, Terminal } from 'lucide-react';
import { WordLevel, UserProgress } from '../types';

interface DashboardProps {
  currentLevel: WordLevel;
  onSelectLevel: (level: WordLevel) => void;
  quizLength: number;
  onSelectLength: (length: number) => void;
  progress: UserProgress;
  onInitialize: () => void;
  wordsTotalInLevel: number;
  wordsMasteredInLevel: number;
  quizMode: 'VOCABULARY' | 'STRUCTURE';
  onSelectMode: (mode: 'VOCABULARY' | 'STRUCTURE') => void;
}

export default function Dashboard({
  currentLevel,
  onSelectLevel,
  quizLength,
  onSelectLength,
  progress,
  onInitialize,
  wordsTotalInLevel,
  wordsMasteredInLevel,
  quizMode,
  onSelectMode,
}: DashboardProps) {
  // Sync status calculation
  const syncPercentage = wordsTotalInLevel > 0 
    ? Math.round((wordsMasteredInLevel / wordsTotalInLevel) * 100) 
    : 0;

  // Let's create SVG circles for progress ring
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (syncPercentage / 100) * circumference;

  return (
    <div className="space-y-10 max-w-[768px] mx-auto">
      {/* Hero Card: System Synchronization */}
      <section 
        className="relative overflow-hidden bg-[#201f1f] border-l-4 p-6 clip-polygon shadow-md"
        style={{ borderLeftColor: 'var(--theme-color, #00e0b3)' }}
      >
        {/* chamfer decoration effect */}
        <div className="absolute top-0 right-0 w-3 h-3 bg-[#0e0e0e] rotate-45 transform translate-x-1.5 -translate-y-1.5 border-b border-[#3a4a44]" />
        
        <div className="relative z-10 flex justify-between items-center">
          <div className="space-y-2">
            <p className="font-mono text-xs uppercase tracking-widest flex items-center gap-2" style={{ color: 'var(--theme-color, #00e0b3)' }}>
              <Zap className="w-3.5 h-3.5 animate-pulse" style={{ color: 'var(--theme-color, #00e0b3)' }} />
              System Sync: Active // 系統同步鎖定中
            </p>
            <div className="flex items-baseline gap-2">
              <h2 className="text-4xl sm:text-5xl font-mono font-bold" style={{ color: 'var(--theme-color, #00e0b3)' }}>
                {syncPercentage}.0<span className="text-xl">%</span>
              </h2>
            </div>
            <p className="text-[#b9cbc2] font-mono text-[11px] uppercase tracking-tighter">
              {quizMode === 'STRUCTURE' 
                ? 'Grammar Segments: Deep Structural Parsing Active ┃ 句子結構分析特訓模塊已就緒'
                : `Memory Segments: ${wordsMasteredInLevel}/${wordsTotalInLevel} Loops Approved ┃ 已驗證內存字詞段比例`}
            </p>
          </div>

          <div className="relative w-24 h-24 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                className="stroke-[#353534]"
                cx="50"
                cy="50"
                fill="transparent"
                r={radius}
                strokeWidth="3"
              />
              <circle
                className="transition-all duration-500 ease-out"
                style={{ stroke: 'var(--theme-color, #00e0b3)' }}
                cx="50"
                cy="50"
                fill="transparent"
                r={radius}
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="square"
                strokeWidth="5"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <RefreshCw className="w-5 h-5 animate-spin-slow mb-0.5" style={{ color: 'var(--theme-color, #00e0b3)' }} />
              <span className="font-mono text-[8px] tracking-widest font-bold" style={{ color: 'var(--theme-color, #00e0b3)' }}>SYNC</span>
            </div>
          </div>
        </div>

        {/* Technical background grids lines */}
        <div className="absolute top-2 right-4 flex gap-1.5 opacity-20">
          <div className="w-1 h-3" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }} />
          <div className="w-1 h-1.5" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }} />
          <div className="w-1 h-2" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }} />
        </div>
      </section>

      {/* Training Paradigm Select: Choose Mode */}
      <section className="space-y-4">
        <div className="flex justify-between items-end px-1">
          <h3 className="font-mono text-xs uppercase tracking-widest font-semibold flex items-center gap-1.5" style={{ color: 'var(--theme-color, #00e0b3)' }}>
            <span className="w-1.5 h-1.5" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }} />
            Training Paradigm // 選擇戰術演練模式
          </h3>
          <span className="font-mono text-[9px] text-[#b9cbc2]/50">PARADIGM_SELECT_V1</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() => onSelectMode('VOCABULARY')}
            className={`flex items-start gap-4 p-4 border text-left transition-all relative overflow-hidden h-28 cursor-pointer ${
              quizMode === 'VOCABULARY'
                ? 'text-[#002118]'
                : 'bg-[#1c1b1b] text-white border-[#3a4a44] hover:border-theme-acc'
            }`}
            style={{
              backgroundColor: quizMode === 'VOCABULARY' ? 'var(--theme-color, #00e0b3)' : '',
              borderColor: quizMode === 'VOCABULARY' ? 'var(--theme-color, #00e0b3)' : '',
              boxShadow: quizMode === 'VOCABULARY' ? '0 0 15px var(--theme-color-glow)' : '',
            }}
          >
            <div className={`p-2 rounded mt-0.5 ${quizMode === 'VOCABULARY' ? 'bg-black/15' : 'bg-[#292928]'}`}>
              <BookOpen className="w-5 h-5 shrink-0" />
            </div>
            <div className="space-y-1">
              <span className={`font-mono text-[9px] uppercase font-bold ${quizMode === 'VOCABULARY' ? 'text-black/85' : 'text-[#b9cbc2]/50'}`}>
                VOCAB_DRILL // 詞彙連鎖
              </span>
              <h4 className="font-mono text-sm font-black tracking-wider leading-none mt-1">戰術詞彙特訓</h4>
              <p className={`text-[10px] sm:text-[11px] font-sans leading-tight mt-1 ${quizMode === 'VOCABULARY' ? 'text-black/70' : 'text-[#b9cbc2]/60'}`}>
                旨在提高神經突觸對外文符號/單詞的理解與反應記憶速度。
              </p>
            </div>
          </button>

          <button
            onClick={() => onSelectMode('STRUCTURE')}
            className={`flex items-start gap-4 p-4 border text-left transition-all relative overflow-hidden h-28 cursor-pointer ${
              quizMode === 'STRUCTURE'
                ? 'text-[#002118]'
                : 'bg-[#1c1b1b] text-white border-[#3a4a44] hover:border-theme-acc'
            }`}
            style={{
              backgroundColor: quizMode === 'STRUCTURE' ? 'var(--theme-color, #00e0b3)' : '',
              borderColor: quizMode === 'STRUCTURE' ? 'var(--theme-color, #00e0b3)' : '',
              boxShadow: quizMode === 'STRUCTURE' ? '0 0 15px var(--theme-color-glow)' : '',
            }}
          >
            <div className={`p-2 rounded mt-0.5 ${quizMode === 'STRUCTURE' ? 'bg-[#002118]/10' : 'bg-[#292928]'}`}>
              <Terminal className="w-5 h-5 shrink-0" />
            </div>
            <div className="space-y-1">
              <span className={`font-mono text-[9px] uppercase font-bold ${quizMode === 'STRUCTURE' ? 'text-[#002118]/85' : 'text-[#b9cbc2]/50'}`}>
                STRUCT_DRILL // 句子結構
              </span>
              <h4 className="font-mono text-sm font-black tracking-wider leading-none mt-1">英文句子結構練習</h4>
              <p className={`text-[10px] sm:text-[11px] font-sans leading-tight mt-1 ${quizMode === 'STRUCTURE' ? 'text-[#002118]/70' : 'text-[#b9cbc2]/60'}`}>
                特別針對時態變格、被動語態、假設語氣及複雜英文句子結構特訓。
              </p>
            </div>
          </button>
        </div>
      </section>

      {/* Level的选择: Choose Level */}
      <section className="space-y-4">
        <div className="flex justify-between items-end px-1">
          <h3 className="font-mono text-xs uppercase tracking-widest font-semibold flex items-center gap-1.5" style={{ color: 'var(--theme-color, #00e0b3)' }}>
            <span className="w-1.5 h-1.5" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }} />
            Choose Tactical Mission // 選擇戰術分析級別
          </h3>
          <span className="font-mono text-[9px] text-[#b9cbc2]/50">LEVEL_SELECT_V2</span>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {(['BASIC', 'INTERMEDIATE', 'TOEIC', 'TOEFL'] as WordLevel[]).map((level, idx) => {
            const isSelected = currentLevel === level;
            const codes = ['OPS-01', 'OPS-02', 'OPS-T1', 'OPS-T2'];
            const labels = ['初級分析', '中級戰術', '多益演習', '托福實戰'];
            const difficulties = [
              '最低等級 (最簡單)',
              '中低等級 (難度適中/偏易)',
              '中高等級 (難度適中/偏難)',
              '最高等級 (最難)'
            ];
            
            return (
              <button
                key={level}
                onClick={() => onSelectLevel(level)}
                className={`flex flex-col justify-between h-28 p-3.5 border transition-all text-left relative group ${
                  isSelected
                    ? 'text-[#002118]'
                    : 'bg-[#1c1b1b] text-white border-[#3a4a44] hover:border-theme-acc'
                }`}
                style={{
                  backgroundColor: isSelected ? 'var(--theme-color, #00e0b3)' : '',
                  borderColor: isSelected ? 'var(--theme-color, #00e0b3)' : '',
                  boxShadow: isSelected ? '0 0 15px var(--theme-color-glow)' : '',
                }}
              >
                {/* Chamfer decoration */}
                <div 
                  className={`absolute bottom-0 right-0 w-3 h-3 rotate-45 transform translate-x-1.5 translate-y-1.5 border-t`} 
                  style={{
                    backgroundColor: isSelected ? 'var(--theme-color, #00e0b3)' : '#131313',
                    borderColor: isSelected ? 'black' : '#3a4a44'
                  }}
                />

                <div className="flex justify-between items-start w-full">
                  <span className={`font-mono text-[9px] uppercase font-semibold ${
                    isSelected ? 'text-black/80' : 'text-[#b9cbc2]/60'
                  }`}>
                    {codes[idx]}
                  </span>
                  <span 
                    className={`font-sans text-[8px] px-1 py-0.5 font-bold border rounded`}
                    style={{
                      borderColor: isSelected ? 'rgba(0,0,0,0.2)' : '#3a4a44',
                      backgroundColor: isSelected ? 'rgba(0,0,0,0.1)' : 'rgba(0,0,0,0.3)',
                      color: isSelected ? 'black' : '#b9cbc2'
                    }}
                  >
                    DIFF-{idx + 1}
                  </span>
                </div>
                
                <div className="mt-2">
                  <p className="font-mono text-sm font-black tracking-wider leading-none">{level}</p>
                  <span className={`font-sans text-[10px] mt-1.5 block font-bold leading-tight ${
                    isSelected ? 'text-black' : 'text-white'
                  }`}>
                    {labels[idx]}
                  </span>
                  <span className={`font-sans text-[9px] mt-0.5 block ${
                    isSelected ? 'text-black/70' : 'text-[#b9cbc2]/45'
                  }`}>
                    {difficulties[idx]}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Deployment Size的选择: Quiz length */}
      <section className="space-y-4">
        <div className="flex justify-between items-end px-1">
          <h3 className="font-mono text-xs text-[#e5e2e1] uppercase tracking-widest font-semibold flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-[#b9cbc2]" />
            Deployment Scope // 部署任務題量數 (學習計劃)
          </h3>
          <span className="font-mono text-[9px] text-[#b9cbc2]/50">OBJ_COUNT_SETUP</span>
        </div>

        <div className="grid grid-cols-3 gap-0 border border-[#3a4a44] bg-[#0e0e0e]">
          {[5, 10, 20].map((len) => {
            const isSelected = quizLength === len;
            const chineseLabel = len === 5 ? "五個" : len === 10 ? "十個" : "二十個";
            return (
              <button
                key={len}
                onClick={() => onSelectLength(len)}
                className={`py-3 font-mono border-r last:border-r-0 border-[#3a4a44] transition-all ${
                  isSelected
                    ? 'text-[#002118]'
                    : 'text-[#b9cbc2] hover:bg-[#201f1f]'
                }`}
                style={{
                  backgroundColor: isSelected ? 'var(--theme-color, #00e0b3)' : ''
                }}
              >
                <div className="flex flex-col items-center justify-center">
                  <span className="text-[14px] font-sans font-black tracking-wider">{chineseLabel}</span>
                  <span className={`text-[9px] font-mono tracking-wider mt-0.5 font-semibold ${
                    isSelected ? 'text-black/80' : 'text-[#b9cbc2]/50'
                  }`}>
                    {String(len).padStart(2, '0')} UNITS
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Personnel Intel Performance section */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Combat Efficiency */}
        <div className="bg-[#1c1b1b] p-4 border border-[#3a4a44] flex flex-col justify-between min-h-24 relative overflow-hidden">
          <div className="flex justify-between w-full items-start">
            <Award className="text-[#ffbf81] w-5 h-5" />
            <span className="font-mono text-[9px] text-[#b9cbc2]/40">LATEST_RT_EVAL</span>
          </div>
          <div className="mt-2">
            <p className="text-[#b9cbc2] font-mono text-[10px] uppercase tracking-widest">Combat Efficiency // 綜合戰鬥效能比 (答對率)</p>
            <p className="text-3xl font-mono text-white font-bold mt-1">
              {progress.combatEfficiency}<span className="text-lg">%</span>
            </p>
          </div>
          <div className="absolute bottom-0 right-0 w-8 h-8 bg-[#ffbf81]/5 -rotate-45 translate-x-4 translate-y-4" />
        </div>

        {/* Re-Education Pool (Missed Words count) */}
        <div className="bg-[#1c1b1b] p-4 border border-[#3a4a44] flex flex-col justify-between min-[#1c1b1b] relative overflow-hidden">
          <div className="flex justify-between w-full items-start">
            <ShieldAlert className="w-5 h-5 animate-pulse" style={{ color: 'var(--theme-color, #00e0b3)' }} />
            <span className="font-mono text-[9px] text-[#b9cbc2]/40">ERR_ANOMALY_LOG</span>
          </div>
          <div className="mt-2">
            <p className="text-[#b9cbc2] font-mono text-[10px] uppercase tracking-widest">Re-Education Pool // 待優化核心錯題庫</p>
            <p className="text-3xl font-mono text-white font-bold mt-1">
              {progress.reEducationCount}
            </p>
          </div>
          <div className="absolute bottom-0 right-0 w-8 h-8 -rotate-45 translate-x-4 translate-y-4 opacity-5" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }} />
        </div>
      </section>

      {/* Custom Dynamic Illustration */}
      <div className="relative w-full h-40 bg-[#201f1f] overflow-hidden group border border-[#3a4a44]">
        {/* Hotlink illustration from unsplash that fits technical Arknights visual */}
        <img
          alt="Educational inspiration"
          className="w-full h-full object-cover transition-transform duration-1000 grayscale brightness-[30%] group-hover:scale-105"
          referrerPolicy="no-referrer"
          src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=640&auto=format&fit=crop"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0e0e0e]/95 via-[#0e0e0e]/20 to-transparent flex items-center p-6">
          <div className="max-w-[85%] border-l-2 pl-4 space-y-1" style={{ borderLeftColor: 'var(--theme-color, #00e0b3)' }}>
            <p className="text-[10px] font-mono mb-0.5 opacity-85 uppercase tracking-[0.2em]" style={{ color: 'var(--theme-color, #00e0b3)' }}>CORE_DIRECTIVE // 戰術指示</p>
            <p className="text-white font-mono text-xs sm:text-sm leading-relaxed italic font-medium">
              "The roots of education are bitter, but the fruit is sweet. Stand resilient, Doctor."
            </p>
            <p className="text-[#b1c5ba] font-sans text-[11px] leading-relaxed">
              「教育的根是酸澀的，但其結出的果實無比甜美。請保持堅韌，Doctor。」
            </p>
          </div>
        </div>
        <div className="absolute top-2 right-3 font-mono text-[8px] opacity-40 uppercase" style={{ color: 'var(--theme-color, #00e0b3)' }}>STORAGE_LINK_7741</div>
      </div>

      {/* CTA Floating/Bottom Button container */}
      <div className="pt-4 pb-8">
        <button
          onClick={onInitialize}
          className="w-full text-[#002118] font-mono text-sm py-5 relative overflow-hidden group active:scale-[0.98] transition-all border hover:brightness-110 cursor-pointer"
          style={{
            backgroundColor: 'var(--theme-color, #00e0b3)',
            borderColor: 'var(--theme-color, #00e0b3)',
            boxShadow: '0 0 20px var(--theme-color-glow, rgba(0,224,179,0.25))',
          }}
        >
          <div className="relative flex flex-col items-center justify-center gap-1">
            <div className="flex items-center gap-2">
              <span className="tracking-[0.2em] font-black">INITIALIZE TACTICAL OPERATION</span>
              <span className="font-bold sm:inline hidden text-xs">⚡</span>
            </div>
            <span className="text-[10px] tracking-[0.1em] text-black/80 font-bold font-sans">啟動高級戰術記憶訓練鏈接</span>
          </div>
          {/* bracket decoration styling elements inside chamfer button */}
          <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-black" />
          <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-black" />
        </button>
      </div>
    </div>
  );
}
