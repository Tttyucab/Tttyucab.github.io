import { useState, useEffect } from 'react';
import { CheckCircle2, AlertOctagon, Target, ChevronRight, HelpCircle, HardDrive, Loader2 } from 'lucide-react';
import { VocabularyWord } from '../types';

interface QuizProps {
  currentWord: VocabularyWord;
  onNext: (isCorrect: boolean, chosenOption: string) => void;
  currentIndex: number; // 0-based
  totalWords: number;
  consecutiveCorrect: number;
  sessionEarnedOrundum: number;
  sessionCorrectCount: number;
}

export default function Quiz({
  currentWord,
  onNext,
  currentIndex,
  totalWords,
  consecutiveCorrect,
  sessionEarnedOrundum,
  sessionCorrectCount,
}: QuizProps) {
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);
  const [explainData, setExplainData] = useState<any | null>(null);
  const [explainLoading, setExplainLoading] = useState<boolean>(false);

  // Reset state on question change
  useEffect(() => {
    setSelectedChoice(null);
    setIsSubmitted(false);
    setIsCorrect(false);
    setExplainData(null);
  }, [currentWord]);

  const fetchExplanation = async () => {
    setExplainLoading(true);
    setExplainData(null);
    try {
      const response = await fetch('/api/explain-sentence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sentence: currentWord.sentence,
          targetWord: currentWord.word,
          meaning: currentWord.meaning,
          choices: currentWord.choices,
        }),
      });
      const data = await response.json();
      setExplainData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setExplainLoading(false);
    }
  };

  useEffect(() => {
    if (isSubmitted) {
      fetchExplanation();
    } else {
      setExplainData(null);
    }
  }, [isSubmitted, currentWord]);

  // Handle Enter key for bypass/confirm
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        if (!selectedChoice) return;
        if (!isSubmitted) {
          handleConfirm();
        } else {
          handleProceed();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedChoice, isSubmitted]);

  const handleSelect = (choice: string) => {
    if (isSubmitted) return;
    setSelectedChoice(choice);
  };

  const handleConfirm = () => {
    if (!selectedChoice || isSubmitted) return;
    const correct = selectedChoice.toUpperCase() === currentWord.correctAnswer.toUpperCase();
    setIsCorrect(correct);
    setIsSubmitted(true);
  };

  const handleProceed = () => {
    if (!selectedChoice) return;
    onNext(isCorrect, selectedChoice);
  };

  // Deployment progress percentage (e.g., 30%)
  const percentageCompleted = Math.round((currentIndex / totalWords) * 100);

  return (
    <div className="w-full max-w-[768px] mx-auto flex flex-col gap-6 relative">
      
      {/* Technical Readout Top */}
      <div className="flex justify-between items-end border-b border-[#3a4a44]/30 pb-2 font-mono">
        <div className="flex flex-col">
          <span className="text-[10px] uppercase tracking-widest font-bold" style={{ color: 'var(--theme-color, #00e0b3)', opacity: 0.75 }}>DEPLOYMENT_PROGRESS</span>
          <span className="text-xl font-bold" style={{ color: 'var(--theme-color, #00e0b3)' }}>{percentageCompleted}%</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[10px] text-[#b9cbc2] uppercase tracking-wider">OBJECTIVE_ID</span>
          <span className="text-sm text-[#e5e2e1] font-bold">
            ST-{String(currentIndex + 1).padStart(3, '0')} / {String(totalWords).padStart(3, '0')}
          </span>
        </div>
      </div>

      {/* Progress Data Strip segments (10 loading segments) */}
      <div className="flex h-1.5 w-full gap-0.5">
        {Array.from({ length: Math.max(10, totalWords) }).map((_, idx) => {
          // If totalWords is less than 10, fill up segments nicely.
          const segmentIndex = Math.floor((idx / Math.max(10, totalWords)) * totalWords);
          const isActive = segmentIndex < currentIndex;
          const isCurrent = segmentIndex === currentIndex;
          
          return (
            <div
              key={idx}
              className={`flex-grow h-full transition-all duration-300 ${
                isActive ? 'shadow-[0_0_8px_var(--theme-color-glow)]' : isCurrent ? 'animate-pulse' : 'bg-[#2a2a2a]'
              }`}
              style={{
                backgroundColor: isActive 
                  ? 'var(--theme-color, #00e0b3)' 
                  : isCurrent 
                    ? 'var(--theme-color-bg, rgba(0, 224, 179, 0.4))' 
                    : ''
              }}
            />
          );
        })}
      </div>

      {/* AI Adaptive Difficulty Status Strip */}
      <div 
        className="bg-[#101413] border px-4 py-3 flex flex-col lg:flex-row justify-between items-start lg:items-center font-mono text-xs gap-3 rounded shadow-inner"
        style={{ borderColor: 'var(--theme-color-bg)' }}
      >
        <div className="flex flex-col gap-1 w-full lg:w-auto">
          <div className="flex items-center gap-2.5 text-[#b9cbc2]">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }}></span>
              <span className="relative inline-flex rounded-full h-2 w-2" style={{ backgroundColor: 'var(--theme-color, #00e0b3)' }}></span>
            </span>
            <span className="text-[10px] sm:text-[11px] leading-relaxed">
              <strong className="font-bold" style={{ color: 'var(--theme-color, #00e0b3)' }}>PRTS_ADAPTIVE_GATE // 智能自適應引擎</strong>：答對 3 題自動晉升，答錯自動降級並注入同義詞鞏固
            </span>
          </div>
          <div className="text-[10px] text-[#b9cbc2]/70 pl-4.5 flex flex-wrap items-center gap-1.5 sm:gap-2">
            <span className="font-bold" style={{ color: 'var(--theme-color, #00e0b3)' }}>EST_BONUS // 預計結算回報:</span>
            <span className="bg-[#1a1c1a] px-1.5 py-0.5 rounded border border-[#3a4a44]/50">
              當前答對: <strong className="text-white font-bold">{sessionCorrectCount}</strong> / {currentIndex} 題
              {currentIndex > 0 && ` (${Math.round((sessionCorrectCount / currentIndex) * 100)}%)`}
            </span>
            <span className="text-[#364840]">┃</span>
            <span className="bg-[#1a1c1a] px-1.5 py-0.5 rounded border border-[#d2ab30]/30 flex items-center gap-1 text-white">
              <span className="text-[#ffd700] font-black">累計待核發:</span>
              <strong className="text-[#ffd700] hover:scale-105 transition-all">+{sessionEarnedOrundum}</strong>
              <span className="text-[#ffd700]/60 text-[8px] uppercase">合成玉</span>
            </span>
            <span className="text-[9px] text-[#b9cbc2]/40 hidden md:inline font-sans">( 更高難度單字/正確率越高 收益越多 )</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2 shrink-0 text-[11px]">
          <span className="text-[#b9cbc2]/50 text-[10px] uppercase">LINK_SERIES // 連勝序列:</span>
          <div className="flex gap-1">
            {[1, 2, 3].map((step) => {
              const isPassed = consecutiveCorrect >= step;
              return (
                <div
                  key={step}
                  className={`w-4 h-4 border flex items-center justify-center text-[9px] font-bold transition-all duration-300 ${
                    isPassed
                      ? 'text-[#002118]'
                      : 'border-[#3a4a44] text-[#b9cbc2]/30 bg-[#141414]'
                  }`}
                  style={{
                    backgroundColor: isPassed ? 'var(--theme-color, #00e0b3)' : '',
                    borderColor: isPassed ? 'var(--theme-color, #00e0b3)' : '',
                    boxShadow: isPassed ? '0 0 6px var(--theme-color-glow)' : '',
                  }}
                >
                  {step}
                </div>
              );
            })}
          </div>
          <span className="font-bold font-mono" style={{ color: 'var(--theme-color, #00e0b3)' }}>({consecutiveCorrect}/3)</span>
        </div>
      </div>

      {/* Tactical Question Card */}
      <section className="relative bg-[#1c1b1b] border border-[#3a4a44] p-6 sm:p-8 overflow-hidden group">
        {/* corner borders */}
        <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2" style={{ borderColor: 'var(--theme-color, #00e0b3)' }} />
        <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2" style={{ borderColor: 'var(--theme-color, #00e0b3)' }} />
        <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2" style={{ borderColor: 'var(--theme-color, #00e0b3)' }} />
        <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2" style={{ borderColor: 'var(--theme-color, #00e0b3)' }} />
        
        {/* subtle scanline overlay */}
        <div className="absolute inset-0 bg-scanline pointer-events-none opacity-5 animate-scanline" />
 
        <div className="flex flex-col gap-5 relative z-10 font-mono">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2" style={{ color: 'var(--theme-color, #00e0b3)' }}>
              <Target className="w-4 h-4" />
              <span className="text-[11px] tracking-[0.2em] font-bold">INTEL_ANALYSIS_REQUIRED</span>
            </div>
            <div className="text-[10px] text-[#b9cbc2]/40 bg-white/5 px-2 py-0.5 border border-[#3a4a44]/30">
              REF_ID: {currentWord.refId}
            </div>
          </div>
 
          <h2 className="text-lg sm:text-2xl text-white font-bold leading-relaxed border-l-4 pl-4" style={{ borderLeftColor: 'var(--theme-color, #00e0b3)' }}>
            {/* Split the sentence around _______ to highlight it differently if desired */}
            {currentWord.sentence.includes('_______') ? (
              <>
                {currentWord.sentence.split('_______')[0]}
                <span 
                  className="px-2 py-1 mx-1 rounded border-b-2 border-dashed font-bold underline text-theme-acc"
                  style={{
                    backgroundColor: 'var(--theme-color-bg)',
                    borderBottomColor: 'var(--theme-color)',
                  }}
                >
                  {isSubmitted ? currentWord.correctAnswer : '_______'}
                </span>
                {currentWord.sentence.split('_______')[1]}
              </>
            ) : (
              currentWord.sentence
            )}
          </h2>

          {isSubmitted && (
            <p className="text-xs sm:text-sm text-[#b9cbc2]/70 border-l-2 border-dashed border-[#3a4a44] pl-4 italic">
              翻譯：{currentWord.sentenceChinese}
            </p>
          )}

          <div className="grid grid-cols-2 gap-4 mt-2">
            <div className="flex flex-col gap-1">
              <span className="text-[9px] text-[#b9cbc2]/60 uppercase font-bold tracking-widest">Context_Matrix</span>
              <div className="h-1.5 bg-[#3a4a44]/20 w-full overflow-hidden">
                <div
                  className="h-full transition-all duration-500"
                  style={{ 
                    width: `${currentWord.contextValue}%`,
                    backgroundColor: 'var(--theme-color)'
                  }}
                />
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-[9px] text-[#b9cbc2]/60 uppercase font-bold tracking-widest">System_Load</span>
              <div className="h-1.5 bg-[#3a4a44]/20 w-full overflow-hidden">
                <div
                  className="h-full transition-all duration-500"
                  style={{ 
                    width: `${currentWord.systemLoadValue}%`,
                    backgroundColor: 'var(--theme-color)'
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Choice Buttons Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {currentWord.choices.map((choice, index) => {
          const letter = String.fromCharCode(65 + index); // A, B, C, D
          const isSelected = selectedChoice === choice;
          const isCorrectChoice = choice.toUpperCase() === currentWord.correctAnswer.toUpperCase();

          // Custom styling for active battle response
          let borderStyle = 'border-[#3a4a44] bg-[#201f1f] hover:bg-[#2a2a2a]';
          let textColor = 'text-[#b9cbc2]';
          let letterBg = 'bg-[#1c1b1b] border-[#3a4a44]';
          let opStateLabel = 'CMD_EXECUTE';
          let rightIcon = null;

          if (isSubmitted) {
            if (isCorrectChoice) {
              // Highlight the correct answer in green glow
              borderStyle = 'border-theme-acc bg-theme-acc-10 shadow-theme-acc';
              textColor = 'text-theme-acc font-bold';
              letterBg = 'bg-theme-acc-10 border-theme-acc text-theme-acc';
              opStateLabel = 'SYNC SUCCESSFUL';
              rightIcon = <CheckCircle2 className="w-5 h-5 text-theme-acc ml-auto shrink-0" />;
            } else if (isSelected) {
              // Highlight selected incorrect answer in warning orange
              borderStyle = 'border-[#ff9800] bg-[#ff9800]/10 shadow-[0_0_10px_rgba(255,152,0,0.2)]';
              textColor = 'text-[#ff9800] font-bold';
              letterBg = 'bg-[#ff9800]/25 border-[#ff9800] text-[#ff9800]';
              opStateLabel = 'LINK FAILURE';
              rightIcon = <AlertOctagon className="w-5 h-5 text-[#ff9800] ml-auto shrink-0" />;
            } else {
              // Non-selected neutral options are disabled/dims
              borderStyle = 'border-[#3a4a44]/40 bg-[#201f1f]/35 opacity-20 cursor-not-allowed';
              textColor = 'text-[#b9cbc2]/40';
            }
          } else {
            // Unsubmitted states
            if (isSelected) {
              borderStyle = 'border-theme-acc bg-theme-acc-10 shadow-theme-acc';
              textColor = 'text-white font-semibold';
              letterBg = 'bg-theme-acc-10 border-theme-acc text-theme-acc';
            }
          }

          return (
            <button
              key={choice}
              disabled={isSubmitted}
              onClick={() => handleSelect(choice)}
              className={`relative flex items-center p-4 border transition-all duration-150 text-left overflow-hidden ${borderStyle}`}
            >
              <div className="flex items-center gap-4 z-10 w-full">
                <div className={`font-mono border w-8 h-8 flex items-center justify-center shrink-0 font-bold ${letterBg}`}>
                  {letter}
                </div>
                <div className="flex flex-col flex-grow">
                  <span className={`font-mono text-[9px] uppercase tracking-widest ${textColor}/70`}>
                    {opStateLabel}
                  </span>
                  <span className={`font-mono text-[14px] sm:text-[16px] tracking-tight uppercase ${textColor}`}>
                    {choice}
                  </span>
                  {isSubmitted && explainData?.choicesTranslation?.[choice] && (
                    <span className="text-[11px] sm:text-[12px] text-[#b9cbc2]/90 mt-1 font-sans font-medium leading-tight">
                      {explainData.choicesTranslation[choice]}
                    </span>
                  )}
                </div>
                {rightIcon}
              </div>
            </button>
          );
        })}
      </div>

      {/* Situation Analysis AI feedback is rendered right inside the quiz flow if submitted! */}
      {isSubmitted && (
        <section 
          className="bg-[#0e0e0e] border font-mono relative overflow-hidden mt-2 transition-all duration-500"
          style={{ borderColor: 'var(--theme-color-bg)' }}
        >
          <div className="absolute top-0 left-0 w-full h-[3px] animate-pulse" style={{ backgroundColor: 'var(--theme-color)' }} />
          <div className="p-6">
            <div className="flex justify-between items-center mb-5 border-b pb-2" style={{ borderBottomColor: 'var(--theme-color-bg)' }}>
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 animate-pulse text-theme-acc" />
                <h3 className="text-xs tracking-[0.2em] font-bold uppercase text-theme-acc">
                  [ SITUATION ANALYSIS ]
                </h3>
              </div>
              <span className="text-[10px] text-[#b9cbc2]/40">DECRYPT_SIG: {currentWord.decryptSig}</span>
            </div>

            <div className="space-y-6 text-sm text-[#b9cbc2]/90 leading-relaxed">
              <div>
                <p className="text-[9px] text-[#b9cbc2]/40 uppercase tracking-widest mb-1">&gt; TRANSLATION_DATA // 詞彙釋義</p>
                <div className="flex items-baseline gap-2">
                  <p className="text-xl font-bold uppercase text-theme-acc">{currentWord.word}</p>
                  <span className="text-sm font-bold text-theme-acc">： {currentWord.meaning}</span>
                </div>
              </div>

              {/* AI Sentences Translate & Grammar Breakdown */}
              {explainLoading && (
                <div className="bg-[#141414] border border-[#3a4a44]/30 p-5 flex items-center justify-center gap-3 my-4">
                  <Loader2 className="w-5 h-5 animate-spin text-theme-acc" />
                  <span className="text-xs animate-pulse font-mono tracking-wider text-theme-acc">PRTS COGNITIVE REPORT GENERATING... // 正在由 AI 深入分析本題語法與生字...</span>
                </div>
              )}

              {explainData && (
                <div className="space-y-5 my-4 font-sans border-t border-b border-[#3a4a44]/20 py-4">
                  {/* 1. Complete Sentence Translation */}
                  <div className="bg-[#141414] border border-[#3a4a44]/40 p-4 space-y-1 rounded relative">
                    <span className="absolute top-2 right-3 text-[8px] text-[#ffb870]/40 font-mono font-bold uppercase">// ACCURATE_DECODING</span>
                    <p className="text-[10px] text-[#ffb870] uppercase tracking-widest font-mono font-bold mb-1">// SENTENCE_DECODING // 題目句子深度翻譯</p>
                    <p className="text-white text-sm sm:text-[15px] font-sans font-medium leading-relaxed">
                      {explainData.sentenceTranslation}
                    </p>
                  </div>

                  {/* 2. Grammatical & Vocabulary Segment Breakdown */}
                  <div className="space-y-2.5">
                    <p className="text-[10px] uppercase tracking-widest font-mono font-bold text-theme-acc">// TACTICAL_STRUCTURE_ANALYSIS // 句式及核心語法點拆解</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {explainData.grammarBreakdown?.map((chunk: any, i: number) => (
                        <div key={i} className="bg-[#141414] border border-[#3a4a44]/30 p-3.5 rounded relative">
                          <span className="absolute top-2 right-3 text-[8px] font-mono text-theme-acc/45">SECT-0{i+1}</span>
                          <span className="text-[13.5px] font-bold block mb-1 text-theme-acc">{chunk.segment}</span>
                          <span className="text-xs text-[#ffb870] font-sans font-semibold border-b border-[#3a4a44]/20 pb-0.5 mb-1.5 block">
                            {chunk.grammaticalValue} ┃ {chunk.translation}
                          </span>
                          <p className="text-[#b9cbc2]/90 text-xs mt-1 font-sans font-normal leading-relaxed">{chunk.tip}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 3. Synonyms */}
                  {explainData.synonyms && explainData.synonyms.length > 0 && (
                    <div className="bg-[#141414] border border-[#3a4a44]/30 p-4 space-y-2 rounded">
                      <p className="text-[10px] uppercase tracking-widest font-mono font-bold text-theme-acc">// EXTENDED_TACTICAL_SYNONYMS // 同盟生字與關聯詞擴展</p>
                      <div className="flex flex-wrap gap-2 pt-1">
                        {explainData.synonyms.map((syn: string, i: number) => (
                          <span key={i} className="border px-3 py-1 text-xs text-[#ebd8b7] font-sans font-semibold rounded bg-theme-acc-10 border-theme-acc/35">
                            {syn}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div>
                <p className="text-[9px] text-[#b9cbc2]/40 uppercase tracking-widest mb-1">&gt; LOGICAL_VALIDATION // 記憶邏輯解析</p>
                <div className="border-l-2 pl-4 py-1 leading-relaxed text-xs sm:text-sm text-[#b9cbc2] space-y-1.5" style={{ borderLeftColor: 'var(--theme-color-bg)' }}>
                  <p className="text-[11px] text-[#b9cbc2]/50 uppercase">{currentWord.explanation}</p>
                  <p className="text-white font-sans text-sm font-medium">{currentWord.explanationChinese}</p>
                </div>
              </div>

              <div className="bg-[#201f1f]/50 p-4 border border-[#3a4a44]/30 space-y-2">
                <p className="text-[9px] uppercase tracking-widest font-bold text-theme-acc">// BONUS_APPLICATION_CASE // 戰地應用例句</p>
                <p className="italic text-white opacity-90 text-xs sm:text-sm">
                  "{currentWord.bonusCase}"
                </p>
                <div className="border-t border-[#3a4a44]/30 pt-1.5 mt-1.5 text-xs sm:text-sm text-theme-acc">
                  譯：{currentWord.bonusCaseChinese}
                </div>
              </div>
            </div>

            <div className="mt-8">
              <button
                onClick={handleProceed}
                className="w-full py-4 text-[#002118] font-mono text-xs font-bold tracking-[0.3em] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                style={{
                  backgroundColor: 'var(--theme-color, #00e0b3)',
                }}
              >
                <span>ACKNOWLEDGE & PROCEED</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Submit / Skip Control */}
      {!isSubmitted && (
        <div className="flex flex-col items-center pt-2">
          <button
            onClick={handleConfirm}
            disabled={!selectedChoice}
            className={`group w-full sm:w-auto sm:min-w-[320px] py-4 px-8 font-mono tracking-widest transition-all duration-300 relative border overflow-hidden ${
              selectedChoice
                ? 'text-[#002118] cursor-pointer'
                : 'bg-[#2a2a2a] text-[#b9cbc2]/40 border-[#3a4a44]/30 cursor-not-allowed'
            }`}
            style={{
              backgroundColor: selectedChoice ? 'var(--theme-color, #00e0b3)' : '',
              borderColor: selectedChoice ? 'var(--theme-color, #00e0b3)' : '',
              boxShadow: selectedChoice ? '0 0 20px var(--theme-color-glow)' : '',
            }}
          >
            <span className="relative z-10 font-bold uppercase">
              {selectedChoice ? 'INITIALIZE_SEQUENCE' : 'CONFIRM_SELECTION'}
            </span>
          </button>
          
          <div className="mt-4 flex items-center gap-6 font-mono text-[9px] text-[#b9cbc2]/40 uppercase tracking-[0.2em]">
            <span>[ Press Enter to Bypass ]</span>
            <span>[ Status: {selectedChoice ? 'SEQUENCE_READY' : 'WAITING_INPUT'} ]</span>
          </div>
        </div>
      )}
    </div>
  );
}
