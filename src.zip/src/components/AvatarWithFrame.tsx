import { 
  ShieldAlert, Award, Star, Eye, Shield, Feather, Coffee, Compass, 
  Target, Flame, Heart, Cpu, Skull, Sparkles, Crown, Zap
} from 'lucide-react';
import { GACHA_AVATARS, AvatarItem } from '../avatarData';

export interface AvatarFrame {
  id: string;
  name: string;
  nameChinese: string;
  price: number;
  description: string;
  descriptionChinese: string;
  borderColor: string;
  glowColor: string;
  className: string;
}

export const AVATAR_FRAMES: AvatarFrame[] = [
  {
    id: 'CLASSIC',
    name: 'PRTS Operator Frame',
    nameChinese: '羅德島標準端框',
    price: 0,
    description: 'Standard tactical communication terminal border. Classic cyan outline.',
    descriptionChinese: '羅德島製式通訊終端框。簡約高對比青色。',
    borderColor: '#00e0b3',
    glowColor: 'rgba(0, 224, 179, 0.2)',
    className: 'border border-[var(--theme-color,#00e0b3)]'
  },
  {
    id: 'ELITE',
    name: 'Rhodes elite frame',
    nameChinese: '精英幹員榮耀金框',
    price: 800,
    description: 'Elite Operator gold gilded frame. Represents advanced tactical recognition.',
    descriptionChinese: '精英幹員專屬鍍金外框，代表戰術認證的特等榮耀。具有星芒微光。',
    borderColor: '#ffd700',
    glowColor: 'rgba(255, 215, 0, 0.45)',
    className: 'border-2 border-[#ffd700] ring-1 ring-[#ffd700]/30 shadow-[0_0_12px_rgba(255,215,0,0.4)]'
  },
  {
    id: 'SYRACUSE',
    name: 'Syracusian Bloodhound',
    nameChinese: '敘拉古狂熱燃紅框',
    price: 1500,
    description: 'Crimson tactical boundary from Syracusian outposts. Pulsing with fighting spirit.',
    descriptionChinese: '敘拉古前哨赤紅外框，邊緣流淌著狂熱的雙色呼吸光效。',
    borderColor: '#ff4b4b',
    glowColor: 'rgba(255, 75, 75, 0.5)',
    className: 'border-2 border-[#ff4b4b] animate-pulse shadow-[0_0_15px_rgba(255,75,75,0.5)]'
  },
  {
    id: 'LATERANO',
    name: 'Neon Halo Resonator',
    nameChinese: '拉特蘭極光霓虹框',
    price: 2500,
    description: 'Laterano saint halo-resonant vector box. Shifting spectral violet neon.',
    descriptionChinese: '拉特蘭光圈共鳴霓虹外框。放射奇幻多維霓虹漸變紫光。',
    borderColor: '#cc55ff',
    glowColor: 'rgba(204, 85, 255, 0.6)',
    className: 'border-2 border-transparent bg-gradient-to-r from-[#cc55ff] to-[#00f0ff] bg-clip-border shadow-[0_0_18px_rgba(204,85,255,0.7)] animate-bounce-slow'
  },
  // GACHA SPECIAL ITEMS
  {
    id: 'FRAME_YATO_TACTICAL',
    name: 'Yato Tactical Visor',
    nameChinese: '夜刀 · 遮光護目頭像框',
    price: 0,
    description: 'Smooth slate-gray titanium border featuring Yato\'s red laser scan theme.',
    descriptionChinese: '【3★/普通】啞光鋼硬灰銑合金，橫亙着與夜刀遮光護目鏡如出一轍的一道赤紅掃描光條。',
    borderColor: '#707070',
    glowColor: 'rgba(112, 112, 112, 0.3)',
    className: 'border-2 border-zinc-500 shadow-[inset_0_0_6px_rgba(112,112,112,0.4)]'
  },
  {
    id: 'FRAME_PLUME_WINGED',
    name: 'Plume Winged Ranger',
    nameChinese: '翎羽 · 守衛羽睫頭像框',
    price: 0,
    description: 'Technical army green frame adorned with micro wing guard accessories.',
    descriptionChinese: '【3★/普通】標準軍隊橄欖綠護架外框，左下角與右上角點綴着一對纖細的白羽鋼盾折片。',
    borderColor: '#556b2f',
    glowColor: 'rgba(85, 107, 47, 0.2)',
    className: 'border border-lime-800 ring-1 ring-lime-700/30'
  },
  {
    id: 'FRAME_MELANTHA_ROSE',
    name: 'Melantha Rose Blade',
    nameChinese: '玫蘭莎 · 薔薇暗影頭像框',
    price: 0,
    description: 'Sleek violet-steel frame featuring fine floral engravings.',
    descriptionChinese: '【4★/稀有】優雅的暗面紫羅蘭晶鋼，在邊框折角處陰刻有微縮的薔薇刃紋花瓣。',
    borderColor: '#8a2be2',
    glowColor: 'rgba(138, 43, 226, 0.4)',
    className: 'border-2 border-purple-600 shadow-[0_0_8px_rgba(138,43,226,0.5)]'
  },
  {
    id: 'FRAME_FANG_ADVANCED',
    name: 'Fang Advance Vanguard',
    nameChinese: '芬 · 十字突擊精制頭像框',
    price: 0,
    description: 'Symmetrical light teal frame with neon illuminated corner tracking markers.',
    descriptionChinese: '【4★/稀有】明朗的先鋒萊姆綠鋼飾結構，四個夾角集成了電子高度指引呼吸燈。',
    borderColor: '#20b2aa',
    glowColor: 'rgba(32, 178, 170, 0.4)',
    className: 'border-2 border-teal-500 ring-1 ring-teal-300/30 shadow-[0_0_10px_rgba(32,178,170,0.5)]'
  },
  {
    id: 'FRAME_AMIYA_RING',
    name: 'Amiya Ring Destiny',
    nameChinese: '阿米婭 · 命運指環特效頭像框',
    price: 0,
    description: 'Ethereal glowing glass shard frame bound by dark inhibitor ring details.',
    descriptionChinese: '【5★/史詩】透明感晶藍外框，四邊被細小的微縮源石抑製圈所束縛，散發微冷晶藍霓虹外圈。',
    borderColor: '#00ccff',
    glowColor: 'rgba(0, 204, 255, 0.55)',
    className: 'border-2 border-cyan-400 shadow-[0_0_12px_rgba(0,204,255,0.7),_inset_0_0_8px_rgba(0,204,255,0.3)]'
  },
  {
    id: 'FRAME_CHEN_DRACONIC',
    name: 'Ch\'en Draconic Armored',
    nameChinese: '陳 · 龍脊斑駁重裝頭像框',
    price: 0,
    description: 'Heavy composite gold-crimson armor frame with L.G.D. warning elements.',
    descriptionChinese: '【5★/史詩】由紅、黑、銀三色複合裝甲鍛造的硬派直角框，融合赤霄劍鞘龍脊，莊重而具壓迫感。',
    borderColor: '#ff2255',
    glowColor: 'rgba(255, 34, 85, 0.6)',
    className: 'border-2 border-rose-500 ring-2 ring-blue-900/40 shadow-[0_0_14px_rgba(255,34,85,0.8)]'
  },
  {
    id: 'FRAME_TEXAS_WOLF',
    name: 'Texas Swordmaster Frame',
    nameChinese: '德克薩斯 · 雙刃流光頭像框',
    price: 0,
    description: 'Premium carbon fiber frame flanked by active glowing amber laser blades.',
    descriptionChinese: '【6★/傳說】奢華磨砂黑晶和碳纖維主體，下緣交叉着兩柄高溫切換的亮黃色能量光刃，溢散黃金餘暉。',
    borderColor: '#ff9900',
    glowColor: 'rgba(255, 153, 0, 0.75)',
    className: 'border-2 border-amber-500 bg-gradient-to-tr from-amber-950/20 to-black/80 shadow-[0_0_20px_rgba(255,153,0,0.9),_inset_0_0_10px_rgba(255,153,0,0.5)] animate-pulse'
  },
  {
    id: 'FRAME_MOSTIMA_TIME',
    name: 'Mostima Chrono Resonator',
    nameChinese: '莫斯提馬 · 時空雙環特效頭像框',
    price: 0,
    description: 'Double reverse-rotating glowing chronological halo rings with cosmic purple dust.',
    descriptionChinese: '【6★/傳說】由内外兩層逆時針與順時針咬合運行的深紫色時空星軌環構成，呈現動態時差，科幻極客。',
    borderColor: '#aa55ff',
    glowColor: 'rgba(170, 85, 255, 0.8)',
    className: 'border-2 border-purple-500 bg-gradient-to-b from-indigo-950/10 to-purple-950/20 shadow-[0_0_25px_rgba(170, 85, 255, 1),_inset_0_0_12px_rgba(170, 85, 255, 0.6)] animate-bounce-slow'
  },
  {
    id: 'FRAME_W_EMBER',
    name: 'W Apocalypse Combustion',
    nameChinese: 'W · 炙燒煉獄動態頭像框',
    price: 0,
    description: 'Supreme limited frame of red-horned Sarkaz style. Dynamic combustion shockwaves.',
    descriptionChinese: '【★限定★/至高】暗黑魔角裝飾的熔岩外框。邊緣不斷湧現爆燃火舌與炙熱粒子，具備多維脈衝震盪波。',
    borderColor: '#ff1a00',
    glowColor: 'rgba(255, 26, 0, 0.95)',
    className: 'border-[3px] border-orange-600 shadow-[0_0_35px_rgba(255,48,0,1),_inset_0_0_15px_rgba(255,48,0,0.8)]'
  }
];

interface AvatarWithFrameProps {
  avatarUrl: string;
  activeFrameId?: string;
  activeAvatarId?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  onClick?: () => void;
}

export default function AvatarWithFrame({
  avatarUrl,
  activeFrameId = 'CLASSIC',
  activeAvatarId = 'DEFAULT',
  size = 'md',
  onClick
}: AvatarWithFrameProps) {
  const frame = AVATAR_FRAMES.find(f => f.id === activeFrameId) || AVATAR_FRAMES[0];

  let sizeClasses = 'w-8 h-8';
  let iconSizeClasses = 'w-3.5 h-3.5';
  
  if (size === 'sm') {
    sizeClasses = 'w-7 h-7';
    iconSizeClasses = 'w-3 h-3';
  } else if (size === 'lg') {
    sizeClasses = 'w-16 h-16';
    iconSizeClasses = 'w-7 h-7';
  } else if (size === 'xl') {
    sizeClasses = 'w-24 h-24';
    iconSizeClasses = 'w-11 h-11';
  }

  // Find custom avatar
  const isCustom = activeAvatarId && activeAvatarId !== 'DEFAULT';
  const customAvatarItem = isCustom ? GACHA_AVATARS.find(a => a.id === activeAvatarId) : undefined;

  // Render standard Lucide icon inside custom avatar based on item config
  const renderAvatarContent = () => {
    if (customAvatarItem) {
      const renderYato = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#1e1d1f]">
          <div className="absolute inset-0 bg-radial-gradient from-red-600/15 via-transparent to-transparent pointer-events-none" />
          <div className="absolute -inset-2 opacity-25 flex flex-col justify-around rotate-12 pointer-events-none">
            <div className="h-1.5 w-[200%] bg-zinc-800 -ml-10" />
            <div className="h-1.5 w-[200%] bg-zinc-800 -ml-10" />
          </div>
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%] drop-shadow-[0_2px_5px_rgba(0,0,0,0.9)]">
            {/* Gray carbon-steel visor base plate */}
            <path d="M10 24 Q4 10 22 6 L32 14 L42 6 Q60 10 54 24 L48 44 L32 50 L16 44 Z" fill="#2d2d30" stroke="#5a5a5d" strokeWidth="1.5" />
            <path d="M18 20 L32 28 L46 20 L32 14 Z" fill="#1b1b1d" />
            {/* Blinder mask visor cover */}
            <rect x="12" y="24" width="40" height="11" rx="1.5" fill="#141416" stroke="#444" strokeWidth="1" />
            {/* Glowing red laser belt */}
            <line x1="14" y1="29.5" x2="50" y2="29.5" stroke="#ff003c" strokeWidth="4.5" strokeLinecap="round" className="animate-pulse" />
            <line x1="14" y1="29.5" x2="50" y2="29.5" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />
            <circle cx="32" cy="42" r="3" fill="#8a8c8e" />
          </svg>
        </div>
      );

      const renderPlume = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#111513]">
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            {/* Victoria boundary radar background */}
            <circle cx="32" cy="32" r="28" fill="none" stroke="#25352c" strokeWidth="1.5" strokeDasharray="3,4" />
            <circle cx="32" cy="32" r="18" fill="none" stroke="#1d2a23" strokeWidth="1" strokeDasharray="1,2" />
            {/* Crossed steel lances */}
            <g className="opacity-80">
              <line x1="12" y1="52" x2="52" y2="12" stroke="#7b8a82" strokeWidth="2.5" strokeLinecap="round" />
              <line x1="52" y1="52" x2="12" y2="12" stroke="#7b8a82" strokeWidth="2.5" strokeLinecap="round" />
              {/* Lance tips */}
              <polygon points="50,10 54,16 46,20" fill="#ffffff" stroke="#7b8a82" strokeWidth="1" />
              <polygon points="14,10 10,16 18,20" fill="#ffffff" stroke="#7b8a82" strokeWidth="1" />
            </g>
            {/* Two white feathers floating */}
            <path d="M22 46 C30 38 40 38 48 22 C40 38 30 40 22 46 Z" fill="#ffffff" opacity="0.95" />
            <path d="M42 46 C34 38 24 38 16 22 C24 38 34 40 42 46 Z" fill="#7b8a82" opacity="0.65" />
            {/* Lance core binding ring */}
            <circle cx="32" cy="32" r="3.5" fill="#ffffff" stroke="#25352c" strokeWidth="1" />
          </svg>
        </div>
      );

      const renderDurin = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#1c1511]">
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%] text-[#908d80]">
            <line x1="8" y1="50" x2="56" y2="50" stroke="#3d2a21" strokeWidth="2" strokeLinecap="round" />
            {/* Cozy vapor curls */}
            <path d="M26 19 Q28 14 26 10" fill="none" stroke="#e49012" strokeWidth="1.2" className="animate-pulse" />
            <path d="M32 19 Q34 14 32 10" fill="none" stroke="#e49012" strokeWidth="1.2" className="animate-pulse" style={{ animationDelay: '0.4s' }} />
            <path d="M38 19 Q40 14 38 10" fill="none" stroke="#e49012" strokeWidth="1.2" className="animate-pulse" style={{ animationDelay: '0.8s' }} />
            {/* Insulated cup */}
            <rect x="20" y="24" width="20" height="22" rx="3" fill="#908d80" stroke="#ffebc2" strokeWidth="1.8" />
            {/* Golden cup accent */}
            <rect x="20" y="29" width="20" height="4" fill="#e49012" />
            {/* Handle */}
            <path d="M40 29 C45 29 45 39 40 39" fill="none" stroke="#ffebc2" strokeWidth="1.8" strokeLinecap="round" />
            <rect x="23" y="23" width="14" height="2" fill="#ffebc2" />
            {/* Zzz bubbles */}
            <text x="43" y="17" fill="#e49012" fontSize="9" fontWeight="bold" className="animate-bounce-slow font-mono">Zzz</text>
          </svg>
        </div>
      );

      const renderRangers = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#201810]">
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            {/* Antique Canyon Copper compass base dial */}
            <circle cx="32" cy="32" r="26" fill="#2d1f14" stroke="#7c8071" strokeWidth="1" />
            <circle cx="32" cy="32" r="23" fill="none" stroke="#cd7f32" strokeWidth="2" opacity="0.8" />
            {/* Compass degree markers */}
            <circle cx="32" cy="32" r="17" fill="none" stroke="#b87333" strokeWidth="1" strokeDasharray="2,2" opacity="0.6" />
            <line x1="32" y1="8" x2="32" y2="56" stroke="#7c8071" strokeWidth="1" opacity="0.4" />
            <line x1="8" y1="32" x2="56" y2="32" stroke="#7c8071" strokeWidth="1" opacity="0.4" />
            {/* Degree Text Indicators */}
            <text x="30" y="15" fill="#cd7f32" fontSize="5" fontWeight="bold" fontFamily="monospace">N</text>
            <text x="30" y="54" fill="#cd7f32" fontSize="5" fontWeight="bold" fontFamily="monospace">S</text>
            {/* Nav Pointer needle */}
            <g className="origin-center rotate-[35deg] transition-transform duration-1000">
              <polygon points="32,15 37,32 32,29 27,32" fill="#ff4d4d" stroke="#ffffff" strokeWidth="0.5" />
              <polygon points="32,49 37,32 32,35 27,32" fill="#7c8071" stroke="#ffffff" strokeWidth="0.5" />
            </g>
            <circle cx="32" cy="32" r="3.5" fill="#cd7f32" stroke="#ffffff" strokeWidth="1.2" />
          </svg>
        </div>
      );

      const renderKroos = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#05140d]">
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            {/* Tactical sniper range finder rings */}
            <circle cx="32" cy="34" r="24" fill="none" stroke="#1d3e27" strokeWidth="1" strokeDasharray="4,6" />
            <circle cx="32" cy="34" r="18" fill="none" stroke="#3cb371" strokeWidth="1.5" />
            <circle cx="32" cy="34" r="12" fill="none" stroke="#3cb371" strokeWidth="1" opacity="0.4" />
            {/* Long rabbit ears contour */}
            <g className="opacity-80">
              <path d="M21 4 C17 14 19 24 23 26 C23 22 19 12 21 4 Z" fill="#3cb371" />
              <path d="M43 4 C47 14 45 24 41 26 C41 22 47 12 43 4 Z" fill="#3cb371" />
            </g>
            {/* Crosshair grids */}
            <line x1="8" y1="34" x2="56" y2="34" stroke="#3cb371" strokeWidth="1.5" />
            <line x1="32" y1="10" x2="32" y2="58" stroke="#3cb371" strokeWidth="1.5" />
            {/* Crosshair tick labels */}
            <line x1="20" y1="32" x2="20" y2="36" stroke="#3cb371" strokeWidth="1.5" />
            <line x1="44" y1="32" x2="44" y2="36" stroke="#3cb371" strokeWidth="1.5" />
            <line x1="30" y1="22" x2="34" y2="22" stroke="#3cb371" strokeWidth="1.5" />
            <line x1="30" y1="46" x2="34" y2="46" stroke="#3cb371" strokeWidth="1.5" />
            {/* Smile target center */}
            <g transform="translate(0, -1.5)">
              <rect x="20" y="30" width="24" height="11" rx="1" fill="#05140d" stroke="#3cb371" strokeWidth="1" />
              <text x="24" y="38" fill="#ffffff" fontSize="8" fontWeight="black" fontFamily="monospace" letterSpacing="0.2">^ _ ^</text>
            </g>
          </svg>
        </div>
      );

      const renderFang = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#081e1d]">
          {/* Tiffany speed air lines behind */}
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            <path d="M6 32 C12 20 24 16 38 16 C50 16 58 24 58 32" fill="none" stroke="#2a5c58" strokeWidth="1.5" strokeDasharray="4,4" className="opacity-40" />
            <path d="M10 40 Q25 24 46 24 C52 24 54 28 54 32" fill="none" stroke="#20b2aa" strokeWidth="1" strokeDasharray="30; 30" strokeDashoffset="0" style={{ strokeDasharray: '30, 20', animation: 'prts-wind-vector 2s linear infinite' }} />
            {/* Heavy V-shaped steel chevrons */}
            <path d="M12 46 L28 30 L12 14" fill="none" stroke="#0a2a27" strokeWidth="5" strokeLinecap="round" />
            <path d="M22 46 L38 30 L22 14" fill="none" stroke="#104a45" strokeWidth="5" strokeLinecap="round" />
            <path d="M12 46 L28 30 L12 14" fill="none" stroke="#20b2aa" strokeWidth="2.2" strokeLinecap="round" />
            <path d="M22 46 L38 30 L22 14" fill="none" stroke="#ffffff" strokeWidth="2.2" strokeLinecap="round" opacity="0.9" />
            {/* Silver active running horse flags */}
            <g transform="translate(32, 24) scale(0.48)">
              <path d="M26 14 C32 11 44 15 48 15 C50 17 50 23 44 27 C40 29 36 25 32 25 C30 25 28 27 28 29 L28 38 L34 38 M25 38 L25 10" fill="none" stroke="#ffffff" strokeWidth="4.5" strokeLinecap="round" />
              <line x1="28" y1="20" x2="34" y2="20" stroke="#20b2aa" strokeWidth="2" />
            </g>
          </svg>
        </div>
      );

      const renderMelantha = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#3b0816] overflow-hidden">
          {/* Scattered rising rose petals */}
          {[...Array(6)].map((_, i) => {
            const px = `${-10 + i * 6}px`;
            const duration = `${2.5 + Math.random() * 2}s`;
            const delay = `${i * 0.5}s`;
            return (
              <div 
                key={i}
                className="absolute w-2 h-2 bg-[#ff4b8b]/65 rounded-full rounded-tr-none rotate-45 pointer-events-none"
                style={{
                  left: `${15 + i * 16}%`,
                  bottom: '-10px',
                  animation: 'prts-rose-float infinite linear',
                  animationDuration: duration,
                  animationDelay: delay,
                  '--px': px,
                } as any}
              />
            );
          })}
          {/* Heart crest line background */}
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%] relative z-10">
            <circle cx="32" cy="32" r="22" fill="none" stroke="#6b0d24" strokeWidth="1.5" />
            <circle cx="32" cy="32" r="19" fill="none" stroke="#ff4b8b" strokeWidth="0.8" opacity="0.25" />
            {/* Rose branch vector design */}
            <path d="M18 28 C24 16 40 16 46 28 C40 40 24 40 18 28 Z" fill="none" stroke="#ff4b8b" strokeWidth="2" />
            <path d="M23 34 C30 43 40 39 43 30" fill="none" stroke="#ff4b8b" strokeWidth="1.3" />
            <circle cx="32" cy="29" r="4.5" fill="#ff4b8b" stroke="#ffffff" strokeWidth="1" />
            {/* Slashing sword flash glint */}
            <line x1="-10" y1="74" x2="74" y2="-10" stroke="#ffffff" strokeWidth="3.5" className="origin-center" style={{ animation: 'prts-slash-glint 3.2s infinite ease-out' }} />
          </svg>
        </div>
      );

      const renderAmiya = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#020912]">
          {/* Circuits layout backgrounds */}
          <div className="absolute inset-0 opacity-15" style={{ backgroundImage: 'radial-gradient(circle, #00ccff 1px, transparent 1px)', backgroundSize: '6px 6px' }} />
          <svg viewBox="0 0 64 64" className="w-[90%] h-[90%] text-[#00ccff]">
            {/* Electrical pathway paths */}
            <path d="M10 10 L18 18 L18 46 L10 54 M54 10 L46 18 L46 46 L54 54" fill="none" stroke="#003355" strokeWidth="1" />
            <circle cx="18" cy="18" r="1.5" fill="#00ccff" />
            <circle cx="46" cy="46" r="1.5" fill="#00ccff" />
            {/* Outer clockwise rotation control ring */}
            <g className="animate-spin-slow origin-center">
              <circle cx="32" cy="32" r="23" fill="none" stroke="#00ccff" strokeWidth="1.8" strokeDasharray="16,10" />
              <rect x="29" y="8" width="6" height="2" fill="#ffffff" />
              <rect x="29" y="54" width="6" height="2" fill="#ffffff" />
            </g>
            {/* Inner counter clockwise ring */}
            <g style={{ animation: 'prts-spin-counter 7.5s linear infinite' }} className="origin-center">
              <circle cx="32" cy="32" r="16" fill="none" stroke="#00ffff" strokeWidth="1.2" strokeDasharray="8,6" opacity="0.8" />
              <circle cx="32" cy="32" r="11" fill="none" stroke="#00ffff" strokeWidth="0.8" opacity="0.4" />
            </g>
            {/* Double white Chimera diamonds crystal */}
            <polygon points="32,16 41,32 32,48 23,32" fill="#020912" stroke="#00ffd8" strokeWidth="2.5" />
            <polygon points="32,20 38,32 32,44 26,32" fill="#ffffff" stroke="#00ccff" strokeWidth="1.2" className="animate-pulse" />
            <circle cx="32" cy="32" r="1.5" fill="#00ffd8" />
          </svg>
        </div>
      );

      const renderTexas = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#120500] overflow-hidden">
          {/* Rain drops falling */}
          {[...Array(6)].map((_, i) => (
            <div 
              key={i}
              className="absolute w-[1px] h-6 bg-yellow-400/40 pointer-events-none"
              style={{
                left: `${10 + i * 20}%`,
                animation: 'prts-rain-fall infinite linear',
                animationDuration: `${0.8 + Math.random() * 0.6}s`,
                animationDelay: `${i * 0.15}s`,
              }}
            />
          ))}
          {/* Diagonal high energy safety yellow striped ribbon */}
          <div className="absolute top-[-20%] left-[-40%] right-[-40%] h-4.5 bg-[#e4a000] rotate-[-30deg] opacity-40 flex items-center justify-around overflow-hidden border-y border-yellow-200/50">
            {[...Array(12)].map((_, s) => (
              <div key={s} className="w-2.5 h-[200%] bg-black/90 rotate-[35deg]" />
            ))}
          </div>
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%] text-[#ff5500]">
            {/* Two crossed orange laser blades */}
            <line x1="8" y1="52" x2="52" y2="10" stroke="#ffbb00" strokeWidth="3" className="drop-shadow-[0_0_4px_#ff5500]" />
            <line x1="56" y1="52" x2="12" y2="10" stroke="#ffbb00" strokeWidth="3" className="drop-shadow-[0_0_4px_#ff5500]" />
            <line x1="8" y1="52" x2="52" y2="10" stroke="#ffffff" strokeWidth="1" opacity="0.9" />
            <line x1="56" y1="52" x2="12" y2="10" stroke="#ffffff" strokeWidth="1" opacity="0.9" />
            {/* Central Wolf mask shield emblem of PL */}
            <path d="M32 16 L44 30 L32 36 L20 30 Z" fill="#202022" stroke="#ff5500" strokeWidth="2" />
            <polygon points="32,36 34,44 32,42 30,44" fill="#ff5500" />
            {/* Glowing wolf eye slots */}
            <path d="M25 24 L29 26 L26 27 Z" fill="#ff0000" className="animate-pulse" />
            <path d="M39 24 L35 26 L38 27 Z" fill="#ff0000" className="animate-pulse" />
          </svg>
        </div>
      );

      const renderChen = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#2d0208] overflow-hidden">
          {/* Royal draconic horn backdrop */}
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%] text-[#ff2255]">
            <g className="opacity-35 text-[#d4af37]">
              <path d="M26 20 C22 10 18 4 12 8 C16 12 18 18 20 23" fill="none" stroke="currentColor" strokeWidth="1.8" />
              <path d="M38 20 C42 10 46 4 52 8 C48 12 46 18 44 23" fill="none" stroke="currentColor" strokeWidth="1.8" />
            </g>
            <circle cx="32" cy="32" r="23" fill="none" stroke="#ff2255" strokeWidth="1.2" strokeDasharray="3,6" opacity="0.4" />
            {/* Vertical Chi Xiao sword */}
            <g className="origin-center rotate-[-12deg] translate-x-1 translate-y-[-1px]">
              {/* Scarlet energy fire blade aura shroud */}
              <path d="M32 4 M28 32 C26 20 28 8 32 3 C36 8 38 20 36 32 Z" fill="#ff2255" opacity="0.32" className="animate-pulse" />
              {/* The sword steel */}
              <line x1="32" y1="42" x2="32" y2="4" stroke="#ff2255" strokeWidth="2.5" />
              <line x1="32" y1="42" x2="32" y2="4" stroke="#ffffff" strokeWidth="1" opacity="0.9" />
              {/* Copper crossguard */}
              <rect x="21" y="41" width="22" height="3" rx="1" fill="#ebd8b7" stroke="#ff2255" strokeWidth="1.2" />
              {/* Handle */}
              <rect x="30.5" y="44" width="3" height="12" fill="#50000a" />
              <circle cx="32" cy="18" r="2" fill="#ffffff" className="animate-pulse" />
            </g>
          </svg>
        </div>
      );

      const renderLungmenEmblem = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#1c0d02]">
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            {/* Security shield plate outline */}
            <circle cx="32" cy="32" r="27" fill="none" stroke="#5c2600" strokeWidth="1.5" />
            {/* Tactical armored protection matrix grids */}
            <g opacity="0.15" stroke="#ff6a00" strokeWidth="0.8">
              <line x1="10" y1="20" x2="54" y2="20" />
              <line x1="10" y1="32" x2="54" y2="32" />
              <line x1="10" y1="44" x2="54" y2="44" />
              <line x1="20" y1="10" x2="20" y2="54" />
              <line x1="32" y1="10" x2="32" y2="54" />
              <line x1="44" y1="10" x2="44" y2="54" />
            </g>
            <path d="M15 14 L49 14 L45 42 L32 53 L19 42 Z" fill="#2d1405" stroke="#ff6a00" strokeWidth="2.6" className="drop-shadow-[0_2px_5px_rgba(0,0,0,0.8)]" />
            {/* Orange Dragon silhouette overlay behind shield */}
            <path d="M20 22 C22 17 38 12 43 23 C45 28 42 34 32 30 C22 26 20 35 32 44" fill="none" stroke="#ff6a00" strokeWidth="1.5" opacity="0.5" strokeLinecap="round" />
            {/* Gold plaque letters LGD */}
            <rect x="22" y="22" width="20" height="9" rx="1" fill="#ff6a00" />
            <text x="24.5" y="29" fill="#1c0d02" fontSize="6.5" fontWeight="950" fontFamily="monospace" letterSpacing="0.4">LGD</text>
            <line x1="32" y1="31" x2="32" y2="46" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
      );

      const renderNianLegend = () => (
        <div className="absolute inset-0 flex items-center justify-center bg-[#1c1500] overflow-hidden">
          {/* Volcanic thermal magma backdrop with slow respiration scale */}
          <div className="absolute inset-0 opacity-45 bg-gradient-to-t from-[#4a0a00] via-[#851101] to-[#ffa600] animate-pulse" style={{ animationDuration: '3.6s' }} />
          
          {/* Ember heat particles floating from bottom */}
          {[...Array(6)].map((_, i) => {
            const px = `${-14 + i * 8}px`;
            const pdx = `${-4 + Math.random() * 8}px`;
            const duration = `${1.4 + Math.random() * 1.5}s`;
            const delay = `${i * 0.35}s`;
            return (
              <div 
                key={i}
                className="absolute bottom-[-10px] w-1.5 h-1.5 rounded-full bg-gradient-to-t from-[#ff4400] to-[#ffdd00] opacity-0 blur-[0.4px] pointer-events-none shadow-[0_0_5px_#ffaa00]"
                style={{
                  left: `${12 + i * 18}%`,
                  animation: 'prts-float-up-particle infinite linear',
                  animationDuration: duration,
                  animationDelay: delay,
                  '--px': px,
                  '--pdx': pdx,
                } as any}
              />
            );
          })}
          
          {/* Rotating ancient golden ring matrix holding glyphs */}
          <div className="absolute w-[84%] h-[84%] border border-[#ffd700]/40 rounded-full" style={{ animation: 'prts-spin-clockwise 7.5s linear infinite' }}>
            <div className="absolute top-0 left-1/2 -ml-1 w-2.5 h-2.5 rounded-full bg-[#ffd700] shadow-[0_0_10px_#ffd700]" />
            <div className="absolute bottom-0 left-1/2 -ml-1 w-2.5 h-2.5 rounded-full bg-[#ff5500] shadow-[0_0_10px_#ff5500]" />
            {/* Simulated ancient glyph bounds */}
            <div className="absolute top-1/2 left-0 -mt-1 w-1.5 h-1.5 bg-[#ffd700]" />
            <div className="absolute top-1/2 right-0 -mt-1 w-1.5 h-1.5 bg-[#ffd700]" />
          </div>
          <div className="absolute w-[62%] h-[62%] border-2 border-dashed border-[#ff6600]/30 rounded-full animate-spin-reverse origin-center" style={{ animation: 'prts-spin-counter 4.8s linear infinite' }} />

          {/* Central heavy bronze armor shield shield with glowing heat vectors */}
          <svg viewBox="0 0 64 64" className="w-[66%] h-[66%] relative z-10 drop-shadow-[0_0_12px_rgba(255,102,0,0.85)]">
            <polygon points="32,6 50,22 43,48 32,55 21,48 14,22" fill="#2d1d05" stroke="#ffd700" strokeWidth="2.5" />
            <polygon points="32,9 47,23 41,45 32,51 23,45 17,23" fill="#4a1a00" stroke="#ffaa00" strokeWidth="1" />
            {/* Lava fire cracks pulsing inside */}
            <path d="M26 28 Q32 16 38 28 Q32 40 26 28" fill="#ff4d00" className="animate-pulse" />
            <circle cx="32" cy="28" r="4.5" fill="#ffffff" className="animate-pulse" />
            <path d="M20 22 L32 28 L44 22 M32 28 L32 50 M24 42 L40 42" fill="none" stroke="#ffd700" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </div>
      );

      const renderSkadiLegend = () => (
        <div className="absolute inset-0 bg-[#0c0005] overflow-hidden flex items-center justify-center">
          {/* Dark Red Ocean tide gradient */}
          <div className="absolute inset-0 opacity-45 bg-gradient-to-b from-[#3a0014] via-[#05111d] to-[#140014] animate-pulse" style={{ animationDuration: '4.8s' }} />
          
          {/* Wave Soundwaves pulse ripples */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
            <div className="absolute top-1/2 left-1/2 w-28 h-28 rounded-full border border-red-500/40 -translate-x-1/2 -translate-y-1/2" style={{ animation: 'prts-wave-pulse 2.4s infinite ease-out' }} />
            <div className="absolute top-1/2 left-1/2 w-28 h-28 rounded-full border border-red-500/20 -translate-x-1/2 -translate-y-1/2" style={{ animation: 'prts-wave-pulse 2.4s infinite ease-out', animationDelay: '1.2s' }} />
          </div>

          {/* Bioluminescent floating crimson Seaborn spores */}
          {[...Array(6)].map((_, i) => {
            const px = `${-14 + i * 8}px`;
            const pdx = `${-4 + Math.random() * 8}px`;
            const duration = `${1.6 + Math.random() * 1.5}s`;
            const delay = `${i * 0.4}s`;
            return (
              <div 
                key={i}
                className="absolute bottom-[-10px] w-1.5 h-1.5 rounded-full bg-[#ff0055] opacity-0 blur-[0.2px] pointer-events-none shadow-[0_0_6px_#ff003c]"
                style={{
                  left: `${10 + i * 18}%`,
                  animation: 'prts-float-up-particle infinite linear',
                  animationDuration: duration,
                  animationDelay: delay,
                  '--px': px,
                  '--pdx': pdx,
                } as any}
              />
            );
          })}

          {/* Abyss Coral Crown crown wireframe & active ruby core */}
          <svg viewBox="0 0 64 64" className="w-[66%] h-[66%] relative z-10 drop-shadow-[0_0_10px_rgba(255,0,85,0.75)]">
            <circle cx="32" cy="22" r="14" fill="none" stroke="#ff0055" strokeWidth="1" opacity="0.4" />
            {/* Crown of deep corals */}
            <path d="M12 40 C14 26 24 22 32 30 C40 22 50 26 52 40 C38 32 26 32 12 40 Z" fill="#210008" stroke="#ff0055" strokeWidth="2" strokeLinecap="round" />
            <circle cx="32" cy="26" r="6" fill="#ff0055" className="animate-pulse" />
            <circle cx="32" cy="26" r="2.5" fill="#ffffff" className="animate-pulse" />
            {/* Vertical cross staff line */}
            <line x1="32" y1="46" x2="32" y2="8" stroke="#ffffff" strokeWidth="2.2" strokeLinecap="round" />
            <line x1="25" y1="36" x2="37" y2="36" stroke="#ff0055" strokeWidth="1.8" />
          </svg>
        </div>
      );

      const renderPrtsOverlord = () => (
        <div className="absolute inset-0 bg-[#000504] overflow-hidden flex items-center justify-center">
          {/* Double column green binary code flow */}
          <div className="absolute left-[5%] right-auto top-0 bottom-0 opacity-25 font-mono text-[5px] text-[#00ffd8] select-none h-[200%] flex flex-col justify-around leading-none pointer-events-none" style={{ animation: 'prts-stream-binary 10s linear infinite' }}>
            <span>0101 1100</span>
            <span>0011 0001</span>
            <span>0111 0101</span>
            <span>1100 0010</span>
            <span>1010 1111</span>
            <span>0110 0110</span>
            <span>1001 0101</span>
            <span>1100 1100</span>
          </div>
          <div className="absolute right-[5%] left-auto top-0 bottom-0 opacity-25 font-mono text-[5px] text-[#00ffd8] select-none h-[200%] flex flex-col justify-around leading-none pointer-events-none" style={{ animation: 'prts-stream-binary 8s linear infinite' }}>
            <span>1100 0011</span>
            <span>0101 1010</span>
            <span>0111 1100</span>
            <span>0010 0001</span>
            <span>1110 0101</span>
            <span>0011 1111</span>
            <span>1000 0101</span>
            <span>0110 1010</span>
          </div>

          {/* Glitching horizontal slice overlay */}
          <div className="absolute inset-0 bg-[#00ffd8]/10 mix-blend-color-dodge z-10 pointer-events-none" style={{ animation: 'prts-glitch-flicker 5s infinite' }} />

          {/* Core hologram rotation circles */}
          <div className="absolute inset-0 flex items-center justify-center z-10" style={{ animation: 'prts-hologram-shiver 3s ease-in-out infinite' }}>
            <div className="absolute w-[88%] h-[88%] border-2 border-[#00ffd8]/25 rounded-full" style={{ animation: 'prts-spin-clockwise 10s linear infinite' }}>
              <div className="absolute top-0 left-1/2 -ml-1 w-2 h-2 bg-[#00ffd8] shadow-[0_0_8px_#00ffd8]" />
              <div className="absolute bottom-0 left-1/2 -ml-1 w-2 h-2 bg-[#00ffd8] shadow-[0_0_8px_#00ffd8]" />
              <div className="absolute top-1/2 left-0 -mt-1 w-2 h-2 bg-[#00ffd8] shadow-[0_0_8px_#00ffd8]" />
              <div className="absolute top-1/2 right-0 -mt-1 w-2 h-2 bg-[#00ffd8] shadow-[0_0_8px_#00ffd8]" />
            </div>
            <div className="absolute w-[72%] h-[72%] border border-dashed border-[#00ffd8]/40 rounded-full animate-spin-reverse" style={{ animation: 'prts-spin-counter 5s linear infinite' }} />
            
            {/* Central high dimensional wireframe prism */}
            <svg viewBox="0 0 64 64" className="w-[60%] h-[60%] relative z-10 drop-shadow-[0_0_12px_rgba(0,255,216,0.9)]">
              <path d="M12 18 L12 12 L18 12 M46 12 L52 12 L52 18 M12 46 L12 52 L18 52 M46 52 L52 52 L52 46" fill="none" stroke="#00ffd8" strokeWidth="2.8" />
              {/* Pulsing superbrain prism */}
              <g className="origin-center animate-pulse">
                <polygon points="32,15 45,32 32,49 19,32" fill="none" stroke="#00ffd8" strokeWidth="1.8" />
                <polygon points="32,21 39,32 32,43 25,32" fill="none" stroke="#ffffff" strokeWidth="1" opacity="0.8" />
                <line x1="32" y1="15" x2="32" y2="49" stroke="#00ffd8" strokeWidth="1" strokeDasharray="2,2" />
                <line x1="19" y1="32" x2="45" y2="32" stroke="#00ffd8" strokeWidth="1" strokeDasharray="2,2" />
              </g>
              {/* Core light spot */}
              <circle cx="32" cy="32" r="3.5" fill="#ffffff" className="animate-ping" style={{ animationDuration: '2.5s' }} />
              <circle cx="32" cy="32" r="2.5" fill="#00ffd8" />
            </svg>

            {/* Glowing radar grid sweeps */}
            <div className="absolute w-[1px] h-[92%] bg-gradient-to-b from-transparent via-[#00ffd8]/25 to-transparent rotate-45" />
            <div className="absolute w-[1px] h-[92%] bg-gradient-to-b from-transparent via-[#00ffd8]/25 to-transparent -rotate-45" />
          </div>

          {/* Cyber scanner swipe high energy neon green line */}
          <div className="absolute left-0 right-0 h-[2.5px] bg-gradient-to-r from-transparent via-[#00ffd8] to-transparent shadow-[0_0_12px_#00ffd8] z-20 pointer-events-none" style={{ animation: 'prts-scanning 2.8s infinite linear' }} />
          <div className="absolute left-0 right-0 bg-[#00ffd8]/25 z-25 pointer-events-none animate-pulse" style={{ height: '2px', top: '33%' }} />
        </div>
      );

      // Route custom renderings based on ID
      switch (customAvatarItem.id) {
        case 'YATO': return renderYato();
        case 'PLUME': return renderPlume();
        case 'DURIN': return renderDurin();
        case 'RANGER': return renderRangers();
        case 'KROOS': return renderKroos();
        case 'FANG': return renderFang();
        case 'MELANTHA': return renderMelantha();
        case 'AMIYA_EPIC': return renderAmiya();
        case 'TEXAS_EPIC': return renderTexas();
        case 'CHEN_EPIC': return renderChen();
        case 'LUNGMEN_EMBLEM': return renderLungmenEmblem();
        case 'NIAN_LEGEND': return renderNianLegend();
        case 'SKADI_LEGEND': return renderSkadiLegend();
        case 'PRTS_OVERLORD': return renderPrtsOverlord();
      }

      // Fallback fallback to generic icon rendering
      let IconComponent = Cpu;
      switch (customAvatarItem.iconName) {
        case 'Shield': IconComponent = Shield; break;
        case 'Feather': IconComponent = Feather; break;
        case 'Coffee': IconComponent = Coffee; break;
        case 'Compass': IconComponent = Compass; break;
        case 'Target': IconComponent = Target; break;
        case 'Flame': IconComponent = Flame; break;
        case 'Heart': IconComponent = Heart; break;
        case 'Cpu': IconComponent = Cpu; break;
        case 'Skull': IconComponent = Skull; break;
        case 'Crown': IconComponent = Crown; break;
        case 'Sparkles': IconComponent = Sparkles; break;
        case 'Zap': IconComponent = Zap; break;
        default: IconComponent = Cpu;
      }

      // Check rarity effects
      const r = customAvatarItem.rarity;
      return (
        <div 
          className="w-full h-full relative flex items-center justify-center overflow-hidden" 
          style={{ background: customAvatarItem.bgColor }}
        >
          {/* Limited edition dazzling rainbows overlay */}
          {r === 'LIMITED' && (
            <div className="absolute inset-0 bg-gradient-to-tr from-[#ff3366]/20 via-[#00ffcc]/10 to-[#ffff00]/20 animate-pulse mix-blend-color-dodge z-0 pointer-events-none" />
          )}

          {/* Legendary pulsing halo backshadow */}
          {r === 'LEGENDARY' && (
            <div 
              className="absolute inset-[15%] rounded-full animate-ping opacity-35 z-0" 
              style={{ backgroundColor: customAvatarItem.color }}
            />
          )}

          {/* Epic nested border card */}
          {r === 'EPIC' && (
            <div className="absolute inset-[8%] border border-[#ffffff]/15 pointer-events-none z-10" />
          )}

          {/* Rare slight background noise indicator or vignette */}
          {r === 'RARE' && (
            <div className="absolute inset-0 bg-black/15 mix-blend-overlay z-0" />
          )}

          {/* Central insignia icon */}
          <div className="relative z-10 drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)] flex items-center justify-center">
            <IconComponent 
              className={`text-white transition-transform ${
                r === 'LIMITED' 
                  ? 'animate-bounce-slow h-[110%] w-[110%]' 
                  : r === 'LEGENDARY' 
                    ? 'animate-pulse' 
                    : ''
              }`}
              style={{ 
                color: customAvatarItem.color,
                strokeWidth: r === 'COMMON' ? 1.5 : 2 
              }}
              size={size === 'xl' ? 44 : size === 'lg' ? 28 : size === 'sm' ? 12 : 16}
            />
          </div>

          {/* Small corner tags for LIMITED/LEGENDARY */}
          {r === 'LIMITED' && (
            <div className="absolute bottom-1 right-1 text-[7px] font-mono select-none px-1 py-0.5 bg-yellow-500 text-black leading-none uppercase font-black tracking-widest leading-none z-20 scale-[0.85] rounded-[1px]">
              LTD
            </div>
          )}
          {r === 'LEGENDARY' && (
            <div className="absolute bottom-1 right-1 text-[7px] font-mono select-none px-1 py-0.5 bg-red-600 text-white leading-none uppercase font-black tracking-widest leading-none z-20 scale-[0.85] rounded-[1px]">
              LEG
            </div>
          )}
        </div>
      );
    }

    // Default Avatar (standard PNG)
    return (
      <img
        alt="User Profile"
        className="w-full h-full object-cover grayscale brightness-90 hover:grayscale-0 transition-all duration-300"
        src={avatarUrl}
        referrerPolicy="no-referrer"
      />
    );
  };

  return (
    <div 
      id={`avatar-frame-container-${frame.id}`}
      onClick={onClick}
      className={`relative flex items-center justify-center transition-all bg-[#121212] overflow-visible shrink-0 ${sizeClasses} ${
        onClick ? 'cursor-pointer hover:scale-105 active:scale-95' : ''
      }`}
      style={{
        outline: activeFrameId === 'CLASSIC' ? 'none' : `1px dashed ${frame.borderColor}55`,
        outlineOffset: '2px'
      }}
    >
      <style>{`
        @keyframes prts-spin-clockwise {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes prts-spin-counter {
          0% { transform: rotate(360deg); }
          100% { transform: rotate(0deg); }
        }
        @keyframes prts-float-up-particle {
          0% { transform: translateY(110%) translateX(var(--px, 0px)) scale(0.6); opacity: 0; }
          20% { opacity: 0.95; }
          80% { opacity: 0.95; }
          100% { transform: translateY(-30%) translateX(calc(var(--px, 0px) + var(--pdx, 8px))) scale(1.2); opacity: 0; }
        }
        @keyframes prts-scanning {
          0% { transform: translateY(-110%); }
          50% { transform: translateY(110%); }
          100% { transform: translateY(-110%); }
        }
        @keyframes prts-wave-pulse {
          0% { transform: scale(0.2) translate(-50%, -50%); opacity: 0.95; }
          100% { transform: scale(1.6) translate(-50%, -50%); opacity: 0; }
        }
        @keyframes prts-hologram-shiver {
          0%, 100% { transform: translate(0, 0) scale(1); filter: hue-rotate(0deg) saturate(1); }
          20% { transform: translate(-1px, 1px) scale(1.01); filter: hue-rotate(4deg) saturate(1.1); }
          40% { transform: translate(1px, -1px) scale(0.99); filter: hue-rotate(-4deg); }
          60% { transform: translate(-0.5px, -0.5px) scale(1); filter: hue-rotate(2deg) saturate(1.05); }
          80% { transform: translate(1px, 1px) scale(1.02); filter: hue-rotate(-2deg); }
        }
        @keyframes prts-stream-binary {
          0% { transform: translateY(-50%); }
          100% { transform: translateY(0%); }
        }
        @keyframes prts-glitch-flicker {
          0%, 100% { opacity: 0.05; transform: scaleY(1); }
          10% { opacity: 0.6; transform: scaleY(1.5) skewX(5deg); }
          12% { opacity: 0.1; }
          48% { opacity: 0.08; transform: scaleY(0.8); }
          50% { opacity: 0.7; transform: scaleY(1.2) translateX(3px) skewX(-10deg); }
          52% { opacity: 0.05; }
          85% { opacity: 0.5; transform: scaleY(1) translateX(-3px); }
        }
        @keyframes prts-rose-float {
          0% { transform: translateY(110%) rotate(0deg); opacity: 0; }
          20% { opacity: 0.7; }
          80% { opacity: 0.7; }
          100% { transform: translateY(-20%) rotate(360deg); opacity: 0; }
        }
        @keyframes prts-slash-glint {
          0% { transform: scale(0) rotate(-45deg); opacity: 0; }
          15% { transform: scale(1) rotate(-45deg); opacity: 1; }
          25% { transform: scale(1.05) rotate(-45deg); opacity: 1; filter: brightness(1.6); }
          45% { transform: scale(1) rotate(-45deg); opacity: 0.2; }
          100% { transform: scale(0) rotate(-45deg); opacity: 0; }
        }
        @keyframes prts-wind-vector {
          0% { stroke-dashoffset: 60; }
          100% { stroke-dashoffset: 0; }
        }
        @keyframes prts-rain-fall {
          0% { transform: translateY(-110%) translateX(-40%); opacity: 0; }
          30% { opacity: 0.6; }
          80% { opacity: 0.6; }
          100% { transform: translateY(110%) translateX(40%); opacity: 0; }
        }
      `}</style>

      {/* Outer frame styling */}
      <div className={`absolute inset-0 z-20 pointer-events-none rounded-none ${frame.className}`} />

      {/* Frame decoration corners */}
      {activeFrameId === 'ELITE' && (
        <>
          <Star className="absolute -top-1.5 -right-1.5 w-3 h-3 text-[#ffd700] fill-[#ffd700] z-30 animate-spin-slow" />
          <div className="absolute -bottom-1 -left-1 w-1.5 h-1.5 bg-[#ffd700] z-30" />
        </>
      )}

      {activeFrameId === 'SYRACUSE' && (
        <>
          <div className="absolute -top-1 -left-1 w-2 h-0.5 bg-[#ff4b4b] z-30" />
          <div className="absolute -bottom-1 -right-1 w-2 h-0.5 bg-[#ff4b4b] z-30" />
          <div className="absolute top-1/2 -right-1 w-1 h-1 bg-white z-30" />
        </>
      )}

      {activeFrameId === 'LATERANO' && (
        <div className="absolute inset-[-4px] border border-[#cc55ff]/30 animate-pulse z-0 pointer-events-none" />
      )}

      {/* NEW GACHA-EXCLUSIVE DECORATIONS */}
      {activeFrameId === 'FRAME_YATO_TACTICAL' && (
        <div className="absolute top-1 inset-x-2 h-0.5 bg-red-600/80 animate-pulse z-30" />
      )}

      {activeFrameId === 'FRAME_PLUME_WINGED' && (
        <>
          <div className="absolute top-1 left-1 w-2 h-1.5 bg-zinc-200 rotate-12 z-30 border border-zinc-400" />
          <div className="absolute bottom-1 right-1 w-2 h-1.5 bg-zinc-200 rotate-12 z-30 border border-zinc-400" />
        </>
      )}

      {activeFrameId === 'FRAME_MELANTHA_ROSE' && (
        <>
          <div className="absolute top-0 right-0 w-2 h-2 bg-purple-700 rounded-full z-30 border border-white/20 animate-pulse" />
          <div className="absolute bottom-1 left-1 w-1.5 h-1.5 bg-purple-500 rounded-full z-30 opacity-70" />
        </>
      )}

      {activeFrameId === 'FRAME_FANG_ADVANCED' && (
        <>
          <div className="absolute -top-1 -left-1 w-2 h-2 border-t border-l border-teal-300 z-30" />
          <div className="absolute -top-1 -right-1 w-2 h-2 border-t border-r border-teal-300 z-30" />
          <div className="absolute -bottom-1 -left-1 w-2 h-2 border-b border-l border-teal-300 z-30" />
          <div className="absolute -bottom-1 -right-1 w-2 h-2 border-b border-r border-teal-300 z-30" />
        </>
      )}

      {activeFrameId === 'FRAME_AMIYA_RING' && (
        <>
          <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-4 h-1.5 rounded-full bg-black border border-cyan-400 animate-pulse z-30" />
          <div className="absolute top-1.5 left-1 w-1.5 h-1.5 rounded-full bg-cyan-400 z-30" />
          <div className="absolute bottom-1.5 right-1 w-1.5 h-1.5 rounded-full bg-cyan-400 z-30" />
        </>
      )}

      {activeFrameId === 'FRAME_CHEN_DRACONIC' && (
        <>
          {/* Dragon horns & badge plate decoration */}
          <div className="absolute -top-2 left-1.5 w-1 h-3 bg-[#ff2255] z-30 border border-black rotate-[-15deg] shadow-md-red" />
          <div className="absolute -top-2 right-1.5 w-1 h-3 bg-[#ff2255] z-30 border border-black rotate-[15deg] shadow-md-red" />
          <div className="absolute bottom-0 right-1 w-2 h-2 bg-yellow-600/40 border border-yellow-500/80 rounded-sm z-30 flex items-center justify-center text-[5px] text-yellow-300 font-bold scale-[0.8]">LGD</div>
        </>
      )}

      {activeFrameId === 'FRAME_TEXAS_WOLF' && (
        <>
          {/* Crossed energy sabers pins at the bottom */}
          <div className="absolute bottom-0.5 left-1/2 -translate-x-1/2 whitespace-nowrap z-30 scale-75">
            <div className="inline-block w-4 h-1 bg-yellow-400 rotate-[20deg] border border-white brightness-125 z-30" />
            <div className="inline-block w-4 h-1 bg-yellow-400 rotate-[-20deg] border border-white brightness-125 z-30 -ml-1.5" />
          </div>
          <div className="absolute -top-1 left-2 w-1.5 h-1.5 bg-yellow-400 rounded-full z-30 animate-ping" />
        </>
      )}

      {activeFrameId === 'FRAME_MOSTIMA_TIME' && (
        <>
          {/* Infinite clock halo indicators */}
          <div className="absolute inset-[-6px] border border-violet-500/30 rounded-full animate-spin z-0 pointer-events-none" style={{ animationDuration: '10s' }} />
          <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-gradient-to-r from-violet-400 to-indigo-400 rounded-full z-30 border border-black animate-pulse" />
          <div className="absolute bottom-0 right-1 w-1.5 h-1.5 bg-cyan-400 rounded-full z-30" />
        </>
      )}

      {activeFrameId === 'FRAME_W_EMBER' && (
        <>
          {/* SARKAZ DEMON HORNS & PULSATING BURST AT CORNERS */}
          <div className="absolute -top-2.5 left-0 w-3.5 h-3.5 text-red-500 z-30 drop-shadow-[0_0_8px_#ff1a00]">
            {/* Left horn curved geometry */}
            <svg viewBox="0 0 24 24" className="w-full h-full fill-current">
              <path d="M18,22 C18,14 12,6 4,4 C10,12 14,18 18,22 Z" />
            </svg>
          </div>
          <div className="absolute -top-2.5 right-0 w-3.5 h-3.5 text-red-500 z-30 drop-shadow-[0_0_8px_#ff1a00] scale-x-[-1]">
            {/* Right horn curved geometry */}
            <svg viewBox="0 0 24 24" className="w-full h-full fill-current">
              <path d="M18,22 C18,14 12,6 4,4 C10,12 14,18 18,22 Z" />
            </svg>
          </div>
          {/* Spark lights */}
          <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-4 h-1 bg-[#ffd700] rounded-full z-30 animate-pulse" />
          <div className="absolute top-1.5 left-1.5 w-1 h-1 bg-yellow-400 rounded-full z-30 animate-bounce" />
          <div className="absolute bottom-2 right-1 w-1 h-1 bg-red-500 rounded-full z-30 animate-ping" />
        </>
      )}

      {/* Inner Avatar Content (Image or Programmatic design) */}
      <div className="w-full h-full p-[2px] overflow-hidden">
        {renderAvatarContent()}
      </div>
    </div>
  );
}
