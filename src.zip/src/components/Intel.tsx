import { useState, useEffect } from 'react';
import { ShieldAlert, Zap, Cpu, RefreshCw, Loader2, Sparkles, AlertOctagon } from 'lucide-react';
import { UserProgress, WordLevel } from '../types';
import IntelChat from './IntelChat';
import { VOCABULARY_DATABASE } from '../data';

interface IntelProps {
  progress: UserProgress;
  currentLevel: WordLevel;
}

export default function Intel({ progress, currentLevel }: IntelProps) {
  const [loading, setLoading] = useState(false);
  const [advice, setAdvice] = useState<string | null>(null);
  const [missedBreakdown, setMissedBreakdown] = useState<any[] | null>(null);
  const [expansionWords, setExpansionWords] = useState<any[] | null>(null);
  const [logIndex, setLogIndex] = useState(0);

  const logs = [
    `[PRTS] ACCESSED SYSTEM REGISTERS...`,
    `[PRTS] EXTRACTING DATA VECTOR SYNC CORRELATIONS...`,
    `[PRTS] DETECTING DISCREPANCIES IN SECTOR ${currentLevel}...`,
    `[PRTS] ENGAGING COGNITIVE LOGIC GROUNDING CORE...`,
    `[PRTS] CONNECTING GEMINI AI COMMAND GATEWAY...`,
    `[PRTS] TRANSMITTING INTEGRITY COEFFICIENT MAP...`,
    `[PRTS] RECONSTRUCTING HIGH-ENERGY STRATEGY ADVICE...`,
    `[PRTS] SYSTEM ADVICE MATRICES RESOLVED SUCCESSFULLY...`
  ];

  const fetchAdvice = async () => {
    setLoading(true);
    setAdvice(null);
    setMissedBreakdown([]);
    setExpansionWords([]);
    setLogIndex(0);

    // Simulated log stream timing for premium feel
    const interval = setInterval(() => {
      setLogIndex((prev) => (prev < logs.length - 1 ? prev + 1 : prev));
    }, 450);

    // Map missed words details to feed into the prompt
    const missedWordDetails = Object.keys(progress.missedWords || {})
      .filter(id => (progress.missedWords[id] || 0) > 0)
      .map(id => {
        const found = VOCABULARY_DATABASE.find(w => w.id === id);
        return found ? {
          word: found.word,
          meaning: found.meaning,
          sentence: found.sentence,
          sentenceChinese: found.sentenceChinese,
          errorCount: progress.missedWords[id]
        } : null;
      })
      .filter(Boolean);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          missedWords: progress.missedWords,
          missedWordsDetails: missedWordDetails,
          totalAttempts: progress.totalAttempts,
          correctAttempts: progress.correctAttempts,
          completedWords: progress.completedWordIds,
          currentLevel: currentLevel
        }),
      });
      const data = await response.json();
      if (data.adviceData) {
        setAdvice(data.adviceData.generalRecommendationChinese || data.adviceData.generalRecommendation);
        setMissedBreakdown(data.adviceData.missedAnalysis || []);
        setExpansionWords(data.adviceData.expandWords || []);
      } else {
        setAdvice(data.advice);
        setMissedBreakdown([]);
        setExpansionWords([]);
      }
    } catch (err) {
      console.error(err);
      setAdvice('[ERROR: INTEL_DECRYPTION_OFFLINE] - Unable to establish proxy handshake with PRTS Command center.');
    } finally {
      clearInterval(interval);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdvice();
  }, [currentLevel, progress.totalAttempts]);

  // Overall calculations
  const totalAnomalies = Object.keys(progress.missedWords).length;
  const combatEfficiency = progress.totalAttempts > 0 
    ? Math.round((progress.correctAttempts / progress.totalAttempts) * 100)
    : 0;

  return (
    <div className="max-w-[768px] mx-auto space-y-6 pb-24 md:pb-8 font-mono">
      {/* Header */}
      <div className="border-l-4 border-[#00e0b3] pl-6 py-2">
        <h2 className="text-3xl text-white font-bold tracking-tighter uppercase">
          COGNITIVE EVALUATION // 認知戰術評估
        </h2>
        <p className="text-[#00e0b3] text-xs uppercase tracking-widest mt-1">
          Diagnostics and Tactical Recommendations for Operator_001. ┃ 提供 Doctor 專屬的戰術優化診斷報告。
        </p>
      </div>

      {/* Main Command Box */}
      <section className="bg-[#1c1b1b] border border-[#3a4a44] p-6 relative overflow-hidden">
        {/* chamfer style decoration */}
        <div className="absolute top-0 right-0 w-3 h-3 bg-[#0e0e0e] rotate-45 transform translate-x-1.5 -translate-y-1.5 border-b border-[#3a4a44]" />

        <div className="flex items-center gap-3 border-b border-[#3a4a44]/35 pb-3">
          <Cpu className="w-5 h-5 text-[#00e0b3]" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            PRTS Tactical EVALUATION AI // PRTS 智能評估中樞
          </h3>
          <span className="text-[9px] text-[#ffb870] bg-[#ffb870]/10 border border-[#ffb870]/20 px-2 py-0.5 ml-auto font-bold animate-pulse uppercase">
            LIVE_LINK
          </span>
        </div>

        {loading ? (
          <div className="py-12 flex flex-col justify-center items-center min-h-[180px]">
            <Loader2 className="w-8 h-8 text-[#00e0b3] animate-spin mb-4" />
            <div className="text-center space-y-1 font-mono text-xs text-[#00e0b3] max-w-sm">
              <p className="animate-pulse tracking-widest font-bold">DECRYPTING COGNITIVE DATA... // 正在解密與生成優化診斷...</p>
              <p className="text-[#b9cbc2]/40 text-[10px] mt-2 block">{logs[logIndex]}</p>
            </div>
          </div>
        ) : (
          <div className="py-6 min-h-[180px] flex flex-col justify-between">
            <div className="space-y-6">
              <div className="text-[9px] text-[#b9cbc2]/45 uppercase flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#00e0b3] animate-pulse" />
                <span>Diagnostics decrypted // Timestamp: {new Date().toLocaleTimeString()} ┃ 報告已解密成功</span>
              </div>
              
              {/* General Recommendation Section */}
              <div className="bg-[#141414]/80 p-4 border-l-4 border-[#00e0b3] relative">
                <p className="text-[8px] text-[#00e0b3] uppercase tracking-widest font-mono font-bold mb-1">// COMMANDER_DECISION // 攻堅策略與建議</p>
                <div className="text-white text-[13px] sm:text-[14px] leading-relaxed font-sans whitespace-pre-line">
                  {advice}
                </div>
              </div>

              {/* Missed words breakdown section */}
              {missedBreakdown && missedBreakdown.length > 0 && (
                <div className="space-y-3 mt-4">
                  <p className="text-[9px] text-[#ffb870] uppercase tracking-widest font-mono font-bold flex items-center gap-1.5">// CRITICAL_ANOMALIES_RESOLVED // 關鍵錯題字彙及記憶點拆解</p>
                  <div className="grid grid-cols-1 gap-3">
                    {missedBreakdown.map((item, idx) => (
                      <div key={idx} className="bg-[#151515] border border-[#3a4a44]/50 p-4 relative">
                        <div className="absolute top-2 right-3 font-mono text-[8px] text-[#ffb870] border border-[#ffb870]/30 px-1 py-0.5 bg-[#ffb870]/5">
                          MUTATION RATIO // 偏離度高
                        </div>
                        <div className="flex items-baseline gap-2 mb-2">
                          <span className="text-[#00e0b3] text-lg font-bold font-mono">{item.word}</span>
                          <span className="text-[#e5e2e1] text-xs font-sans font-semibold">： {item.meaning}</span>
                        </div>
                        <div className="space-y-2 font-sans text-xs sm:text-sm text-[#b9cbc2]/80">
                          <p className="bg-[#ffb870]/5 border-l-2 border-[#ffb870] pl-2.5 py-1 text-white">
                            <strong className="text-[#ffb870] text-[11px] font-mono mr-1">MEMORY_HACK // 記憶竅門:</strong> {item.mnemonic}
                          </p>
                          <p className="text-[#b9cbc2]/70 text-[11px] sm:text-xs">
                            <strong className="text-[#b9cbc2]/90 font-semibold mr-1">CONTEXT_TIP // 語境提醒:</strong> {item.sentenceTip}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Directly translated expandWords section */}
              {expansionWords && expansionWords.length > 0 && (
                <div className="space-y-3 mt-6">
                  <p className="text-[9px] text-[#00e0b3] uppercase tracking-widest font-mono font-bold">// EXPANDED_COGNITIVE_VECTORS // 高頻生字直譯擴展 (自主研習)</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {expansionWords.map((item, idx) => (
                      <div key={idx} className="bg-[#121212] border border-[#3a4a44]/50 p-3.5 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-white text-sm font-bold font-mono tracking-wider">{item.word}</span>
                            <span className="text-[8px] bg-[#00e0b3]/10 text-[#00e0b3] border border-[#00e0b3]/30 px-1.5 py-0.5 font-mono">RELATED // 關聯</span>
                          </div>
                          <p className="text-[#00e0b3] text-xs font-sans font-semibold mb-2">{item.meaning}</p>
                          <p className="text-[#b9cbc2]/70 text-[11px] italic leading-relaxed font-sans mt-1 bg-white/5 p-2 rounded">
                            "{item.example}"
                          </p>
                        </div>
                        <div className="border-t border-[#3a4a44]/30 pt-2 mt-2.5 text-[10px] text-[#b9cbc2]/40 font-mono">
                          譯：{item.translation}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="mt-8 pt-4 border-t border-[#3a4a44]/20 flex justify-between items-center">
              <span className="text-[9px] text-[#b9cbc2]/30 uppercase tracking-widest">
                Source: Gemini AI Coordinator (Rhodes_Island_03)
              </span>
              
              <button
                onClick={fetchAdvice}
                className="text-xs text-[#00e0b3] hover:text-[#002118] hover:bg-[#00e0b3] border border-[#00e0b3]/30 px-3.5 py-1.5 transition-all flex items-center gap-2 active:scale-95 cursor-pointer font-bold font-sans"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>DIAGNOSE // 重新診斷</span>
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Overview Analytics board */}
      <section className="grid grid-cols-2 gap-4">
        <div className="bg-[#1c1b1b]/50 p-4 border border-[#3a4a44] relative overflow-hidden">
          <p className="text-[#b9cbc2]/70 font-mono text-[9px] uppercase tracking-widest">Combat Accuracy // 戰鬥答對效率</p>
          <p className="text-3xl text-white font-mono font-bold mt-1">{combatEfficiency}%</p>
          <div className="h-1 bg-[#3a4a44] w-full mt-3 overflow-hidden">
            <div className="h-full bg-[#00e0b3]" style={{ width: `${combatEfficiency}%` }} />
          </div>
        </div>

        <div className="bg-[#1c1b1b]/50 p-4 border border-[#3a4a44] relative overflow-hidden">
          <p className="text-[#b9cbc2]/70 font-mono text-[9px] uppercase tracking-widest">Detected Anomalies // 錯題待建段</p>
          <p className="text-3xl text-white font-mono font-bold mt-1">{totalAnomalies}</p>
          <div className="h-1 bg-[#3a4a44] w-full mt-3 overflow-hidden">
            <div
              className={`h-full ${totalAnomalies > 5 ? 'bg-[#ff9800]' : 'bg-[#00e0b3]'}`}
              style={{ width: `${Math.min(100, (totalAnomalies / 16) * 100)}%` }}
            />
          </div>
        </div>
      </section>

      {/* Conversational AI Word Explainer Chat & Quiz Generator */}
      <IntelChat />

      {/* Simulated CLI Log scroll box */}
      <section className="bg-[#0e0e0e] border border-[#3a4a44]/50 p-4 font-mono text-[10px] text-[#b9cbc2]/50 uppercase space-y-1 overflow-hidden">
        <p className="text-[#00e0b3] text-xs pb-1 border-b border-[#3a4a44]/20">// RE-EDUCATION TELEMETRY FEED (GUEST_MODE_001)</p>
        <p>&gt; SECURE PORT ACQUIRED FOR COGNITIVE HANDSHAKE</p>
        <p>&gt; SYSTEM_SYNC_PERCENTAGE: {combatEfficiency}% SUCCESS RATE</p>
        <p>&gt; BUFFER_DISCREPANCIES_DETECTED: {totalAnomalies} CRITICAL ANOMALIES</p>
        <p>&gt; ACTIVE_TARGET_VECTORS: [{currentLevel}] MISSION MODULES</p>
        <p className="text-[#00e0b3]/50">&gt; DIAGNOSTICS DECODER CORE STANDBY // OPTIMAL LINK FORWARDED</p>
      </section>
    </div>
  );
}
