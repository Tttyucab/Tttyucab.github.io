import { useState } from 'react';
import { Search, Loader2, Sparkles, X, ShieldAlert, CheckCircle2, Flame, Play, HelpCircle, RefreshCw } from 'lucide-react';
import { VocabularyWord, UserProgress } from '../types';

interface ArchivesProps {
  words: VocabularyWord[];
  progress: UserProgress;
  onReviewWord: (word: VocabularyWord) => void;
}

export default function Archives({ words, progress, onReviewWord }: ArchivesProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [storyModalOpen, setStoryModalOpen] = useState(false);
  const [generatingStory, setGeneratingStory] = useState(false);
  const [generatedStory, setGeneratedStory] = useState<string | null>(null);

  // Filter missed words based on search term
  const missedWordIds = Object.keys(progress.missedWords);
  
  const filteredWords = words.filter((word) => {
    const isMissed = missedWordIds.includes(word.id);
    const matchesSearch = 
      word.word.toLowerCase().includes(searchTerm.toLowerCase()) ||
      word.meaning.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  // Sort them so missed words stay on top
  const sortedWords = [...filteredWords].sort((a, b) => {
    const aMissed = progress.missedWords[a.id] || 0;
    const bMissed = progress.missedWords[b.id] || 0;
    return bMissed - aMissed; // higher missed counts on top
  });

  // Calculate correctness rate / synchronization rate
  const syncRate = progress.totalAttempts > 0 
    ? Math.round((progress.correctAttempts / progress.totalAttempts) * 100)
    : 0; // default fallback matching mockup

  const handleStoryReconstruction = async () => {
    // If no missed words, take the first 3 words in the database to showcase the feature
    const missedWordsToUse = missedWordIds.length > 0 
      ? words.filter(w => missedWordIds.includes(w.id)).map(w => w.word)
      : words.slice(0, 3).map(w => w.word);

    setStoryModalOpen(true);
    setGeneratingStory(true);
    setGeneratedStory(null);

    try {
      const response = await fetch('/api/reconstruct-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ missedWords: missedWordsToUse }),
      });
      const data = await response.json();
      setGeneratedStory(data.story);
    } catch (err) {
      console.error(err);
      setGeneratedStory('[ERROR: SIGNAL_DECRYPT_FAILED] - Could not establish synchronous link with Gemini AI host.');
    } finally {
      setGeneratingStory(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto space-y-6 pb-24 md:pb-8 font-mono">
      {/* Header and Action row */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-l-4 border-[#00e0b3] pl-6 py-2">
        <div>
          <h2 className="text-3xl md:text-4xl text-white font-bold tracking-tighter uppercase">
            ARCHIVES // NOTEBOOK // 核心學習存檔
          </h2>
          <p className="text-[#00e0b3] text-xs uppercase tracking-widest mt-1">
            Analysis of {missedWordIds.length || 14} non-standard linguistic patterns detected. ┃ 已檢測到異常編譯字詞段
          </p>
        </div>

        {/* Story Reconstruction AI Trigger */}
        <button
          onClick={handleStoryReconstruction}
          className="flex items-center gap-3 px-6 py-3 bg-[#1c1b1b] border border-[#00e0b3] text-[#00e0b3] font-bold text-xs tracking-widest transition-all group overflow-hidden cursor-pointer hover:bg-[#00e0b3] hover:text-[#002118]"
        >
          <Sparkles className="w-4 h-4 animate-pulse group-hover:scale-110" />
          <span>STORY RECONSTRUCTION // 情境重建</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative group">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#00e0b3]">
          <Search className="w-5 h-5" />
        </span>
        <input
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-4 bg-[#1c1b1b] border-b-2 border-[#3a4a44] focus:border-[#00e0b3] focus:ring-0 transition-all text-[#e5e2e1] placeholder:text-[#b9cbc2]/30 rounded-none text-sm font-sans"
          placeholder="SEARCH_DATABASE_FOR_KEYWORDS... // 搜尋系統字彙或中文釋義..."
          type="text"
        />
      </div>

      {/* Main Grid split: Words list vs stats sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Word Card Stack */}
        <section className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between border-b border-[#3a4a44]/30 pb-2">
            <h4 className="text-xs text-[#b9cbc2] uppercase flex items-center gap-2 tracking-widest font-bold">
              <span className="w-2 h-2 bg-[#00e0b3]" />
              Prioritize_Data_Correction // 優先核心數據修正
            </h4>
            <span className="text-[10px] text-[#ffb4ab] uppercase tracking-wider font-semibold">
              Security Clearance: ALPHA
            </span>
          </div>

          <div className="space-y-3">
            {sortedWords.length === 0 ? (
              <div className="p-8 text-center text-[#b9cbc2]/40 bg-[#1c1b1b] border border-[#3a4a44]/35 text-xs">
                NO SECTORS MATCHING QUERY AT THE TIME. ┃ 暫無符合查詢之詞彙段
              </div>
            ) : (
              sortedWords.map((word) => {
                const missedCount = progress.missedWords[word.id] || 0;
                const lastAttemptTime = progress.lastSyncTimes[word.id] || 'NEVER';

                return (
                  <div
                    key={word.id}
                    className="relative bg-[#1c1b1b] p-5 border border-[#3a4a44]/30 hover:bg-[#201f1f] transition-all group overflow-hidden"
                  >
                    {/* corners decorations */}
                    <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-[#00e0b3]" />
                    <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-[#00e0b3]" />

                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <div className="flex items-center gap-3">
                          <h3 className="text-xl text-[#00e0b3] font-bold tracking-tight uppercase group-hover:translate-x-1 transition-transform">
                            {word.word}
                          </h3>
                          <span className="text-[9px] text-[#b9cbc2]/60 bg-[#0e0e0e] px-2 py-0.5 border border-[#3a4a44]/70 font-semibold uppercase">
                            {word.id}
                          </span>
                        </div>
                        <p className="text-[#e5e2e1] text-sm mt-1.5 font-sans font-bold">釋義：{word.meaning}</p>
                        <p className="text-[#b9cbc2]/80 text-xs mt-1 italic font-sans">例句：{word.sentenceChinese}</p>
                      </div>

                      <div className="flex flex-col items-end">
                        {missedCount > 0 ? (
                          <div className="text-xs text-[#ffb4ab] bg-[#93000a]/10 border border-[#ffb4ab]/20 px-3 py-1 flex items-center gap-1.5 font-bold">
                            <ShieldAlert className="w-3.5 h-3.5 animate-pulse" />
                            <span>MISSED: {String(missedCount).padStart(2, '0')} 次錯題</span>
                          </div>
                        ) : (
                          <div className="text-xs text-[#00e0b3] bg-[#00e0b3]/5 border border-[#00e0b3]/20 px-3 py-1 flex items-center gap-1.5 font-bold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>VERIFIED // 精通已驗證</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="mt-5 flex justify-between items-center text-[10px] text-[#b9cbc2]/50 uppercase tracking-widest">
                      <span>LST_SYNC // 上次驗證: {lastAttemptTime}</span>
                      
                      <button
                        onClick={() => onReviewWord(word)}
                        className="text-[#00e0b3] flex items-center gap-1.5 hover:bg-[#00e0b3] hover:text-[#002118] px-3 py-1 transition-all border border-[#00e0b3]/20 active:scale-95 cursor-pointer font-bold font-sans"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>啟動複習測試 EX_QUIZ.SH</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* Stats Sidebar */}
        <aside className="lg:col-span-4 space-y-4">
          
          {/* Integrity status */}
          <div className="bg-[#1c1b1b] p-6 border border-[#3a4a44] relative overflow-hidden">
            <h3 className="text-xs text-white uppercase mb-5 flex items-center gap-2 font-bold tracking-widest">
              <span className="w-1.5 h-1.5 bg-[#00e0b3]" />
              INTEGRITY_STATUS // 內存完整度
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1.5 text-[11px] font-bold">
                  <span className="text-[#b9cbc2] uppercase">SYNCHRONIZATION_RATE // 精通同步率</span>
                  <span className="text-[#00e0b3]">{syncRate}.00%</span>
                </div>
                <div className="h-1 w-full bg-[#3a4a44]/30 overflow-hidden">
                  <div
                    className="h-full bg-[#00e0b3] shadow-[0_0_8px_rgba(0,224,179,0.5)] transition-all duration-500"
                    style={{ width: `${syncRate}%` }}
                  />
                </div>
              </div>
              <p className="text-[10px] text-[#b9cbc2]/60 leading-relaxed border-t border-[#3a4a44]/25 pt-3 uppercase">
                // ANALYSIS COMPLETE // 診斷意見： <br />
                {progress.completedWordIds.length > 0 
                  ? `Operator verified ${progress.completedWordIds.length} segments this cycle. Re-focus is instructed on critical remaining anomalies.`
                  : `Select level simulation to acquire active vocabulary telemetry. Database stands operational.`}
              </p>
            </div>
          </div>

          {/* Concurrent streak */}
          <div className="bg-[#201f1f] p-6 border-l-4 border-[#ffb870] relative overflow-hidden">
            <h3 className="text-[#ffb870] uppercase mb-4 text-xs font-bold tracking-widest">
              OPERATIONAL_STREAK // 連續學習天數
            </h3>
            <div className="flex items-end gap-3">
              <span className="text-5xl text-white tracking-tighter font-mono font-bold leading-none">
                {progress.currentStreak}
              </span>
              <span className="text-[10px] text-[#b9cbc2]/60 uppercase tracking-wider pb-1 font-semibold block">
                CONCURRENT_CYCLES ┃ 連續周期天數
              </span>
            </div>
            <div className="absolute right-3 bottom-2 text-[#ffb870]/5">
              <Flame className="w-16 h-16 pointer-events-none" />
            </div>
          </div>
        </aside>
      </div>

      {/* AI Story Reconstruction overlay modal */}
      {storyModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div
            onClick={() => setStoryModalOpen(false)}
            className="absolute inset-0 bg-[#0e0e0e]/90 backdrop-blur-sm"
          />
          <div className="relative bg-[#131313] border border-[#00e0b3] w-full max-w-2xl overflow-hidden shadow-[0_0_55px_rgba(0,0,0,0.85)] max-h-[90vh] flex flex-col">
            
            {/* Modal header */}
            <div className="bg-[#00e0b3] p-4 flex justify-between items-center text-[#002118]">
              <div className="flex items-center gap-3">
                <Sparkles className="w-5 h-5" />
                <h3 className="text-xs font-mono font-bold tracking-widest">
                  COGNITIVE_RECONSTRUCTION // 戰術智能情境故事重建
                </h3>
              </div>
              <button
                onClick={() => setStoryModalOpen(false)}
                className="hover:bg-black/15 p-1 rounded-sm text-[#002118] cursor-pointer"
              >
                <X className="w-5 h-5 font-bold" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-grow">
              <div className="text-[9px] text-[#b9cbc2]/40 uppercase border-b border-[#3a4a44]/30 pb-2">
                TIMESTAMP: {new Date().toISOString().replace('T', ' ').substring(0, 19)} // MEMORY_LINK_AI_STORY
              </div>

              {generatingStory ? (
                <div className="py-12 flex flex-col items-center justify-center gap-3 text-sm text-[#00e0b3]">
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <span className="tracking-widest text-xs animate-pulse font-bold font-sans">正在與核心戰術 AI 聯網，生成您的專屬聯想情境故事...</span>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="text-sm sm:text-base text-[#e5e2e1] leading-relaxed border-l-2 border-[#00e0b3]/30 pl-6 space-y-4">
                    {/* Render paragraphs if it contains double newlines, supporting both English/Chinese segments */}
                    {generatedStory?.split('\n\n').map((p, idx) => (
                      <p key={idx} className="font-sans leading-relaxed whitespace-pre-line text-white">
                        {p}
                      </p>
                    ))}
                  </div>

                  <div className="pt-4 border-t border-[#3a4a44]/20">
                    <p className="text-[9px] text-[#00e0b3] uppercase tracking-widest mb-2 font-bold">// Target Terms Resolved // 本次融合記憶目標詞彙</p>
                    <div className="flex flex-wrap gap-2">
                      {(missedWordIds.length > 0 
                        ? words.filter(w => missedWordIds.includes(w.id)).map(w => w.word)
                        : words.slice(0, 3).map(w => w.word)
                      ).map((wStr) => (
                        <span
                          key={wStr}
                          className="px-2.5 py-1 bg-[#1c1b1b] text-[#00e0b3] border border-[#00e0b3]/30 text-[10px] font-bold tracking-wider"
                        >
                          {wStr}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Action buttons footer */}
              {!generatingStory && (
                <div className="mt-8 flex flex-col sm:flex-row gap-3 pt-2">
                  <button
                    onClick={handleStoryReconstruction}
                    className="flex-1 flex items-center justify-center gap-2 bg-[#00e0b3] text-[#002118] py-3 text-xs font-bold font-mono tracking-widest hover:brightness-110 transition-all cursor-pointer border border-[#00e0b3]"
                  >
                    <RefreshCw className="w-4 h-4" />
                    REGENERATE_STORY // 重新生成情境
                  </button>
                  <button
                    onClick={() => setStoryModalOpen(false)}
                    className="flex-1 flex items-center justify-center gap-2 bg-[#2a2a2a] text-[#e5e2e1] py-3 text-xs font-bold font-mono tracking-widest hover:bg-[#353534] transition-all cursor-pointer border border-[#3a4a44]"
                  >
                    <span>CLOSE MODULE // 關閉模組</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
