import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Trash2, Edit2, RotateCw, ChevronLeft, ChevronRight, 
  Search, Shuffle, BookOpen, Check, AlertCircle, Save, X, Layers,
  Play, ArrowLeft, RefreshCw, Sparkles, ThumbsUp, ThumbsDown
} from 'lucide-react';
import { CustomFlashcard } from '../types';

interface CustomStudyProps {
  onNotifyToast: (text: string, isCorrect: boolean) => void;
}

interface CustomDeck {
  id: string;
  name: string;
  cards: CustomFlashcard[];
  createdAt: number;
}

const DEFAULT_CARDS: CustomFlashcard[] = [
  { id: 'custom-1', english: 'Rhodes Island', translation: '羅德島 (製藥公司，醫療及戰術自救組織)', createdAt: Date.now() - 3000 },
  { id: 'custom-2', english: 'Tactical Memorization', translation: '戰術記憶 (旨在提高神經突觸對外文符號的突發連攜速度)', createdAt: Date.now() - 2000 },
  { id: 'custom-3', english: 'Doctor', translation: '博士 (羅德島戰術指揮官，深自記憶深處引導作戰)', createdAt: Date.now() - 1000 },
];

export default function CustomStudy({ onNotifyToast }: CustomStudyProps) {
  // Read and load decks from local storage, with legacy single list fallback and automated migration
  const [decks, setDecks] = useState<CustomDeck[]>(() => {
    const savedDecks = localStorage.getItem('lexiquiz_tactical_custom_decks');
    if (savedDecks) {
      try {
        const parsed = JSON.parse(savedDecks);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse custom decks path', e);
      }
    }

    // Attempt migration from legacy custom cards storage key
    const legacyCardsRaw = localStorage.getItem('lexiquiz_tactical_custom_cards');
    let legacyCards = DEFAULT_CARDS;
    if (legacyCardsRaw) {
      try {
        legacyCards = JSON.parse(legacyCardsRaw);
      } catch (e) {}
    }

    return [
      {
        id: 'deck-default',
        name: '預設戰術核心 // DEFAULT_TACTICS',
        cards: legacyCards,
        createdAt: Date.now()
      }
    ];
  });

  const [activeDeckId, setActiveDeckId] = useState<string>(() => {
    const savedActive = localStorage.getItem('lexiquiz_tactical_active_deck_id');
    if (savedActive && decks.some(d => d.id === savedActive)) {
      return savedActive;
    }
    return decks[0]?.id || 'deck-default';
  });

  // Controls for Deck / Combination operations
  const [isCreatingDeck, setIsCreatingDeck] = useState(false);
  const [newDeckName, setNewDeckName] = useState('');
  const [isRenamingDeck, setIsRenamingDeck] = useState(false);
  const [renameDeckValue, setRenameDeckValue] = useState('');
  const [deckToDeleteId, setDeckToDeleteId] = useState<string | null>(null);

  // Save changes to local storage when state changes
  useEffect(() => {
    localStorage.setItem('lexiquiz_tactical_custom_decks', JSON.stringify(decks));
  }, [decks]);

  useEffect(() => {
    localStorage.setItem('lexiquiz_tactical_active_deck_id', activeDeckId);
  }, [activeDeckId]);

  // Derived state: Active deck and its corresponding cards array
  const activeDeck = decks.find(d => d.id === activeDeckId) || decks[0];
  const cards = activeDeck ? activeDeck.cards : [];

  const setCardsForActiveDeck = (newCards: CustomFlashcard[]) => {
    setDecks(prev => prev.map(d => {
      if (d.id === activeDeckId) {
        return {
          ...d,
          cards: newCards
        };
      }
      return d;
    }));
  };

  // Search and general state
  const [searchQuery, setSearchQuery] = useState('');
  const [newEnglish, setNewEnglish] = useState('');
  const [newTranslation, setNewTranslation] = useState('');
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [editEnglish, setEditEnglish] = useState('');
  const [editTranslation, setEditTranslation] = useState('');

  // Interactive Carousel state
  const [currentIndex, setCurrentIndex] = useState(0);
  // Default to true as the user requested "跳轉單字卡後為卡面的翻譯面" (Translation side shown after jump)
  const [isFlipped, setIsFlipped] = useState(true);
  const [defaultToTranslation, setDefaultToTranslation] = useState<boolean>(true);

  // Direct editing of translation face state
  const [isEditingBack, setIsEditingBack] = useState(false);
  const [backEditTranslation, setBackEditTranslation] = useState('');

  // Adjust Carousel Index when cards array length shifts
  useEffect(() => {
    if (currentIndex >= cards.length && cards.length > 0) {
      setCurrentIndex(cards.length - 1);
    } else if (cards.length === 0) {
      setCurrentIndex(0);
    }
  }, [cards.length]);

  // Reset back translation edit when moving to another card
  useEffect(() => {
    setIsEditingBack(false);
  }, [currentIndex]);

  // Form input validation feedback
  const [formError, setFormError] = useState<string | null>(null);

  // --- START OF HIGH-INTEGRATION COGNITIVE STUDY DRILL SYSTEM ---
  const [isTrainingMode, setIsTrainingMode] = useState<boolean>(false);
  const [trainingCards, setTrainingCards] = useState<CustomFlashcard[]>([]);
  const [trainingFails, setTrainingFails] = useState<CustomFlashcard[]>([]);
  const [trainingSuccesses, setTrainingSuccesses] = useState<CustomFlashcard[]>([]);
  const [trainingCurrentIdx, setTrainingCurrentIdx] = useState<number>(0);
  const [trainingDefaultFace, setTrainingDefaultFace] = useState<'front' | 'back'>('front');
  const [trainingShowFlipped, setTrainingShowFlipped] = useState<boolean>(false);
  const [dragOffset, setDragOffset] = useState<number>(0);

  // Initialize and Shuffle for Drills
  const startTraining = (defaultFace: 'front' | 'back' = 'front') => {
    if (cards.length === 0) {
      onNotifyToast('ERROR // 當前組別中無卡片，請先在右側新增卡片！', false);
      return;
    }
    const shuffled = [...cards].sort(() => 0.5 - Math.random());
    setTrainingCards(shuffled);
    setTrainingFails([]);
    setTrainingSuccesses([]);
    setTrainingCurrentIdx(0);
    setTrainingDefaultFace(defaultFace);
    setTrainingShowFlipped(false);
    setDragOffset(0);
    setIsTrainingMode(true);
    onNotifyToast('TACTICAL_TRAINING_INIT // 戰術卡組已隨機打亂，訓練開啟！', true);
  };

  // Card Swipe / Button click response handler
  const handleTrainingSwipe = (success: boolean) => {
    if (trainingCurrentIdx >= trainingCards.length) return;

    const currentCard = trainingCards[trainingCurrentIdx];
    if (success) {
      setTrainingSuccesses(prev => [...prev, currentCard]);
      onNotifyToast('COMPLETED // 太棒了！已標記為：學習成功', true);
    } else {
      setTrainingFails(prev => [...prev, currentCard]);
      onNotifyToast('FAILED // 已標記為：需要再次複習', false);
    }

    setTrainingCurrentIdx(prev => prev + 1);
    setTrainingShowFlipped(false);
    setDragOffset(0);
  };

  // Only train failed cards (再次打亂學習失敗的卡片)
  const handleDrillFailsOnly = () => {
    if (trainingFails.length === 0) return;
    const shuffled = [...trainingFails].sort(() => 0.5 - Math.random());
    setTrainingCards(shuffled);
    setTrainingFails([]);
    setTrainingSuccesses([]);
    setTrainingCurrentIdx(0);
    setTrainingShowFlipped(false);
    setDragOffset(0);
    onNotifyToast('RE_DRILL_FAILS // 已完成重載！僅對剛才記憶失敗的項目重複強化', true);
  };

  // Restart training completely
  const handleRestartAll = () => {
    startTraining(trainingDefaultFace);
  };

  // Keyboard navigation bindings
  useEffect(() => {
    if (!isTrainingMode || trainingCurrentIdx >= trainingCards.length) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        handleTrainingSwipe(false);
      } else if (e.key === 'ArrowRight') {
        handleTrainingSwipe(true);
      } else if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        setTrainingShowFlipped(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isTrainingMode, trainingCurrentIdx, trainingCards, trainingDefaultFace]);
  // --- END OF HIGH-INTEGRATION COGNITIVE STUDY DRILL SYSTEM ---

  // Create New Combination (開啟新組合)
  const handleCreateDeck = (e: React.FormEvent) => {
    e.preventDefault();
    const nameClean = newDeckName.trim();
    const finalName = nameClean || `自訂戰術組合 #${decks.length + 1} // MATRIX_${Date.now().toString().slice(-4)}`;

    const freshDeck: CustomDeck = {
      id: `deck-${Date.now()}`,
      name: finalName,
      cards: [
        {
          id: `custom-usr-init-${Date.now()}`,
          english: 'Initiate Link',
          translation: '建立神經連結 (點擊右側或此處進行自訂編輯)',
          createdAt: Date.now()
        }
      ],
      createdAt: Date.now()
    };

    setDecks(prev => [...prev, freshDeck]);
    setActiveDeckId(freshDeck.id);
    setNewDeckName('');
    setIsCreatingDeck(false);
    setCurrentIndex(0);
    setIsFlipped(defaultToTranslation);
    onNotifyToast('NEXUS_ESTABLISHED // 已成功開啟新存檔組合！', true);
  };

  // Rename Current Combination
  const handleRenameDeck = (e: React.FormEvent) => {
    e.preventDefault();
    const nameClean = renameDeckValue.trim();
    if (!nameClean) {
      onNotifyToast('ERROR // 組合名稱不能為空', false);
      return;
    }

    setDecks(prev => prev.map(d => {
      if (d.id === activeDeckId) {
        return {
          ...d,
          name: nameClean
        };
      }
      return d;
    }));

    setIsRenamingDeck(false);
    onNotifyToast('RENAME_SUCCESS // 儲存組合名稱修改完畢', true);
  };

  // Delete Combination (銷毀組合)
  const handleDeleteDeck = (idToDelete: string) => {
    if (decks.length <= 1) {
      onNotifyToast('PERMISSIONS_DENIED // 至少保留一個自訂戰術組合', false);
      return;
    }

    const remaining = decks.filter(d => d.id !== idToDelete);
    setDecks(remaining);
    setDeckToDeleteId(null);

    // If we deleted the active deck, fall back to the first available one
    if (activeDeckId === idToDelete) {
      const fallbackDeck = remaining[0];
      setActiveDeckId(fallbackDeck.id);
      setCurrentIndex(0);
      setIsFlipped(defaultToTranslation);
    }

    onNotifyToast('PURGED // 指定認知儲存組合已完全銷毀', false);
  };

  // Handle adding a card
  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const engClean = newEnglish.trim();
    const transClean = newTranslation.trim();

    if (!engClean) {
      setFormError('ENGLISH_EMPTY // 請填寫英文面文字');
      return;
    }
    if (!transClean) {
      setFormError('TRANSLATION_EMPTY // 請填寫翻譯面文字');
      return;
    }

    const newCard: CustomFlashcard = {
      id: `custom-usr-${Date.now()}`,
      english: engClean,
      translation: transClean,
      createdAt: Date.now()
    };

    setCardsForActiveDeck([...cards, newCard]);
    setNewEnglish('');
    setNewTranslation('');
    onNotifyToast('SUCCESS // 已成功新增自定義學習卡片！', true);
  };

  // Handle deleting a card
  const handleDeleteCard = (id: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    // Delete target card
    const targetCardIdx = cards.findIndex(c => c.id === id);
    if (targetCardIdx === -1) return;

    const updated = cards.filter(c => c.id !== id);
    setCardsForActiveDeck(updated);

    // Adjust Carousel Index if it is out of bounds
    if (currentIndex >= updated.length && updated.length > 0) {
      setCurrentIndex(updated.length - 1);
    } else if (updated.length === 0) {
      setCurrentIndex(0);
    }
    setIsFlipped(defaultToTranslation);
    onNotifyToast('ARCHIVE_DELETED // 已刪除自定義卡片存檔！', false);
  };

  // Handle editing initiating
  const startEditing = (card: CustomFlashcard) => {
    setEditingCardId(card.id);
    setEditEnglish(card.english);
    setEditTranslation(card.translation);
  };

  // Handle saving the edited card
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editEnglish.trim() || !editTranslation.trim()) {
      onNotifyToast('ERROR // 儲存內容不能為空', false);
      return;
    }

    setCardsForActiveDeck(cards.map(c => {
      if (c.id === editingCardId) {
        return {
          ...c,
          english: editEnglish.trim(),
          translation: editTranslation.trim()
        };
      }
      return c;
    }));

    setEditingCardId(null);
    onNotifyToast('UPDATE_SUCCESS // 卡片修改更新完畢', true);
  };

  // Carousel actions
  const nextCard = () => {
    if (cards.length === 0) return;
    setIsFlipped(defaultToTranslation);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % cards.length);
    }, 100);
  };

  // Previous card
  const prevCard = () => {
    if (cards.length === 0) return;
    setIsFlipped(defaultToTranslation);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length);
    }, 100);
  };

  // Shuffle active deck
  const shuffleCards = () => {
    if (cards.length <= 1) return;
    const shuffled = [...cards].sort(() => 0.5 - Math.random());
    setCardsForActiveDeck(shuffled);
    setCurrentIndex(0);
    setIsFlipped(defaultToTranslation);
    onNotifyToast('ALGORITHM_SHUFFLED // 卡片組已全面隨機打亂', true);
  };

  // Filtered cards list for the management explorer view
  const filteredCards = cards.filter(card => {
    const q = searchQuery.toLowerCase();
    return card.english.toLowerCase().includes(q) || card.translation.toLowerCase().includes(q);
  });

  const activeCard = cards[currentIndex];

  if (isTrainingMode) {
    const totalTrainingCards = trainingCards.length;
    const isCompleted = trainingCurrentIdx >= totalTrainingCards;
    const currentCard = trainingCards[trainingCurrentIdx];
    const accuracy = totalTrainingCards > 0 
      ? Math.round((trainingSuccesses.length / totalTrainingCards) * 100) 
      : 0;

    return (
      <div className="space-y-8 font-mono animate-fade-in text-[#e5e2e1]" id="training-interface-container">
        {/* Header Ribbon / Navigation bar */}
        <div className="border border-[#3a4a44] bg-[#161616] p-4 flex flex-col md:flex-row justify-between items-start md:items-center relative overflow-hidden">
          <div className="absolute top-0 right-0 h-10 w-10 text-[var(--theme-color,#00e0b3)] opacity-5 pointer-events-none">
            <RefreshCw className="w-full h-full animate-spin-slow" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-4 bg-amber-400 inline-block animate-pulse"></span>
              <span className="text-xs uppercase font-extrabold tracking-widest text-[#b9cbc2]/50">DRILL_MODULE_ACTIVE // 戰術學習自主訓練終端</span>
            </div>
            <h2 className="text-xl font-black text-white tracking-widest uppercase">
              {activeDeck?.name || '預設記憶組合'}
            </h2>
          </div>
          
          <button
            type="button"
            onClick={() => setIsTrainingMode(false)}
            className="mt-4 md:mt-0 px-4 py-2 bg-neutral-900 hover:bg-neutral-800 border border-[#3a4a44] hover:border-[var(--theme-color,#00e0b3)] text-white font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 rounded cursor-pointer transition-all duration-150 font-black self-stretch md:self-auto"
          >
            <ArrowLeft className="w-4 h-4 text-[var(--theme-color,#00e0b3)]" />
            返回自定學習 // EXIT_DRILL
          </button>
        </div>

        {/* Dynamic State Layout (Completed vs In-Progress) */}
        {isCompleted ? (
          /* RESULT / COMPLETED SCREEN */
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="border-2 border-[var(--theme-color,#00e0b3)]/60 bg-[#121212] p-6 text-center space-y-6 relative overflow-hidden"
          >
            <div className="max-w-md mx-auto space-y-4">
              <div className="inline-flex items-center justify-center p-4 bg-[var(--theme-color-bg,rgba(0,224,179,0.08))] border border-[var(--theme-color,#00e0b3)] rounded-full mb-2">
                <Sparkles className="w-10 h-10 text-[var(--theme-color,#00e0b3)] animate-bounce" />
              </div>

              <h3 className="text-xl font-black text-white tracking-widest uppercase">
                DRILL_SEQUENCE_COMPLETE // 訓練流程已全部結算
              </h3>
              
              <p className="text-xs text-[#b9cbc2]/60 font-sans tracking-wide leading-relaxed">
                本輪自主戰術複習程序核對完畢。您已完全劃過此組合中的所有資料卡。以下為您的認知同步分析數據：
              </p>

              {/* Stats Metrics Visual Bar */}
              <div className="grid grid-cols-3 gap-3 pt-2 font-mono text-xs">
                <div className="bg-[#181818] border border-[#3a4a44]/60 p-3 rounded">
                  <div className="text-[10px] text-[#b9cbc2]/40 uppercase tracking-tighter mb-1">TOTAL_CARDS</div>
                  <div className="text-lg font-black text-white">{totalTrainingCards} 字</div>
                </div>
                <div className="bg-[#181a1a] border border-emerald-500/30 p-3 rounded">
                  <div className="text-[10px] text-emerald-500/60 uppercase tracking-tighter mb-1">SUCCESS_COUNT</div>
                  <div className="text-lg font-black text-emerald-400">{trainingSuccesses.length} 字</div>
                </div>
                <div className="bg-[#1a1818] border border-red-500/30 p-3 rounded">
                  <div className="text-[10px] text-red-500/60 uppercase tracking-tighter mb-1">FAILED_RECALL</div>
                  <div className="text-lg font-black text-red-400">{trainingFails.length} 字</div>
                </div>
              </div>

              {/* Accuracy progress bar */}
              <div className="space-y-1.5 pt-2">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-[#b9cbc2]/60 uppercase">COGNITIVE SYNC ACCURACY // 認知同步率</span>
                  <span className={accuracy >= 80 ? 'text-[var(--theme-color,#00e0b3)]' : accuracy >= 50 ? 'text-amber-400' : 'text-red-400'}>
                    {accuracy}% ACCURACY
                  </span>
                </div>
                <div className="h-2 w-full bg-[#181818] rounded-full overflow-hidden border border-[#3a4a44]/50">
                  <div 
                    className="h-full transition-all duration-500 bg-gradient-to-r from-[var(--theme-color,#00e0b3)] to-emerald-400"
                    style={{ width: `${accuracy}%` }}
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-[#3a4a44]/40 space-y-3">
                {trainingFails.length > 0 ? (
                  <button
                    type="button"
                    onClick={handleDrillFailsOnly}
                    className="w-full py-3 bg-[var(--theme-color,#00e0b3)] hover:bg-[#00c59d] text-[#002118] font-black text-xs uppercase tracking-widest transition-all rounded shadow-[0_0_15px_rgba(0,224,179,0.25)] flex items-center justify-center gap-2 cursor-pointer border-none"
                  >
                    <RefreshCw className="w-4 h-4 animate-spin-slow" />
                    再次打亂學習失敗的卡片 ({trainingFails.length} 字) // RETRY_FAILS
                  </button>
                ) : (
                  <div className="bg-emerald-950/10 border border-emerald-500/20 p-2.5 text-center text-xs text-emerald-400 font-bold mb-3 font-sans">
                     CONGRATULATIONS // 超完美境界！本組卡片已 100% 掌握完畢
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={handleRestartAll}
                    className="py-2.5 bg-neutral-900 hover:bg-neutral-800 border border-[#3a4a44] text-white hover:text-[#00e0b3] hover:border-[var(--theme-color,#00e0b3)] font-bold text-xs uppercase tracking-wider transition-all rounded cursor-pointer"
                  >
                    重組完整卡片 ({totalTrainingCards} 字)
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsTrainingMode(false)}
                    className="py-2.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-600 text-white font-bold text-xs uppercase tracking-wider transition-all rounded cursor-pointer"
                  >
                    返回自訂學習 // EXIT
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ) : (
          /* DRILL ACTIVE SEQUENCE / SWIPER */
          <div className="space-y-6">
            
            {/* Top Dashboard Hud / Settings */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              
              {/* Left Settings: Default Face selector */}
              <div className="md:col-span-12 lg:col-span-5 bg-[#0e0e0e]/60 border border-[#3a4a44]/50 p-2 flex flex-col sm:flex-row items-center justify-between gap-2.5 rounded-sm">
                <span className="text-[10px] text-[#b9cbc2]/50 uppercase tracking-widest font-bold font-mono pl-1">
                  DEFAULT_FACE // 預設顯示卡面：
                </span>
                <div className="flex bg-[#141414] p-0.5 border border-[#3a4a44]/60 rounded-sm w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => {
                      setTrainingDefaultFace('front');
                      setTrainingShowFlipped(false);
                      onNotifyToast('PRESET_CHANGED // 預設先顯示【正面 - 英文】', true);
                    }}
                    className={`flex-1 sm:flex-none px-3 py-1 text-[10px] uppercase tracking-tighter transition-all font-bold cursor-pointer rounded-sm ${
                      trainingDefaultFace === 'front' 
                        ? 'bg-[var(--theme-color,#00e0b3)] text-[#002118]' 
                        : 'text-[#b9cbc2]/50 hover:text-white'
                    }`}
                  >
                    正面 (英文)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTrainingDefaultFace('back');
                      setTrainingShowFlipped(false);
                      onNotifyToast('PRESET_CHANGED // 預設先顯示【反面 - 釋義】', true);
                    }}
                    className={`flex-1 sm:flex-none px-3 py-1 text-[10px] uppercase tracking-tighter transition-all font-bold cursor-pointer rounded-sm ${
                      trainingDefaultFace === 'back' 
                        ? 'bg-[var(--theme-color,#00e0b3)] text-[#002118]' 
                        : 'text-[#b9cbc2]/50 hover:text-white'
                    }`}
                  >
                    反面 (翻譯)
                  </button>
                </div>
              </div>

              {/* Progress Bar / Indicator (Right Side) */}
              <div className="md:col-span-12 lg:col-span-7 flex flex-col sm:flex-row items-center gap-3 bg-[#111] border border-[#3a4a44]/30 px-3 py-2 rounded-sm w-full">
                <div className="text-right whitespace-nowrap text-xs w-full sm:w-auto flex justify-between sm:justify-start gap-1">
                  <span className="text-[#b9cbc2]/40">PROGRESS:</span>{' '}
                  <div>
                    <span className="text-white font-extrabold">{trainingCurrentIdx}</span>
                    <span className="text-[#3a4a44] mx-0.5">/</span>
                    <span className="text-[var(--theme-color,#00e0b3)] font-extrabold">{totalTrainingCards}</span>
                  </div>
                </div>
                
                {/* Visual Progress bar inside HUD */}
                <div className="flex-grow h-2.5 bg-black border border-[#3a4a44]/50 rounded-sm overflow-hidden p-0.5 w-full sm:w-auto">
                  <div 
                    className="h-full bg-[var(--theme-color,#00e0b3)] transition-all duration-300 rounded-sm"
                    style={{ width: `${(trainingCurrentIdx / totalTrainingCards) * 100}%` }}
                  />
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 text-[10px] whitespace-nowrap font-mono border-t sm:border-t-0 sm:border-l border-[#3a4a44]/40 pt-2 sm:pt-0 pl-0 sm:pl-3 w-full sm:w-auto">
                  <span className="text-emerald-400 font-bold">成功: {trainingSuccesses.length}</span>
                  <span className="text-red-400 font-bold">失敗: {trainingFails.length}</span>
                </div>
              </div>

            </div>

            {/* Dynamic Swipable Floating Card Field */}
            <div className="flex flex-col items-center justify-center max-w-2xl mx-auto py-2 relative w-full">
              
              {/* Visual guidance borders reflecting current swipe state */}
              <div className={`absolute top-0 bottom-0 left-0 w-1 flex items-center justify-center transition-all ${
                dragOffset < -20 ? 'bg-red-500 opacity-100 shadow-[0_0_15px_rgba(239,68,68,0.7)]' : 'bg-[#3a4a44]/20 opacity-0'
              }`} />
              <div className={`absolute top-0 bottom-0 right-0 w-1 flex items-center justify-center transition-all ${
                dragOffset > 20 ? 'bg-emerald-500 opacity-100 shadow-[0_0_15px_rgba(16,185,129,0.7)]' : 'bg-[#3a4a44]/20 opacity-0'
              }`} />

              <span className="text-[9px] text-[#b9cbc2]/45 tracking-widest font-bold uppercase mb-2 block text-center select-none font-mono">
                &gt;_ GESTURE_BOX // 戰術滑動感應板 (滑鼠/觸控左右滑動，或單擊翻牌)
              </span>

              {/* Main Swiper card wrapper with absolute positioning for animated slide */}
              <div className="relative w-full h-80 overflow-visible flex items-center justify-center cursor-grab active:cursor-grabbing perspective-1000">
                <AnimatePresence mode="popLayout">
                  <motion.div
                    key={trainingCurrentIdx}
                    initial={{ scale: 0.96, opacity: 0, y: 15 }}
                    animate={{ 
                      scale: 1, 
                      opacity: 1, 
                      y: 0,
                      x: dragOffset,
                      rotate: dragOffset * 0.04
                    }}
                    exit={{ 
                      opacity: 0, 
                      scale: 0.85, 
                      x: dragOffset < -20 ? -400 : dragOffset > 20 ? 400 : 0,
                      y: dragOffset !== 0 ? 50 : -40,
                      rotate: dragOffset < 0 ? -12 : dragOffset > 0 ? 12 : 0,
                      transition: { duration: 0.25, ease: 'easeOut' }
                    }}
                    drag="x"
                    dragConstraints={{ left: 0, right: 0 }}
                    dragElastic={1}
                    onDrag={(e, info) => {
                      setDragOffset(info.offset.x);
                    }}
                    onDragEnd={(e, info) => {
                      if (info.offset.x < -80) {
                        handleTrainingSwipe(false);
                      } else if (info.offset.x > 80) {
                        handleTrainingSwipe(true);
                      } else {
                        setDragOffset(0);
                      }
                    }}
                    onClick={() => {
                      setTrainingShowFlipped(prev => !prev);
                    }}
                    className={`w-full h-full p-6 flex flex-col justify-between border-2 rounded relative select-none shadow-[0_4px_24px_rgba(0,0,0,0.5)] transition-colors duration-200 ${
                      dragOffset < -15 
                        ? 'bg-[#291414] border-red-500/80 shadow-[0_0_20px_rgba(239,68,68,0.15)]' 
                        : dragOffset > 15 
                          ? 'bg-[#12241e] border-emerald-500/80 shadow-[0_0_20px_rgba(16,185,129,0.15)]'
                          : trainingShowFlipped 
                            ? 'bg-[#171e1d] border-[#00ffd8]/60 shadow-[0_0_15px_rgba(0,255,216,0.04)]' 
                            : 'bg-[#181818] border-[#4a5a54] hover:border-[#00e0b3]'
                    }`}
                  >
                    
                    {/* Top corner category indicators inside card */}
                    <div className="flex justify-between items-center w-full">
                      <div className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-widest text-[#b9cbc2]/45 font-bold">
                        <span className="w-1.5 h-1.5 bg-[#b9cbc2]/60 rounded-full"></span>
                        <span>DRILL_CARD // 訓練卡 00{trainingCurrentIdx + 1}</span>
                      </div>
                      
                      <div className="text-[10px] px-2 py-0.5 bg-black border border-[#3a4a44] text-[#b9cbc2]/60 rounded">
                        {trainingShowFlipped ? 'REVEALED // 已核對' : 'UNREVEALED // 未核對'}
                      </div>
                    </div>

                    {/* Left/Right Overlays while dragging */}
                    {dragOffset < -15 && (
                      <div className="absolute top-16 left-6 rotate-[-12deg] border-2 border-red-500 bg-red-950/95 text-red-500 font-black text-xs uppercase px-2 py-1 tracking-widest pointer-events-none rounded shadow-md z-20">
                        ← 學習失敗 // FAIL
                      </div>
                    )}
                    {dragOffset > 15 && (
                      <div className="absolute top-16 right-6 rotate-[12deg] border-2 border-emerald-500 bg-emerald-950/95 text-emerald-400 font-black text-xs uppercase px-2 py-1 tracking-widest pointer-events-none rounded shadow-md z-20">
                        掌握成功 // SUCCESS →
                      </div>
                    )}

                    {/* Central Word Text */}
                    <div className="flex-grow flex flex-col justify-center items-center py-4 text-center">
                      {!trainingShowFlipped ? (
                        /* Default unrevealed face representation */
                        <p className="text-2xl md:text-3xl font-black text-white text-center tracking-wide break-words leading-snug font-sans max-w-md">
                          {trainingDefaultFace === 'front' ? currentCard.english : currentCard.translation}
                        </p>
                      ) : (
                        /* Revealed alternative face representation */
                        <p className={`text-2xl md:text-3.5xl font-black text-center tracking-wide break-words leading-snug font-sans max-w-md ${
                          trainingDefaultFace === 'front' ? 'text-[var(--theme-color,#00e0b3)]' : 'text-[#ffffff]'
                        }`}>
                          {trainingDefaultFace === 'front' ? currentCard.translation : currentCard.english}
                        </p>
                      )}

                      {/* Display toggle help */}
                      <span className="text-[9px] text-[#b9cbc2]/30 mt-4 uppercase select-none font-mono">
                        ( 點按卡片中央任何位置可【 翻轉卡面 // REVEAL 】)
                      </span>
                    </div>

                    {/* Bottom face labels */}
                    <div className="flex justify-between items-center text-[10px] text-[#b9cbc2]/50 font-mono">
                      <div>
                        {trainingShowFlipped ? (
                          <span className="text-[9px] text-[var(--theme-color,#00e0b3)] font-bold uppercase tracking-widest">
                            {trainingDefaultFace === 'front' ? '▲ TRANSLATION' : '▲ ORIGINAL ENGLISH'}
                          </span>
                        ) : (
                          <span className="text-[9px] tracking-widest uppercase text-white/30">
                            {trainingDefaultFace === 'front' ? '▲ ENGLISH TEXT' : '▲ CHINESE TEXT'}
                          </span>
                        )}
                      </div>
                      
                      <span className="font-bold text-[var(--theme-color,#00e0b3)] font-mono animate-pulse">
                        SWIPE CARD OR CLICK REVEAL
                      </span>
                    </div>

                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Touch Keyboard navigation guideline tags */}
              <div className="flex justify-between items-center w-full mt-3 text-[10px] text-[#b9cbc2]/50 font-sans px-2">
                <span className="text-red-400">← 鍵標記失敗 (LEFT)</span>
                <span className="text-[9px] text-[#b9cbc2]/30 font-mono flex items-center gap-1">
                  <Layers className="w-3 h-3 text-[var(--theme-color,#00e0b3)]" />
                  空白鍵/[⇅]翻查
                </span>
                <span className="text-emerald-400">標記成功 (RIGHT) →</span>
              </div>

            </div>

            {/* Decision Action Buttons (Bottom Layout) */}
            <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto pt-2">
              <button
                type="button"
                onClick={() => handleTrainingSwipe(false)}
                className="h-12 bg-red-950/20 hover:bg-red-500 hover:text-[#0f0000] border-2 border-red-500/50 hover:border-red-500 text-red-400 font-extrabold text-xs uppercase tracking-widest flex items-center justify-center gap-2 rounded cursor-pointer transition-all duration-200 active:scale-97 group shadow-sm font-black"
                title="學習失敗，需要再次挑戰"
              >
                <ThumbsDown className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
                學習失敗 // FAIL_LEFT
              </button>
              
              <button
                type="button"
                onClick={() => handleTrainingSwipe(true)}
                className="h-12 bg-emerald-950/20 hover:bg-emerald-500 hover:text-black border-2 border-emerald-500/50 hover:border-emerald-500 text-emerald-400 font-extrabold text-xs uppercase tracking-widest flex items-center justify-center gap-4 rounded cursor-pointer transition-all duration-200 active:scale-97 group shadow-sm font-black"
                title="掌握完美，核對成功"
              >
                學習成功 // SUCCESS_RIGHT
                <ThumbsUp className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>

          </div>
        )}
        
        {/* Helper Guidelines segment footer inside drill panel */}
        <div className="border border-[#3a4a44]/50 bg-[#0e0e0e]/50 p-4 rounded text-xs leading-relaxed text-[#b9cbc2]/60 font-sans space-y-1 max-w-2xl mx-auto">
          <p className="font-bold text-white uppercase tracking-wider font-mono text-[10px]">&gt;_ STRATEGY // 戰術自研訓練說明</p>
          <ul className="list-disc pl-4 space-y-0.5 text-[#b9cbc2]/50">
            <li><strong>卡片操作:</strong> 點按卡片可以隨時翻面。可直接向左拖拽 / 滑動卡牌標記為不通過，向右標記為掌握。</li>
            <li><strong>極限效率:</strong> 推薦使用鍵盤進行單手高速操作，<strong>← 鍵</strong> 代表失敗，<strong>→ 鍵</strong> 代表成功，<strong>空白鍵或上下鍵</strong> 可以完美翻轉卡片。</li>
            <li><strong>重測弱點:</strong> 訓練結束後，可選 “再次打亂學習失敗的卡片”，此時系統會提取不熟悉的卡片供反覆溫習。</li>
          </ul>
        </div>

      </div>
    );
  }

  return (
    <div className="space-y-8 font-mono animate-fade-in text-[#e5e2e1]">
      
      {/* Top Deck Stats Banner/HUD */}
      <div className="border border-[#3a4a44] bg-[#161616] p-4 flex flex-col md:flex-row justify-between items-start md:items-center relative overflow-hidden">
        <div className="absolute top-0 right-0 h-10 w-10 text-[var(--theme-color,#00e0b3)] opacity-5 pointer-events-none">
          <Layers className="w-full h-full" />
        </div>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-4 bg-[var(--theme-color,#00e0b3)] inline-block"></span>
            <span className="text-xs uppercase font-extrabold tracking-widest text-[#b9cbc2]/50">DYNAMIC_LEARNING_PROTOCOL_v0.9</span>
          </div>
          <h2 className="text-xl font-black text-white tracking-widest select-none">
            CUSTOM COGNITIVE FLASHCARDS // 自定義學習系統
          </h2>
        </div>
        <div className="mt-4 md:mt-0 flex gap-3 flex-wrap w-full md:w-auto">
          <div className="px-3 py-1.5 bg-[#0e0e0e] border border-[#3a4a44] rounded text-right flex flex-col justify-center min-w-[140px] flex-grow md:flex-grow-0">
            <span className="text-[10px] text-[#b9cbc2]/50 uppercase font-semibold">TOTAL DECK SIZE // 當前總卡片</span>
            <span className="text-base font-black text-[var(--theme-color,#00e0b3)]">
              {cards.length} <span className="text-xs text-white">WORDS</span>
            </span>
          </div>
          
          <button
            type="button"
            onClick={() => startTraining('front')}
            disabled={cards.length === 0}
            className="px-4 py-2 bg-[var(--theme-color,#00e0b3)] hover:bg-opacity-90 disabled:bg-neutral-800 disabled:border-neutral-700 disabled:text-neutral-500 disabled:opacity-40 text-[#002118] font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 border border-[var(--theme-color,#00e0b3)] rounded cursor-pointer transition-all duration-150 font-black flex-grow md:flex-grow-0 hover:shadow-[0_0_15px_rgba(0,224,179,0.25)] shadow-md hover:scale-[1.02] active:scale-95 disabled:pointer-events-none"
            title="啟動自定義自主訓練"
          >
            <Play className="w-3.5 h-3.5 fill-[#002118]" />
            啟動自主訓練 // DRILL_MODE
          </button>
        </div>
      </div>

      {/* Combination Managing Console */}
      <div className="border border-[#3a4a44]/80 bg-[#121212] p-4 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3a4a44]/40 pb-3">
          <div className="flex items-center gap-2">
            <Layers className="w-4.5 h-4.5 text-[var(--theme-color,#00e0b3)]" />
            <span className="text-xs uppercase font-extrabold tracking-wider text-white">
              COGNITIVE_MEM_PRESETS // 記憶資料卡組合調控台
            </span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                setIsCreatingDeck(true);
                setIsRenamingDeck(false);
                setNewDeckName('');
              }}
              className="flex items-center gap-1.5 text-[10px] text-[var(--theme-color,#00e0b3)] hover:text-[#002118] border border-[var(--theme-color,#00e0b3)]/40 hover:bg-[var(--theme-color,#00e0b3)] px-2.5 py-1 uppercase tracking-wider transition-all rounded cursor-pointer font-bold animate-pulse"
            >
              <Plus className="w-3.5 h-3.5" />
              開啟新組合 // OPEN_NEW_SET
            </button>
          </div>
        </div>

        {/* 1. Create New Input Deck Box (Inline Form) */}
        {isCreatingDeck && (
          <motion.form 
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={handleCreateDeck}
            className="p-3 bg-[#191919] border border-[var(--theme-color,#00e0b3)] space-y-3 rounded-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[var(--theme-color,#00e0b3)] font-bold uppercase">建立全新記憶組合 // CREATE_NEW_MATRIX_SET</span>
              <button 
                type="button" 
                onClick={() => setIsCreatingDeck(false)} 
                className="text-[#b9cbc2]/60 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="請輸入新組合之識別名稱 (例如：TOEFL 核心詞彙 / 醫療工程術語)..."
                value={newDeckName}
                onChange={(e) => setNewDeckName(e.target.value)}
                className="flex-grow bg-[#0e0e0e] border border-[#3a4a44] focus:border-[var(--theme-color,#00e0b3)] text-white px-3 py-1.5 text-xs focus:outline-none rounded"
                autoFocus
              />
              <button
                type="submit"
                className="px-4 py-1.5 bg-[var(--theme-color,#00e0b3)] hover:bg-opacity-85 text-[#002118] font-bold text-[11px] uppercase tracking-wider rounded cursor-pointer"
              >
                建立並啟用
              </button>
            </div>
          </motion.form>
        )}

        {/* 2. Rename Input Box (Inline Form) */}
        {isRenamingDeck && (
          <motion.form 
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={handleRenameDeck}
            className="p-3 bg-[#191919] border border-[var(--theme-color,#00e0b3)] space-y-3 rounded-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[var(--theme-color,#00e0b3)] font-bold uppercase">重新命名當前智慧組 // RENAME_ACTIVE_MATRIX</span>
              <button 
                type="button" 
                onClick={() => setIsRenamingDeck(false)} 
                className="text-[#b9cbc2]/60 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={renameDeckValue}
                onChange={(e) => setRenameDeckValue(e.target.value)}
                className="flex-grow bg-[#0e0e0e] border border-[#3a4a44] focus:border-[var(--theme-color,#00e0b3)] text-white px-3 py-1.5 text-xs focus:outline-none rounded"
                autoFocus
              />
              <button
                type="submit"
                className="px-4 py-1.5 bg-[var(--theme-color,#00e0b3)] hover:bg-opacity-85 text-[#002118] font-bold text-[11px] uppercase tracking-wider rounded cursor-pointer"
              >
                確認儲存
              </button>
            </div>
          </motion.form>
        )}

        {/* 3. Preset Decks Grid Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {decks.map((deck) => {
            const isActive = deck.id === activeDeckId;
            const isDeleting = deckToDeleteId === deck.id;

            return (
              <div
                key={deck.id}
                onClick={() => {
                  if (!isDeleting) {
                    setActiveDeckId(deck.id);
                    setCurrentIndex(0);
                    setIsFlipped(defaultToTranslation);
                  }
                }}
                className={`p-3 border transition-all flex flex-col justify-between relative group ${
                  isActive
                    ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.06))] border-[var(--theme-color,#00e0b3)] text-white shadow-[0_0_12px_rgba(0,224,179,0.03)]'
                    : 'bg-[#0f0f0f] border-[#3a4a44]/50 hover:border-[#b9cbc2]/50 text-[#b9cbc2]/80 hover:text-white'
                } cursor-pointer rounded-sm`}
              >
                {/* Active selection indicator */}
                {isActive && (
                  <div className="absolute top-2.5 right-2.5 w-1.5 h-1.5 bg-[var(--theme-color,#00e0b3)] rounded-full animate-pulse" />
                )}

                <div className="space-y-1">
                  <div className="text-[9px] text-[#b9cbc2]/40 uppercase tracking-widest font-mono">
                    MATRIX_STORAGE_SLOT // 儲存組合
                  </div>
                  <h4 className="text-xs font-black truncate max-w-[210px] uppercase">
                    {deck.name}
                  </h4>
                </div>

                {/* Info and action row */}
                <div className="flex items-center justify-between border-t border-[#3a4a44]/30 pt-2.5 mt-3 text-[10px] font-mono">
                  <div className="flex items-center gap-1 text-[#b9cbc2]/60">
                    <BookOpen className="w-3 h-3 text-[var(--theme-color,#00e0b3)]/75" />
                    <span className="font-semibold text-white">{deck.cards.length}</span>
                    <span>CARDS</span>
                  </div>

                  {isDeleting ? (
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => handleDeleteDeck(deck.id)}
                        className="text-red-400 font-extrabold hover:text-red-300 uppercase tracking-tighter"
                      >
                        [ 毀滅 // PRG ]
                      </button>
                      <button
                        onClick={() => setDeckToDeleteId(null)}
                        className="text-[#b9cbc2]/60 hover:text-white uppercase tracking-tighter"
                      >
                        [ 否 ]
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 opacity-30 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                      {isActive && (
                        <button
                          onClick={() => {
                            setIsRenamingDeck(true);
                            setIsCreatingDeck(false);
                            setRenameDeckValue(deck.name);
                          }}
                          className="hover:text-[var(--theme-color,#00e0b3)] cursor-pointer"
                          title="修改名稱"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {decks.length > 1 && (
                        <button
                          onClick={() => setDeckToDeleteId(deck.id)}
                          className="hover:text-red-400 cursor-pointer"
                          title="銷毀此組合"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Interactive Flashcard Display (6 cols) */}
        <div className="lg:col-span-7 flex flex-col space-y-4">
          <div className="flex flex-wrap justify-between items-center gap-2 bg-[#0e0e0e]/50 px-2 py-1.5 border-b border-[#3a4a44]/30">
            <div className="flex items-center gap-3">
              <span className="text-[10px] text-white/50 tracking-wider">
                CAROUSEL VIEWPORT // 互動記憶看板
              </span>
              <label className="flex items-center gap-1.5 text-[9px] text-[#b9cbc2]/70 cursor-pointer select-none hover:text-[var(--theme-color,#00e0b3)]">
                <input
                  type="checkbox"
                  checked={defaultToTranslation}
                  onChange={(e) => {
                    setDefaultToTranslation(e.target.checked);
                    setIsFlipped(e.target.checked);
                  }}
                  className="rounded bg-black border-[#3a4a44] text-[var(--theme-color,#00e0b3)] focus:ring-0 w-3 h-3 cursor-pointer"
                />
                <span>跳轉後顯示翻譯 (AUTO_SHOW_BACK)</span>
              </label>
            </div>
            {cards.length > 1 && (
              <button 
                type="button"
                onClick={shuffleCards}
                className="flex items-center gap-1.5 text-[10px] text-[var(--theme-color,#00e0b3)] hover:text-white border border-[var(--theme-color,#00e0b3)]/30 hover:bg-[var(--theme-color,#00e0b3)]/10 px-2.1 py-0.8 tracking-widest uppercase transition-all duration-150 rounded cursor-pointer"
              >
                <Shuffle className="w-3 h-3" />
                SHUFFLE // 打亂卡組
              </button>
            )}
          </div>

          {cards.length === 0 ? (
            /* Empty State */
            <div className="h-80 border-2 border-dashed border-[#3a4a44] flex flex-col justify-center items-center text-center p-6 bg-[#161616]/40 select-none">
              <AlertCircle className="w-12 h-12 text-[#ff4242]/70 mb-3 animate-bounce" />
              <p className="text-sm font-bold text-white tracking-widest uppercase">SYLLABUS_EMPTY // 模組卡組太空</p>
              <p className="text-[11px] text-[#b9cbc2]/50 mt-1 max-w-sm leading-relaxed">
                目前不存在任何記憶卡片。請在右側或下方填寫文字，新增屬於您個人的高強度學習卡！
              </p>
            </div>
          ) : (
            /* Active Flip Flashcard wrapper */
            <div className="space-y-4">
              {/* Interactive Flippable card container */}
              <div 
                onClick={() => {
                  if (!isEditingBack) {
                    setIsFlipped(!isFlipped);
                  }
                }}
                className="relative h-72 w-full cursor-pointer group select-none perspective-1000"
                id="interactive-flip-card"
              >
                <motion.div
                  className="w-full h-full relative border border-[#3a4a44] hover:border-[var(--theme-color,#00e0b3)] bg-[#1a1a1a]"
                  style={{ transformStyle: 'preserve-3d' }}
                  animate={{ rotateY: isFlipped ? 180 : 0 }}
                  transition={{ duration: 0.4, ease: 'easeInOut' }}
                >
                  
                  {/* Front Side (English) - Shows when rotateY is around 0 */}
                  <div 
                    className={`absolute inset-0 p-6 flex flex-col justify-between backface-hidden bg-[#161616] overflow-y-auto ${!isFlipped ? 'pointer-events-auto' : 'pointer-events-none'}`}
                    style={{ 
                      backfaceVisibility: 'hidden',
                      WebkitBackfaceVisibility: 'hidden',
                      opacity: isFlipped ? 0 : 1,
                      transition: 'opacity 0.2s ease-in-out'
                    }}
                  >
                    <div className="flex justify-between items-center w-full">
                      <span className="text-[10px] font-bold text-white/40 tracking-widest uppercase font-mono">
                        FRONT // 英文面
                      </span>
                      <span className="font-mono text-[9px] px-2 py-0.5 border border-[#3a4a44] rounded text-[#b9cbc2]/60">
                        OP_00{currentIndex + 1}
                      </span>
                    </div>

                    <div className="flex-grow flex flex-col justify-center items-center py-4 px-2">
                      <p className="text-2xl md:text-3.5xl font-black text-white text-center tracking-wide leading-tight break-words select-all font-sans">
                        {activeCard.english}
                      </p>
                    </div>

                    <div className="flex justify-between items-center text-[10px] text-[#b9cbc2]/45">
                      <span 
                        onClick={(e) => {
                          e.stopPropagation();
                          setIsFlipped(true);
                        }}
                        className="flex items-center gap-1.5 animate-pulse text-[var(--theme-color,#00e0b3)] cursor-pointer hover:text-white transition-colors"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                        點擊翻轉查看釋義
                      </span>
                      <span>TOTAL {currentIndex + 1} / {cards.length}</span>
                    </div>
                  </div>

                  {/* Back Side (Translation) - Shows when rotateY is 180 */}
                  <div 
                    className={`absolute inset-0 p-6 flex flex-col justify-between bg-[#191e1d] border-2 border-[var(--theme-color,#00e0b3)]/30 overflow-y-auto ${isFlipped ? 'pointer-events-auto' : 'pointer-events-none'}`}
                    style={{ 
                      backfaceVisibility: 'hidden', 
                      WebkitBackfaceVisibility: 'hidden',
                      transform: 'rotateY(180deg)',
                      opacity: isFlipped ? 1 : 0,
                      transition: 'opacity 0.2s ease-in-out'
                    }}
                  >
                    <div className="flex justify-between items-center w-full">
                      <span className="text-[10px] font-bold text-[var(--theme-color,#00e0b3)] tracking-widest uppercase font-mono flex items-center gap-2">
                        BACK // 翻譯面
                        {!isEditingBack && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setIsEditingBack(true);
                              setBackEditTranslation(activeCard.translation);
                            }}
                            className="px-2 py-0.5 rounded border border-[#3a4a44] hover:border-[var(--theme-color,#00e0b3)] bg-black/40 hover:bg-[var(--theme-color,#00e0b3)]/10 text-[var(--theme-color,#00e0b3)] hover:text-white transition-all cursor-pointer flex items-center gap-1 text-[9px] font-sans font-semibold"
                            title="修改翻譯面"
                          >
                            <Edit2 className="w-2.5 h-2.5" />
                            自訂編輯
                          </button>
                        )}
                      </span>
                      <span className="font-mono text-[9px] px-2 py-0.5 border border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)] font-bold rounded">
                        SOLVED // 釋義
                      </span>
                    </div>

                    <div className="flex-grow flex flex-col justify-center items-center py-4 px-3 w-full" onClick={(e) => { if (isEditingBack) e.stopPropagation(); }}>
                      {isEditingBack ? (
                        <div className="w-full space-y-3" onClick={(e) => e.stopPropagation()}>
                          <span className="text-[9px] text-[#b9cbc2]/60 font-mono tracking-widest block uppercase">
                            &gt;_ EDIT_TRANSLATION_FACE // 自訂翻譯面
                          </span>
                          <textarea
                            value={backEditTranslation}
                            onChange={(e) => setBackEditTranslation(e.target.value)}
                            className="w-full bg-[#0e0e0e] border border-[var(--theme-color,#00e0b3)] text-[#e5e2e1] px-3 py-2 text-sm leading-relaxed focus:outline-none rounded resize-none text-center font-sans font-bold"
                            rows={3}
                            placeholder="請在此輸入要自訂的中文翻譯與筆記..."
                            autoFocus
                            onClick={(e) => e.stopPropagation()}
                          />
                          <div className="flex justify-center gap-2" onClick={(e) => e.stopPropagation()}>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setIsEditingBack(false);
                              }}
                              className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-[11px] tracking-wider transition-all cursor-pointer flex items-center gap-1 border border-neutral-600"
                            >
                              <X className="w-3 h-3" />
                              取消
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const cleanTxt = backEditTranslation.trim();
                                if (!cleanTxt) {
                                  onNotifyToast('ERROR // 翻譯內容不能為空', false);
                                  return;
                                }
                                setCardsForActiveDeck(cards.map(c => {
                                  if (c.id === activeCard.id) {
                                    return {
                                      ...c,
                                      translation: cleanTxt
                                    };
                                  }
                                  return c;
                                }));
                                setIsEditingBack(false);
                                onNotifyToast('UPDATE_SUCCESS // 翻譯面自訂更新成功！', true);
                              }}
                              className="px-2.5 py-1 bg-[var(--theme-color,#00e0b3)] hover:bg-opacity-80 text-[#002118] font-bold rounded text-[11px] tracking-wider transition-all cursor-pointer flex items-center gap-1"
                            >
                              <Check className="w-3 h-3" />
                              儲存
                            </button>
                          </div>
                        </div>
                      ) : (
                        <p className="text-lg md:text-xl font-bold text-[#e5e2e1] text-center leading-relaxed break-words font-sans">
                          {activeCard.translation}
                        </p>
                      )}
                    </div>

                    <div className="flex justify-between items-center text-[10px] text-[#b9cbc2]/45">
                      <span 
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!isEditingBack) {
                            setIsFlipped(false);
                          }
                        }}
                        className="flex items-center gap-1 cursor-pointer hover:text-[var(--theme-color,#00e0b3)] text-[#b9cbc2] transition-colors"
                      >
                        <RotateCw className="w-3.5 h-3.5 text-[#b9cbc2]" />
                        點擊再次翻轉正面
                      </span>
                      <span>DECK INDEX {currentIndex + 1}</span>
                    </div>
                  </div>

                </motion.div>
              </div>

              {/* Card Nav Controls */}
              <div className="flex gap-2 justify-between items-center bg-[#0e0e0e] border border-[#3a4a44] p-2">
                <button
                  onClick={prevCard}
                  className="flex items-center justify-center w-12 h-10 bg-[#161616] hover:bg-[var(--theme-color,#00e0b3)] hover:text-black border border-[#3a4a44] hover:border-[var(--theme-color,#00e0b3)] transition-all rounded cursor-pointer"
                  title="Previous Card"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <div className="font-mono text-xs flex items-center gap-2">
                  <span className="text-[#b9cbc2]/50 uppercase">INDEX:</span>
                  <span className="text-white font-extrabold">{currentIndex + 1}</span>
                  <span className="text-[#3a4a44]">/</span>
                  <span className="text-[var(--theme-color,#00e0b3)] font-extrabold">{cards.length}</span>
                </div>

                <button
                  onClick={nextCard}
                  className="flex items-center justify-center w-12 h-10 bg-[#161616] hover:bg-[var(--theme-color,#00e0b3)] hover:text-black border border-[#3a4a44] hover:border-[var(--theme-color,#00e0b3)] transition-all rounded cursor-pointer"
                  title="Next Card"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Card Manager (Add Card + Explorer list) (5 cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-6">
          
          {/* Add card Form */}
          <div className="border border-[#3a4a44] bg-[#161616] p-4 space-y-4">
            <div className="flex items-center gap-2 border-b border-[#3a4a44]/70 pb-2">
              <Plus className="w-4 h-4 text-[var(--theme-color,#00e0b3)]" />
              <span className="text-xs uppercase font-extrabold tracking-widest text-white">NEW_CARD_PROTOCOL // 建立記憶資料卡</span>
            </div>

            <form onSubmit={handleAddCard} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] text-[#b9cbc2]/60 uppercase tracking-wider block">English Side // 英文面文本 (單字、短語、片語或問句)</label>
                <input
                  type="text"
                  value={newEnglish}
                  onChange={(e) => setNewEnglish(e.target.value)}
                  placeholder="e.g. Tactical memory compilation..."
                  className="w-full bg-[#0e0e0e] border border-[#3a4a44] focus:border-[var(--theme-color,#00e0b3)] text-white px-3 py-2 text-sm focus:outline-none transition-all rounded"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#b9cbc2]/60 uppercase tracking-wider block">Translation Side // 翻譯面文本 (中文涵義、語境註釋與詳細分析)</label>
                <textarea
                  value={newTranslation}
                  onChange={(e) => setNewTranslation(e.target.value)}
                  placeholder="e.g. 戰術記憶編譯，代表高強度神經元反射..."
                  rows={2}
                  className="w-full bg-[#0e0e0e] border border-[#3a4a44] focus:border-[var(--theme-color,#00e0b3)] text-white px-3 py-2 text-sm focus:outline-none transition-all rounded resize-none"
                />
              </div>

              {formError && (
                <div className="p-2 border border-red-500/20 bg-red-950/10 text-[10px] text-red-400 font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full h-11 bg-[var(--theme-color,#00e0b3)] hover:bg-[var(--theme-color,#00e0b3)]/90 text-[#002118] transition-all font-sans font-bold flex items-center justify-center gap-2 text-sm tracking-wider cursor-pointer shadow-[0_0_10px_rgba(0,224,179,0.1)] active:scale-97"
              >
                <Plus className="w-4 h-4" />
                新增此客製化卡片 (ADD_TO_DECK)
              </button>
            </form>
          </div>

          {/* Searchable Cards Explorer Dashboard view */}
          <div className="border border-[#3a4a44] bg-[#161616] p-4 flex flex-col space-y-4 h-[350px]">
            <div className="flex justify-between items-center border-b border-[#3a4a44]/70 pb-2">
              <span className="text-xs uppercase font-extrabold tracking-widest text-[#b9cbc2]/60">CARDS_EXPLORER // 資料卡清單庫</span>
              <span className="text-[10px] text-[var(--theme-color,#00e0b3)] bg-[#0e0e0e] px-2 py-0.5 font-bold border border-[#3a4a44]">
                {filteredCards.length} MATCHING
              </span>
            </div>

            {/* Micro search input */}
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-[#b9cbc2]/40">
                <Search className="w-3.5 h-3.5" />
              </span>
              <input
                type="text"
                placeholder="搜尋自定義詞彙或翻譯文字..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0e0e0e] border border-[#3a4a44] focus:border-[var(--theme-color,#00e0b3)] text-white pl-9 pr-3 py-1.5 text-xs focus:outline-none transition-all rounded"
              />
            </div>

            {/* List container */}
            <div className="flex-grow overflow-y-auto space-y-2 pr-1 no-scrollbar text-xs">
              {filteredCards.length === 0 ? (
                <div className="text-center py-6 text-white/30 uppercase tracking-widest text-[9px] select-none">
                  NO_MATCHES_FOUND
                </div>
              ) : (
                filteredCards.map((card, listIdx) => {
                  const isEditingThis = editingCardId === card.id;
                  const isActiveSelection = activeCard?.id === card.id;

                  return (
                    <div 
                      key={card.id}
                      onClick={() => {
                        const globalCardIdx = cards.findIndex(c => c.id === card.id);
                        if (globalCardIdx !== -1) {
                          setCurrentIndex(globalCardIdx);
                          setIsFlipped(defaultToTranslation);
                        }
                      }}
                      className={`p-3 border transition-all text-left relative group ${
                        isActiveSelection 
                          ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] border-[var(--theme-color,#00e0b3)] text-white' 
                          : 'bg-[#0e0e0e] border-[#3a4a44]/60 hover:bg-[#1a1a1a] text-[#b9cbc2]/80 hover:text-white'
                      } cursor-pointer`}
                    >
                      {/* Top Action Ribbon overlay */}
                      <div className="absolute top-2 right-2 flex items-center gap-1.5 opacity-40 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            startEditing(card);
                          }}
                          className="p-1 hover:bg-[#3a4a44]/40 hover:text-[var(--theme-color,#00e0b3)] rounded text-[#b9cbc2] transition-colors cursor-pointer"
                          title="修改卡片"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => handleDeleteCard(card.id, e)}
                          className="p-1 hover:bg-[#ff4242]/20 hover:text-[#ff4242] rounded text-[#b9cbc2] transition-colors cursor-pointer"
                          title="刪除卡片"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>

                      {isEditingThis ? (
                        /* Editing form */
                        <form 
                          onClick={(e) => e.stopPropagation()} 
                          onSubmit={handleSaveEdit} 
                          className="space-y-2 mt-1"
                        >
                          <div className="space-y-1">
                            <input
                              type="text"
                              value={editEnglish}
                              onChange={(e) => setEditEnglish(e.target.value)}
                              className="w-full bg-black border border-[#3a4a44] focus:border-[var(--theme-color,#00e0b3)] text-white px-2 py-1 text-xs focus:outline-none"
                            />
                            <textarea
                              value={editTranslation}
                              onChange={(e) => setEditTranslation(e.target.value)}
                              rows={2}
                              className="w-full bg-black border border-[#3a4a44] focus:border-[var(--theme-color,#00e0b3)] text-white px-2 py-1 text-xs focus:outline-none resize-none"
                            />
                          </div>
                          <div className="flex justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setEditingCardId(null)}
                              className="px-2 py-0.5 bg-[#3a4a44] text-white text-[9px] hover:bg-[#2c3632] uppercase cursor-pointer"
                            >
                              取消
                            </button>
                            <button
                              type="submit"
                              className="px-2 py-0.5 bg-[var(--theme-color,#00e0b3)] text-black font-bold text-[9px] hover:bg-opacity-80 uppercase cursor-pointer"
                            >
                              儲存
                            </button>
                          </div>
                        </form>
                      ) : (
                        /* Default display fields */
                        <div className="space-y-1 pr-12">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono text-[9px] text-[#b9cbc2]/40 font-bold">
                              #{listIdx + 1}
                            </span>
                            <span className="font-sans font-black tracking-wide text-sm truncate max-w-[170px] uppercase text-white font-mono">
                              {card.english}
                            </span>
                          </div>
                          <p className="font-sans text-[11px] leading-relaxed line-clamp-2 text-[#b9cbc2]/60 break-words">
                            {card.translation}
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>

          </div>

        </div>

      </div>

      {/* Decorative Guidelines Footer */}
      <div className="border border-[#3a4a44]/50 bg-[#0e0e0e]/50 p-4 rounded text-xs leading-relaxed text-[#b9cbc2]/60 font-sans space-y-1">
        <p className="font-bold text-white uppercase tracking-wider font-mono text-[10px]">&gt;_ CUSTOM COGNITIVE DRILL // 客製化訓練要點說明</p>
        <ul className="list-disc pl-4 space-y-0.5">
          <li><strong>英文面-正面 (FRONT):</strong> 專為您個人不熟悉的英文生字、難點或者片語量身定做。雙擊或滑鼠點按主界面隨時翻查。</li>
          <li><strong>翻譯面-反面 (BACK):</strong> 由您完全制定的多樣中文含義或考點備註，幫助深度複習，克服特定考題和戰術偏差。</li>
          <li><strong>實持久化存檔:</strong> 您所撰寫的卡片均在流動中即時存入終端本地高速快取 (LocalStorage)，安全可靠，不受關閉干擾。</li>
        </ul>
      </div>

    </div>
  );
}
