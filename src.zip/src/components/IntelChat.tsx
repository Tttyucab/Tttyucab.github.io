import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Cpu, HelpCircle, Check, X, AlertOctagon, Terminal, BookOpen, Lightbulb, CornerDownLeft, Loader2 } from 'lucide-react';

interface BrainQuiz {
  question: string;
  options: string[];
  correctOption: string; // 'A' | 'B' | 'C' | 'D'
  explanation: string;
  userAnswer?: string;
  isCorrect?: boolean;
}

interface WordDetails {
  word: string;
  pronunciation?: string;
  chineseTranslation: string;
  englishDefinition: string;
  usages: string[];
  quiz: BrainQuiz;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'prts';
  text: string;
  wordDetails?: WordDetails;
  isLoading?: boolean;
  error?: string;
}

const INSIGHTS_SUGGESTIONS = [
  "augment",
  "precarious",
  "vulnerability",
  "integrity",
  "resilient",
  "conspicuous"
];

export default function IntelChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'prts',
      text: "Doctor，神經語義分析鏈接已就緒。請輸入任何英文單詞（例如: alleviate, tactical, compromise），我將為您執行深度語意編譯，解析字彙屬性、中文翻譯、實戰用途，並即時生成一道「戰術應用題」以鞏固您的突擊記憶鏈路。"
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendWord = async (wordText: string) => {
    if (!wordText.trim() || isGenerating) return;
    
    const targetWord = wordText.trim();
    setInputValue("");
    setIsGenerating(true);

    // 1. Add User query message
    const userMsgId = Date.now().toString();
    setMessages(prev => [
      ...prev,
      { id: userMsgId, sender: 'user', text: targetWord }
    ]);

    // 2. Add temporary PRTS loading message
    const aiMsgId = (Date.now() + 1).toString();
    setMessages(prev => [
      ...prev,
      {
        id: aiMsgId,
        sender: 'prts',
        text: `PRTS // 正在檢索神經網絡並解譯單詞 "${targetWord}"...`,
        isLoading: true
      }
    ]);

    try {
      const response = await fetch('/api/explain-word', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ word: targetWord }),
      });

      if (!response.ok) {
        let serverError = '傳輸協議異常，PRTS 的衛星鏈接似乎受到了阻礙';
        try {
          const errData = await response.json();
          if (errData && errData.error) {
            serverError = `PRTS 報錯: ${errData.error}`;
          }
        } catch (_) {}
        throw new Error(serverError);
      }

      const data = await response.json();

      // Ensure data parses correctOption correctly
      if (data.quiz && !data.quiz.correctOption && data.quiz.correctAnswer) {
        data.quiz.correctOption = data.quiz.correctAnswer;
      }

      // Update the loading message with actual result
      setMessages(prev => prev.map(m => {
        if (m.id === aiMsgId) {
          return {
            ...m,
            text: `完成對單詞 "${targetWord}" 的記憶矩陣重構。資料如下：`,
            isLoading: false,
            wordDetails: data
          };
        }
        return m;
      }));
    } catch (err: any) {
      console.error(err);
      setMessages(prev => prev.map(m => {
        if (m.id === aiMsgId) {
          return {
            ...m,
            text: `[ERROR] 神經同步解析失敗。讀取線路中斷。`,
            isLoading: false,
            error: err.message || '訊號傳輸遇到干擾'
          };
        }
        return m;
      }));
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAnswerQuiz = (messageId: string, choiceLetter: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId && msg.wordDetails && msg.wordDetails.quiz) {
        // Find option mapping letters
        // E.g. choiceLetter could be "A", option is "A. conspicuous"
        const correctOpt = msg.wordDetails.quiz.correctOption.trim().toUpperCase()[0];
        const isCorrect = choiceLetter === correctOpt;

        return {
          ...msg,
          wordDetails: {
            ...msg.wordDetails,
            quiz: {
              ...msg.wordDetails.quiz,
              userAnswer: choiceLetter,
              isCorrect: isCorrect
            }
          }
        };
      }
      return msg;
    }));
  };

  return (
    <div className="bg-[#141414] border border-[#3a4a44] p-4 sm:p-5 relative overflow-hidden font-mono text-[#e5e2e1] space-y-4">
      
      {/* Decorative tag */}
      <div className="absolute top-0 right-0 w-3 h-3 bg-[#0e0e0e] rotate-45 transform translate-x-1.5 -translate-y-1.5 border-b border-[#3a4a44]" />

      {/* Title block */}
      <div className="flex items-center gap-2.5 pb-3 border-b border-[#3a4a44]/40">
        <Cpu className="w-5 h-5 text-[#00e0b3] animate-pulse" />
        <div>
          <h4 className="text-sm font-bold text-white tracking-widest uppercase">
            PRTS COGNITIVE DIALOGUE AGENT // 語意交互终端
          </h4>
          <p className="text-[9px] text-[#b9cbc2]/50 tracking-tight leading-none mt-0.5 uppercase">
            Interact with tactical AI to formulate quizzes and unpack definitions on demand.
          </p>
        </div>
      </div>

      {/* Messages Feed View */}
      <div 
        ref={scrollRef}
        className="h-[420px] overflow-y-auto pr-1 space-y-4 text-xs scrollbar-thin scrollbar-thumb-[#3a4a44] scrollbar-track-transparent"
        id="prts-chat-scroll"
      >
        {messages.map((msg) => {
          const isPrts = msg.sender === 'prts';
          
          return (
            <div 
              key={msg.id}
              className={`flex flex-col gap-1.5 max-w-[92%] ${isPrts ? 'mr-auto items-start' : 'ml-auto items-end text-right'}`}
            >
              {/* Sender Name Badge */}
              <span className={`text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded-none font-bold ${
                isPrts 
                  ? 'bg-[#1b2b25] text-[#00e0b3] border border-[#00e0b3]/20' 
                  : 'bg-[#29221b] text-[#ffd700] border border-[#ffd700]/20'
              }`}>
                {isPrts ? "🛰️ PRTS_COGNITIVE // 智能助理" : "👤 DOCTOR // 聯絡指令"}
              </span>

              {/* Message text bubble */}
              <div className={`p-3 rounded-none whitespace-pre-wrap leading-relaxed ${
                isPrts 
                  ? 'bg-[#1a1a1a] border border-[#3a4a44]/60 text-[#b9cbc2]' 
                  : 'bg-[#25201c] border border-[#ffb4ab]/20 text-white font-semibold'
              }`}>
                {msg.text}

                {/* Loading indicator */}
                {msg.isLoading && (
                  <div className="flex items-center gap-2 text-[#00e0b3] mt-2 font-bold font-sans">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span className="text-[10px] animate-pulse tracking-widest">TRANSMITTING ANOMALOUS CHANNELS...</span>
                  </div>
                )}

                {/* Error Block */}
                {msg.error && (
                  <div className="flex items-center gap-2 text-[#ffb4ab] mt-2 bg-[#93000a]/10 p-2 border border-[#ffb4ab]/30">
                    <AlertOctagon className="w-4 h-4 shrink-0" />
                    <span className="text-[10px] leading-relaxed">{msg.error}</span>
                  </div>
                )}
              </div>

              {/* Word definition & Translation display panel card (generated by Gemini) */}
              {msg.wordDetails && (
                <div className="w-full bg-[#111] border border-[#3a4a44] p-4.5 space-y-4 animate-in fade-in duration-300">
                  
                  {/* Word title, phonetic, translation */}
                  <div className="border-b border-[#3a4a44]/50 pb-2.5">
                    <div className="flex flex-wrap items-baseline gap-2.5">
                      <span className="text-lg font-black text-white tracking-wider uppercase font-sans">
                        {msg.wordDetails.word}
                      </span>
                      {msg.wordDetails.pronunciation && (
                        <span className="text-[11px] text-[#00e0b3] font-bold font-mono">
                          {msg.wordDetails.pronunciation}
                        </span>
                      )}
                    </div>
                    <div className="text-sm font-bold text-[#ffd700] mt-1.5 font-sans">
                      {msg.wordDetails.chineseTranslation}
                    </div>
                  </div>

                  {/* English Definition */}
                  <div className="space-y-1">
                    <span className="text-[9px] text-[#b9cbc2]/40 tracking-wider block font-bold uppercase">
                      Definition // 英英釋義:
                    </span>
                    <p className="text-[11px] text-[#e5e2e1] leading-relaxed font-mono">
                      {msg.wordDetails.englishDefinition}
                    </p>
                  </div>

                  {/* Typical usage list */}
                  {msg.wordDetails.usages && msg.wordDetails.usages.length > 0 && (
                    <div className="space-y-1.5 pt-1">
                      <span className="text-[9px] text-[#b9cbc2]/40 tracking-wider block font-bold uppercase">
                        Tactical Usage // 實戰用途與例句:
                      </span>
                      <ul className="space-y-3 block pl-2 border-l border-[#00e0b3]/30">
                        {msg.wordDetails.usages.map((usage, i) => (
                          <li key={i} className="text-[11px] text-[#b9cbc2] leading-relaxed whitespace-pre-wrap break-words pb-2 border-b border-[#3a4a44]/10 last:border-0 last:pb-0">
                            {usage}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Dynamic interactive quiz generator question */}
                  {msg.wordDetails.quiz && (
                    <div className="border border-[#00e0b3]/25 bg-[#0e1614] p-3.5 space-y-3 relative overflow-hidden">
                      <div className="absolute top-0 right-0 py-0.5 px-2 bg-[#00e0b3]/15 text-[#00e0b3] text-[8px] font-bold uppercase tracking-wider">
                        Cognitive Defense Vector // 即時能力驗證
                      </div>

                      <div className="flex items-center gap-1.5 text-white font-bold text-xs mt-1">
                        <HelpCircle className="w-4 h-4 text-[#00e0b3] shrink-0" />
                        <span>請完成以下句意填空演練：</span>
                      </div>

                      <p className="text-[11px] text-[#e5e2e1] leading-relaxed font-sans italic my-1.5 bg-[#141414]/80 p-2 border border-[#3a4a44]/30">
                        &ldquo;{msg.wordDetails.quiz.question}&rdquo;
                      </p>

                      {/* Quiz Options Buttons */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        {msg.wordDetails.quiz.options.map((optionStr) => {
                          // Extract letter which should be A, B, C or D
                          const trimmedOpt = optionStr.trim();
                          const optLetter = trimmedOpt[0]?.toUpperCase() || 'A';
                          
                          const quizInst = msg.wordDetails.quiz;
                          const hasAnswered = quizInst.userAnswer !== undefined;
                          const isSelected = quizInst.userAnswer === optLetter;
                          
                          // Styling feedback
                          let btnStyle = "bg-[#141414] border-[#3a4a44] text-[#b9cbc2] hover:border-[#00e0b3] hover:text-white";
                          if (hasAnswered) {
                            const isThisCorrect = optLetter === quizInst.correctOption.trim().toUpperCase()[0];
                            if (isSelected) {
                              btnStyle = quizInst.isCorrect 
                                ? "bg-[#122c23] border-[#00e0b3] text-[#00e0b3] font-bold" 
                                : "bg-[#291719] border-[#f44336] text-[#ffb4ab] font-bold";
                            } else if (isThisCorrect) {
                              // Highlight correct answer if user missed it
                              btnStyle = "bg-[#122c23] border-[#00e0b3]/40 text-[#00e0b3]/90 italic";
                            } else {
                              btnStyle = "bg-[#141414]/40 border-[#3a4a44]/20 text-[#b9cbc2]/40 pointer-events-none";
                            }
                          }

                          return (
                            <button
                              id={`chat-opt-${msg.id}-${optLetter}`}
                              key={optLetter}
                              disabled={hasAnswered}
                              onClick={() => handleAnswerQuiz(msg.id, optLetter)}
                              className={`px-3 py-2 border text-left text-[11px] transition-all rounded-none ${btnStyle} ${
                                !hasAnswered ? 'cursor-pointer hover:bg-[#191919]' : 'pointer-events-none'
                              }`}
                            >
                              {trimmedOpt}
                            </button>
                          );
                        })}
                      </div>

                      {/* Incorrect/Correct Verdict Section with Explanation */}
                      {msg.wordDetails.quiz.userAnswer !== undefined && (
                        <div className={`p-3 border animate-in slide-in-from-top-2 duration-200 mt-2 ${
                          msg.wordDetails.quiz.isCorrect 
                            ? 'bg-[#12271f] border-[#00e0b3]/40 text-[#e0f2f1]' 
                            : 'bg-[#291617] border-[#ffb4ab]/40 text-[#fbebeb]'
                        }`}>
                          <div className="flex items-center gap-1.5 font-bold mb-1 text-xs">
                            {msg.wordDetails.quiz.isCorrect ? (
                              <>
                                <Check className="w-4 h-4 text-[#00e0b3] shrink-0" />
                                <span className="text-[#00e0b3] uppercase tracking-wide">SYNCHRONIZATION // 正確：認知同步完成</span>
                              </>
                            ) : (
                              <>
                                <X className="w-4 h-4 text-[#ffb4ab] shrink-0" />
                                <span className="text-[#ff9800] uppercase tracking-wide">CALIBRATION // 錯誤：建議校正記憶區段</span>
                              </>
                            )}
                          </div>
                          <p className="text-[11px] leading-relaxed italic text-[#b9cbc2]">
                            {msg.wordDetails.quiz.explanation}
                          </p>
                        </div>
                      )}

                    </div>
                  )}

                </div>
              )}

            </div>
          );
        })}
      </div>

      {/* Suggested Quick Target Word Chips */}
      <div className="space-y-1.5 pt-2 border-t border-[#3a4a44]/25">
        <span className="text-[10px] text-[#b9cbc2]/40 tracking-wider block font-black uppercase">
          Quick Target Suggestions // 快速研擬目擊字庫:
        </span>
        <div className="flex flex-wrap gap-1.5">
          {INSIGHTS_SUGGESTIONS.map((word) => (
            <button
              id={`chip-${word}`}
              key={word}
              onClick={() => handleSendWord(word)}
              disabled={isGenerating}
              className="cursor-pointer text-[10px] font-bold px-2.5 py-1 border border-[#3a4a44]/70 bg-[#191919] text-[#00e0b3] hover:text-[#002118] hover:bg-[#00e0b3] hover:border-[#00e0b3] active:scale-95 transition-all"
            >
              +{word}
            </button>
          ))}
        </div>
      </div>

      {/* Input Submit form */}
      <form 
        onSubmit={(e) => {
          e.preventDefault();
          handleSendWord(inputValue);
        }}
        className="flex items-stretch bg-[#111] border border-[#3a4a44] p-1 gap-1"
      >
        <input
          id="prts-chat-input"
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          disabled={isGenerating}
          placeholder="🎯 輸入英文單詞（例如: compromise/vulnerability）並按下 Enter..."
          className="flex-1 bg-transparent border-0 outline-none px-3 font-mono text-xs text-white placeholder-[#b9cbc2]/30 h-10 w-full"
        />
        <button
          id="prts-chat-send-btn"
          type="submit"
          disabled={!inputValue.trim() || isGenerating}
          className={`cursor-pointer px-4 flex items-center justify-center transition-all ${
            inputValue.trim() && !isGenerating
              ? 'bg-[#00e0b3] text-[#002118] font-bold hover:brightness-110 active:scale-95'
              : 'bg-[#1a1a1a] text-[#b9cbc2]/30 border border-[#3a4a44]/30'
          }`}
        >
          <Send className="w-4 h-4 mr-1.5" />
          <span className="text-xs font-bold font-sans">發送</span>
        </button>
      </form>

    </div>
  );
}
