import { Terminal, Settings, User, LogOut } from 'lucide-react';
import AvatarWithFrame from './AvatarWithFrame';

interface HeaderProps {
  learnerName?: string;
  isDebugMode: boolean;
  onToggleDebug: () => void;
  onOpenSettings: () => void;
  activeTab: 'DASHBOARD' | 'INTEL' | 'ARCHIVES' | 'SHOP' | 'LEADERBOARD' | 'PROFILE' | 'CUSTOM';
  currentUser: string | null;
  onLogout: () => void;
  activeFrame?: string;
  activeAvatar?: string;
  onClickAvatar: () => void;
}

export default function Header({
  learnerName = 'DOCTOR',
  isDebugMode,
  onToggleDebug,
  onOpenSettings,
  activeTab,
  currentUser,
  onLogout,
  activeFrame = 'CLASSIC',
  activeAvatar = 'DEFAULT',
  onClickAvatar,
}: HeaderProps) {
  return (
    <header className="flex justify-between items-center px-6 w-full h-16 fixed top-0 z-50 bg-[#0e0e0e] border-b border-[#3a4a44]">
      <div className="flex items-center gap-3">
        <div className="font-mono text-sm text-[var(--theme-color,#00e0b3)] border-l-2 border-[var(--theme-color,#00e0b3)] pl-2 tracking-widest">
          V-TERMINAL_0.1
        </div>
        <div className="hidden md:block font-mono text-[10px] text-[#b9cbc2] uppercase opacity-50">
          System Status: Active (系統運行中) // Unit: Operator_001
        </div>
        <div className="h-4 w-px bg-[#3a4a44] mx-2 hidden md:block" />
        <h1 className="font-mono text-sm tracking-widest text-[var(--theme-color,#00e0b3)] uppercase font-bold">
          {activeTab === 'ARCHIVES' 
            ? 'ARCHIVES // NOTEBOOK' 
            : activeTab === 'SHOP' 
              ? 'PURCHASE // 採購中心' 
              : activeTab === 'LEADERBOARD'
                ? 'LEADERBOARD // 排行榜'
                : activeTab === 'PROFILE'
                  ? 'OPERATOR ARCHIVES // 個人檔案'
                  : activeTab === 'CUSTOM'
                    ? 'CUSTOM STUDY // 自定義學習'
                    : (currentUser ? currentUser.toUpperCase() : learnerName)}
        </h1>
      </div>

      <div className="flex items-center gap-4">
        {/* Debug Toggle */}
        <button
          onClick={onToggleDebug}
          className={`flex items-center gap-2 transition-colors px-3 py-1 rounded border cursor-pointer ${
            isDebugMode
              ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.1))] border-[var(--theme-color,#00e0b3)] text-[var(--theme-color,#00e0b3)]'
              : 'border-[#3a4a44] text-[#b9cbc2]/70 hover:bg-[#353534]/50'
          }`}
          title="Toggle Debug Log Panel"
        >
          <Terminal className="w-4 h-4" />
          <span className="font-mono text-[11px] tracking-wider hidden sm:inline">DEBUG_MODE</span>
        </button>

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          className="p-1.5 hover:bg-[#353534]/50 text-[#b9cbc2] transition-colors rounded border border-transparent hover:border-[#3a4a44] cursor-pointer"
          title="Vocabulary Configuration options"
        >
          <Settings className="w-5 h-5" />
        </button>

        {/* Logout Button */}
        {currentUser && (
          <button
            onClick={onLogout}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-[#93000a]/10 border border-[#ffb4ab]/30 text-[#ffb4ab] hover:bg-[#93000a]/25 text-xs font-mono tracking-widest transition-all cursor-pointer active:scale-95 animate-pulse"
            title="Log out of system connection"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">LOG_OUT // 登出</span>
          </button>
        )}

        {/* Avatar Profile with Frame */}
        <AvatarWithFrame 
          avatarUrl="https://lh3.googleusercontent.com/aida-public/AB6AXuDZ6YNg8nUcZfJnJCwtNUkl8P6NnWqKI6Mm4LpqHueSewTxL1umt_sU9HHiH_Z15MGaGOxUQiMnEbEQa1cstY7-QyB2rHOS2quVL7uH38cfYAtetTKz-u1NGNDCs_rXCvxb7U7asv6-quSSrAYooP7rjyJRw--4hEkNDL_eEk3Efzx8LxXXApDQyVa90XrN3Ut3tVzMPQqPv3a5SefX8T6HkXXJfaf6u8lJAVk31dqqxLgKyzHFqIhluOD5a2BU4y33e9DWb3jSwcEu"
          activeFrameId={activeFrame}
          activeAvatarId={activeAvatar}
          size="md"
          onClick={onClickAvatar}
        />
      </div>
    </header>
  );
}
