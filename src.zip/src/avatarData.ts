export interface GachaItem {
  id: string;
  type: 'SKIN' | 'FRAME';
  name: string;
  nameChinese: string;
  rarity: 'COMMON' | 'RARE' | 'EPIC' | 'LEGENDARY' | 'LIMITED';
  rarityChinese: string;
  color: string; // Theme accent hex
  glowColor: string; // Accent glow
  bgColor: string; // Box shadow/gradient
  description: string;
  descriptionChinese: string;
}

// Retro-compatibility mock for any vintage avatar references
export interface AvatarItem {
  id: string;
  name: string;
  nameChinese: string;
  rarity: string;
  rarityChinese: string;
  iconName: string;
  color: string;
  bgColor: string;
  description: string;
  descriptionChinese: string;
}

export const GACHA_AVATARS: AvatarItem[] = [
  {
    id: 'DEFAULT',
    name: 'Standard Operator',
    nameChinese: '普通聯絡官',
    rarity: 'COMMON',
    rarityChinese: '普通',
    iconName: 'User',
    color: '#8a8c8e',
    bgColor: '#111111',
    description: 'Rhodes Island Standard operator',
    descriptionChinese: '羅德島製式通訊指令員'
  }
];

export const GACHA_ITEMS: GachaItem[] = [
  // ==================== COMMON (普通 - 3★) - 50% ====================
  {
    id: 'SKIN_YATO_SHADOW',
    type: 'SKIN',
    name: 'Yato Shadow Matte',
    nameChinese: '夜刀 · 影刃墨灰系統UI',
    rarity: 'COMMON',
    rarityChinese: '普通',
    color: '#707070',
    glowColor: 'rgba(112, 112, 112, 0.25)',
    bgColor: 'rgba(112, 112, 112, 0.05)',
    description: 'Matte dark-gray HUD inspired by Yato\'s standard vanguard gear. High stability.',
    descriptionChinese: '【3★/普通】基於先鋒幹員夜刀的面罩與輕甲打造的核心UI。碳黑啞光，極具軍工高溫穩定質感。'
  },
  {
    id: 'FRAME_YATO_TACTICAL',
    type: 'FRAME',
    name: 'Yato Tactical Visor',
    nameChinese: '夜刀 · 遮光護目頭像框',
    rarity: 'COMMON',
    rarityChinese: '普通',
    color: '#909090',
    glowColor: 'rgba(144, 144, 144, 0.2)',
    bgColor: 'rgba(0, 0, 0, 0.5)',
    description: 'A smooth, solid gray matte titanium frame with a single cyan indicator line.',
    descriptionChinese: '【3★/普通】一體化成型的鈦合金灰色邊框，正面鑲嵌着與夜刀遮光面具同源的幽藍指示條。'
  },
  {
    id: 'SKIN_PLUME_SWIFT',
    type: 'SKIN',
    name: 'Plume Messenger Swift',
    nameChinese: '翎羽 · 迅捷守衛護甲UI',
    rarity: 'COMMON',
    rarityChinese: '普通',
    color: '#556b2f',
    glowColor: 'rgba(85, 107, 47, 0.25)',
    bgColor: 'rgba(85, 107, 47, 0.05)',
    description: 'Military-forest green and deep carbon style inspired by Plume\'s sentinel gear.',
    descriptionChinese: '【3★/普通】結合翎羽的拉特蘭邊境巡邏裝備，暗綠與黑灰交錯，富含戰術氣息與堅毅觸感。'
  },
  {
    id: 'FRAME_PLUME_WINGED',
    type: 'FRAME',
    name: 'Plume Winged Ranger',
    nameChinese: '翎羽 · 守衛羽睫頭像框',
    rarity: 'COMMON',
    rarityChinese: '普通',
    color: '#7f8c8d',
    glowColor: 'rgba(127, 140, 141, 0.15)',
    bgColor: 'rgba(0, 0, 0, 0.4)',
    description: 'Minimal guard frame accented with small, sharp wing feathers on the edges.',
    descriptionChinese: '【3★/普通】金屬精鍛邊框，左右兩端附着着翎羽高潔的雕花羽翼折角護片，彰顯巡邏衛兵意志。'
  },

  // ==================== RARE (稀有 - 4★) - 30% ====================
  {
    id: 'SKIN_MELANTHA_ROSE',
    type: 'SKIN',
    name: 'Melantha Midnight Violet',
    nameChinese: '玫蘭莎 · 薔薇幽暗紫UI',
    rarity: 'RARE',
    rarityChinese: '稀有',
    color: '#8a2be2',
    glowColor: 'rgba(138, 43, 226, 0.35)',
    bgColor: 'rgba(138, 43, 226, 0.08)',
    description: 'Dark midnight violet theme with delicate dark orchid hues, inspired by Melantha.',
    descriptionChinese: '【4★/稀有】代表幹員玫蘭莎的深邃紫羅蘭暗色調系統UI，融合了淡雅的劍技鋒芒與優雅的薔薇邊緣。'
  },
  {
    id: 'FRAME_MELANTHA_ROSE',
    type: 'FRAME',
    name: 'Melantha Rose Blade',
    nameChinese: '玫蘭莎 · 薔薇暗影頭像框',
    rarity: 'RARE',
    rarityChinese: '稀有',
    color: '#9370db',
    glowColor: 'rgba(147, 112, 219, 0.4)',
    bgColor: 'rgba(20, 10, 30, 0.6)',
    description: 'Sleek dark violet metallic frame with elegant flower silhouette etchings.',
    descriptionChinese: '【4★/稀有】採用暗紫色精銑工藝的重裝外框，四角鏤刻出淡雅幽香的薔薇徽記，劍氣隱現。'
  },
  {
    id: 'SKIN_FANG_CHARGE',
    type: 'SKIN',
    name: 'Fang Vanguard Charge',
    nameChinese: '芬 · 先鋒挺進極速綠UI',
    rarity: 'RARE',
    rarityChinese: '稀有',
    color: '#20b2aa',
    glowColor: 'rgba(32, 178, 170, 0.35)',
    bgColor: 'rgba(32, 178, 170, 0.08)',
    description: 'Mint teal HUD spectrum inspired by Fang\'s action-ready squad combat gear.',
    descriptionChinese: '【4★/稀有】汲取預備兵小隊隊長「芬」的靈綠塗裝，介面流露着行動小隊的幹練與生生不息的推進能量。'
  },
  {
    id: 'FRAME_FANG_ADVANCED',
    type: 'FRAME',
    name: 'Fang Advance Vanguard',
    nameChinese: '芬 · 十字突擊精制頭像框',
    rarity: 'RARE',
    rarityChinese: '稀有',
    color: '#3cb371',
    glowColor: 'rgba(60, 179, 113, 0.35)',
    bgColor: 'rgba(10, 30, 20, 0.6)',
    description: 'Matte green armor plating frame with neon illuminated corner tracking markers.',
    descriptionChinese: '【4★/稀有】先鋒挺進者專屬軍裝綠飾框，四角配備高亮度綠光指示角，大幅升高圖像凝聚度。'
  },

  // ==================== EPIC (史诗 - 5★) - 13% ====================
  {
    id: 'SKIN_AMIYA_CHIMERA',
    type: 'SKIN',
    name: 'Amiya Chimera Azure',
    nameChinese: '阿米婭 · 奇美拉晶藍UI',
    rarity: 'EPIC',
    rarityChinese: '史詩',
    color: '#00ccff',
    glowColor: 'rgba(0, 204, 255, 0.45)',
    bgColor: 'rgba(0, 204, 255, 0.1)',
    description: 'Shimmering crystal teal HUD with digital terminal rings inspired by Amiya\'s output form.',
    descriptionChinese: '【5★/史詩】羅德島的精神支柱「阿米婭」專屬奇美拉晶藍主介面，注入了源石黑晶與溫潤精神共鳴環。'
  },
  {
    id: 'FRAME_AMIYA_RING',
    type: 'FRAME',
    name: 'Amiya Ring Destiny',
    nameChinese: '阿米婭 · 命運指環特效頭像框',
    rarity: 'EPIC',
    rarityChinese: '史詩',
    color: '#00e5ff',
    glowColor: 'rgba(0, 229, 255, 0.5)',
    bgColor: 'rgba(5, 20, 35, 0.75)',
    description: 'An elegant glass-sharded teal frame bound by floating black inhibitor rings.',
    descriptionChinese: '【5★/史詩】仿製自阿米婭約束指環的透明晶體框，主色淡藍，外圈懸浮飄逸着一組黑晶約束能量環。'
  },
  {
    id: 'SKIN_CHEN_DRAGON',
    type: 'SKIN',
    name: 'Ch\'en Dragon Scale',
    nameChinese: '陳 · 龍炎赤霄重載UI',
    rarity: 'EPIC',
    rarityChinese: '史詩',
    color: '#ff2255',
    glowColor: 'rgba(255, 34, 85, 0.45)',
    bgColor: 'rgba(255, 34, 85, 0.1)',
    description: 'Sleek dark navy and crimson tactical grid reflecting the unyielding authority of Lungmen Guard.',
    descriptionChinese: '【5★/史詩】代表龍門近衛局特別督察官「陳」的冷冽墨藍與赤霄朱紅UI，高對比幾何走線展示執法威信。'
  },
  {
    id: 'FRAME_CHEN_DRACONIC',
    type: 'FRAME',
    name: 'Ch\'en Draconic Armored',
    nameChinese: '陳 · 龍脊斑駁重裝頭像框',
    rarity: 'EPIC',
    rarityChinese: '史詩',
    color: '#ff4466',
    glowColor: 'rgba(255, 68, 102, 0.5)',
    bgColor: 'rgba(30, 5, 10, 0.75)',
    description: 'Heavy composite steel border in deep red and ocean navy, crowned by custom dragon claws.',
    descriptionChinese: '【5★/史詩】近衛局頂端高科技高密度碳鋼護套框，融合龍首流線折痕與赤魂雙色脈衝霓虹。'
  },

  // ==================== LEGENDARY (传说 - 6★) - 5.5% ====================
  {
    id: 'SKIN_TEXAS_WOLF',
    type: 'SKIN',
    name: 'Texas Wild Rain',
    nameChinese: '德克薩斯 · 荒野雨夜UI',
    rarity: 'LEGENDARY',
    rarityChinese: '傳說',
    color: '#ffaa00',
    glowColor: 'rgba(255, 170, 0, 0.55)',
    bgColor: 'rgba(255, 170, 0, 0.12)',
    description: 'Immersive dark theme with yellow sword focus glow and rain streak animation indicators.',
    descriptionChinese: '【6★/傳說】企鵝物流冷酷之狼「德克薩斯」的主題UI。呈現昏暗雨夜街道、高對比警戒金燈、凌厲刀芒軌跡與動態雨滴通量。'
  },
  {
    id: 'FRAME_TEXAS_WOLF',
    type: 'FRAME',
    name: 'Texas Swordmaster Frame',
    nameChinese: '德克薩斯 · 雙刃流光頭像框',
    rarity: 'LEGENDARY',
    rarityChinese: '傳說',
    color: '#ffd000',
    glowColor: 'rgba(255, 208, 0, 0.65)',
    bgColor: 'rgba(15, 10, 2, 0.85)',
    description: 'Refined black-gold frame representing Texas\' swordsmanship, complete with dual glowing energy blade cross.',
    descriptionChinese: '【6★/傳說】奢華黑金拉絲碳鋼外框，下端斜插着兩柄半透明金黃色高爆能量充能光刃，呈現熾烈而克制的切片光霧。'
  },
  {
    id: 'SKIN_MOSTIMA_TIME',
    type: 'SKIN',
    name: 'Mostima Chronos Flux',
    nameChinese: '莫斯提馬 · 歲月晶弦UI',
    rarity: 'LEGENDARY',
    rarityChinese: '傳說',
    color: '#6f00ff',
    glowColor: 'rgba(111, 0, 255, 0.55)',
    bgColor: 'rgba(111, 0, 255, 0.12)',
    description: 'Magical blue-purple interface with background rotating chronological stardust vector grids.',
    descriptionChinese: '【6★/傳說】神秘信使「莫斯提馬」的深海星塵UI。底盤載入動態運行的「黑之鎖」與「白之鍵」時空反演刻度網格，幽邃絕美。'
  },
  {
    id: 'FRAME_MOSTIMA_TIME',
    type: 'FRAME',
    name: 'Mostima Chrono Resonator',
    nameChinese: '莫斯提馬 · 時空雙環特效頭像框',
    rarity: 'LEGENDARY',
    rarityChinese: '傳說',
    color: '#aa55ff',
    glowColor: 'rgba(170, 85, 255, 0.7)',
    bgColor: 'rgba(10, 0, 20, 0.95)',
    description: 'Concentric rotating violet halos mirroring temporal magic, pulsing with cosmic nebula particles.',
    descriptionChinese: '【6★/傳說】由兩圈異步逆向旋轉的虛幻法陣光圈構成的極致之框，無處不在地傾瀉着幽藍星沙與光譜重疊，極度尊貴。'
  },

  // ==================== LIMITED (本期限定 - 6★+) - 1.5% ====================
  {
    id: 'SKIN_W_EMBER',
    type: 'SKIN',
    name: 'W Fiery Ember Revelation',
    nameChinese: 'W · 烈焰啟示錄動態系統UI',
    rarity: 'LIMITED',
    rarityChinese: '本期限定',
    color: '#ff3000',
    glowColor: 'rgba(255, 48, 0, 0.75)',
    bgColor: 'rgba(255, 48, 0, 0.18)',
    description: 'Supreme apocalyptic HUD loaded with dynamic rising magma flames, fiery sparks, and customized red targeting crosshairs.',
    descriptionChinese: '【★限定★】傳奇僱傭兵「W」的至高火控UI。系統底層被爆破戰意浸染，邊緣燃燒着不息的金色烈焰與熱量灰燼粒子，擁有最高級特效。'
  },
  {
    id: 'FRAME_W_EMBER',
    type: 'FRAME',
    name: 'W Apocalypse Combustion',
    nameChinese: 'W · 炙燒煉獄動態頭像框',
    rarity: 'LIMITED',
    rarityChinese: '本期限定',
    color: '#ff1a00',
    glowColor: 'rgba(255, 26, 0, 0.85)',
    bgColor: 'rgba(20, 0, 0, 0.98)',
    description: 'Absolute peak custom frame featuring active flame embers, dynamic shockwave flashes, and red metallic horned details.',
    descriptionChinese: '【★限定★】象徵撒卡茲魔角與毀滅炸藥的動態頭像框。暗黑晶體上不斷噴涌金紅色爆破火舌、呼吸火光，並伴隨環形震盪衝擊波。'
  }
];

export function getRandomGachaItem(): GachaItem {
  const roll = Math.random() * 100;

  if (roll <= 1.5) {
    // Limited (1.5%) - Supreme peak status
    const items = GACHA_ITEMS.filter(a => a.rarity === 'LIMITED');
    return items[Math.floor(Math.random() * items.length)];
  } else if (roll <= 7.0) {
    // Legendary (5.5%) - Beautiful premium
    const items = GACHA_ITEMS.filter(a => a.rarity === 'LEGENDARY');
    return items[Math.floor(Math.random() * items.length)];
  } else if (roll <= 20.0) {
    // Epic (13%) - Distinctive operator themed
    const items = GACHA_ITEMS.filter(a => a.rarity === 'EPIC');
    return items[Math.floor(Math.random() * items.length)];
  } else if (roll <= 50.0) {
    // Rare (30%) - Well crafted
    const items = GACHA_ITEMS.filter(a => a.rarity === 'RARE');
    return items[Math.floor(Math.random() * items.length)];
  } else {
    // Common (50%) - Simple
    const items = GACHA_ITEMS.filter(a => a.rarity === 'COMMON');
    return items[Math.floor(Math.random() * items.length)];
  }
}

// Keep the old exporter name for safety
export function getRandomAvatar(): AvatarItem {
  return GACHA_AVATARS[0];
}
