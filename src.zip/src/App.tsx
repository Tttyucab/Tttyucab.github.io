import { useState, useEffect, CSSProperties } from 'react';
import { Terminal, Shield, RefreshCw, BarChart2, BookOpen, AlertOctagon, Sparkles, X, ChevronRight, HelpCircle, ShoppingBag, Trophy, User, Layers } from 'lucide-react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Quiz from './components/Quiz';
import Intel from './components/Intel';
import Archives from './components/Archives';
import Auth from './components/Auth';
import Shop, { SHOP_SKINS } from './components/Shop';
import Leaderboard from './components/Leaderboard';
import Profile from './components/Profile';
import CustomStudy from './components/CustomStudy';
import { VOCABULARY_DATABASE, TACTICAL_BADGES } from './data';
import { SENTENCE_STRUCTURE_DATABASE, selectGrammarQuestions } from './sentenceData';
import { VocabularyWord, UserProgress, WordLevel } from './types';

const checkAndUnlockBadges = (progress: UserProgress): { updated: UserProgress, newlyUnlocked: string[] } => {
  const currentUnlocked = progress.unlockedBadges || [];
  const newlyUnlocked: string[] = [];

  // BADGE 1: INIT_LINK has always been established
  if (!currentUnlocked.includes('INIT_LINK')) {
    newlyUnlocked.push('INIT_LINK');
  }

  // BADGE 2: STREAK_WARRIOR (>= 3 streaks)
  if (progress.currentStreak >= 3 && !currentUnlocked.includes('STREAK_WARRIOR')) {
    newlyUnlocked.push('STREAK_WARRIOR');
  }

  // BADGE 3: STREAK_WEEK (>= 7 streaks)
  if (progress.currentStreak >= 7 && !currentUnlocked.includes('STREAK_WEEK')) {
    newlyUnlocked.push('STREAK_WEEK');
  }

  // BADGE 4: DECIPHERER_10 (>= 10 mastered words)
  const masteredCount = progress.completedWordIds ? progress.completedWordIds.length : 0;
  if (masteredCount >= 10 && !currentUnlocked.includes('DECIPHERER_10')) {
    newlyUnlocked.push('DECIPHERER_10');
  }

  // BADGE 5: DECIPHERER_50
  if (masteredCount >= 50 && !currentUnlocked.includes('DECIPHERER_50')) {
    newlyUnlocked.push('DECIPHERER_50');
  }

  // BADGE 6: DECIPHERER_100
  if (masteredCount >= 100 && !currentUnlocked.includes('DECIPHERER_100')) {
    newlyUnlocked.push('DECIPHERER_100');
  }

  // BADGE 7: TACTICAL_EXCELLENCE (attempts >= 15 with accuracy >= 90%)
  const accuracy = progress.totalAttempts >= 15 ? Math.round((progress.correctAttempts / progress.totalAttempts) * 100) : 0;
  if (progress.totalAttempts >= 15 && accuracy >= 90 && !currentUnlocked.includes('TACTICAL_EXCELLENCE')) {
    newlyUnlocked.push('TACTICAL_EXCELLENCE');
  }

  // BADGE 8: ORUNDUM_COLLECTOR (orundum >= 5000)
  const orundumVal = progress.orundum !== undefined ? progress.orundum : 1200;
  if (orundumVal >= 5000 && !currentUnlocked.includes('ORUNDUM_COLLECTOR')) {
    newlyUnlocked.push('ORUNDUM_COLLECTOR');
  }

  if (newlyUnlocked.length > 0) {
    const updatedUnlocked = [...currentUnlocked, ...newlyUnlocked];
    return {
      updated: {
        ...progress,
        unlockedBadges: updatedUnlocked
      },
      newlyUnlocked
    };
  }

  return {
    updated: {
      ...progress,
      unlockedBadges: currentUnlocked
    },
    newlyUnlocked
  };
};

const LEVEL_SEQUENCE: WordLevel[] = ['BASIC', 'INTERMEDIATE', 'TOEIC', 'TOEFL'];

const CONSOLIDATION_MAP: { [key: string]: string } = {
  'OPS-TOEFL-04': 'OPS-BASIC-03', // JEOPARDIZE -> CANCEL
  'OPS-TOEFL-03': 'OPS-BASIC-02', // FACILITATE -> ACCELERATE
  'OPS-TOEFL-02': 'OPS-TOEIC-02', // DEMOLISH -> RENOVATE
  'OPS-TOEFL-01': 'OPS-BASIC-04', // COMPREHEND -> IGNORE
  'OPS-TOEIC-03': 'OPS-BASIC-03', // TERMINATE -> CANCEL
  'OPS-TOEIC-01': 'OPS-INT-03',    // COLLABORATE -> COMPENSATE
  'OPS-TOEIC-04': 'OPS-INT-03',    // NEGOTIATE -> COMPENSATE
  'OPS-TOEIC-02': 'OPS-BASIC-01',   // RENOVATE -> POSTPONE
  'OPS-INT-04': 'OPS-BASIC-02',    // ACCUMULATE -> ACCELERATE
  'OPS-INT-03': 'OPS-BASIC-01',    // COMPENSATE -> POSTPONE
  'OPS-INT-01': 'OPS-BASIC-03',    // ALLOCATE -> CANCEL
  'OPS-INT-02': 'OPS-BASIC-04',    // SIMULATE -> IGNORE
};

const selectLevelWords = (level: WordLevel, count: number): VocabularyWord[] => {
  const pool = VOCABULARY_DATABASE.filter(w => w.level === level);
  if (pool.length === 0) return [];
  const shuffled = [...pool].sort(() => 0.5 - Math.random());
  const selected: VocabularyWord[] = [];
  for (let i = 0; i < count; i++) {
    selected.push(shuffled[i % shuffled.length]);
  }
  return selected;
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'INTEL' | 'ARCHIVES' | 'SHOP' | 'LEADERBOARD' | 'PROFILE' | 'CUSTOM'>('DASHBOARD');
  const [isDebugMode, setIsDebugMode] = useState<boolean>(false);
  const [isQuizActive, setIsQuizActive] = useState<boolean>(false);
  const [quizLength, setQuizLength] = useState<number>(10);
  const [currentLevel, setCurrentLevel] = useState<WordLevel>('BASIC');
  const [quizMode, setQuizMode] = useState<'VOCABULARY' | 'STRUCTURE'>('VOCABULARY');

  // Active current user state
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  // Active quiz state
  const [quizWords, setQuizWords] = useState<VocabularyWord[]>([]);
  const [currentQuizIndex, setCurrentQuizIndex] = useState<number>(0);
  const [consecutiveCorrect, setConsecutiveCorrect] = useState<number>(0);
  const [sessionCorrectCount, setSessionCorrectCount] = useState<number>(0);
  const [sessionEarnedOrundum, setSessionEarnedOrundum] = useState<number>(0);
  
  // Feedback toast for quiz
  const [toastMessage, setToastMessage] = useState<{ text: string; isCorrect: boolean } | null>(null);

  // Custom safe PRTS-themed confirmation modal
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  // Initialize progress state
  const [progress, setProgress] = useState<UserProgress>({
    completedWordIds: [],
    missedWords: {
      'OPS-BASIC-01': 3,
      'OPS-BASIC-03': 1,
      'OPS-INT-02': 2
    },
    lastSyncTimes: {
      'OPS-BASIC-01': '12H_AGO',
      'OPS-BASIC-03': '24H_AGO',
      'OPS-INT-02': '05H_AGO'
    },
    currentStreak: 12,
    combatEfficiency: 80,
    reEducationCount: 3,
    totalAttempts: 15,
    correctAttempts: 12
  });

  // Load user and progress from localStorage on boot
  useEffect(() => {
    const savedUser = localStorage.getItem('lexiquiz_tactical_current_user');
    if (savedUser) {
      setCurrentUser(savedUser);
      const savedProgress = localStorage.getItem(`lexiquiz_tactical_progress_${savedUser}`);
      if (savedProgress) {
        try {
          const parsed = JSON.parse(savedProgress);
          checkDailyLoginBonus(savedUser, parsed);
        } catch (err) {
          console.error('Failed to parse progress from local cache', err);
        }
      }
    }
  }, []);

  // Check and claim daily login Orundum bonus helper
  const checkDailyLoginBonus = (user: string, currentProgress: UserProgress) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const isDev = user.toUpperCase() === 'DEVELOPER';
    let orundum = currentProgress.orundum !== undefined ? currentProgress.orundum : (isDev ? 900000 : 1200);
    let hasInitDev = currentProgress.hasInitializedDeveloperOrundum;
    if (isDev && !hasInitDev) {
      orundum = 900000;
      hasInitDev = true;
    }
    const lastLogin = currentProgress.lastLoginDate;
    const ownedSkins = currentProgress.ownedSkins || ['CLASSIC'];
    const activeSkin = currentProgress.activeSkin || 'CLASSIC';
    const ownedSouvenirs = currentProgress.ownedSouvenirs || [];
    const ownedFrames = currentProgress.ownedFrames || ['CLASSIC'];
    const activeFrame = currentProgress.activeFrame || 'CLASSIC';
    const points = currentProgress.points !== undefined ? currentProgress.points : 30;
    const unlockedBadges = currentProgress.unlockedBadges || ['INIT_LINK'];

    if (lastLogin !== todayStr) {
      const newOrundum = orundum + 600;
      const newPoints = points + 50; // Daily study login points bonus!
      const updated: UserProgress = {
        ...currentProgress,
        orundum: newOrundum,
        lastLoginDate: todayStr,
        ownedSkins,
        activeSkin,
        ownedSouvenirs,
        ownedFrames,
        activeFrame,
        points: newPoints,
        unlockedBadges,
        hasInitializedDeveloperOrundum: hasInitDev
      };
      saveProgress(updated);
      
      // Delay feedback message to show cleanly
      setTimeout(() => {
        setToastMessage({
          text: 'DAILY_LINK_ESTABLISHED // 每日建立神經連結：發放 +600 合成玉、+50 積分獎勵！',
          isCorrect: true
        });
      }, 1000);
      return updated;
    } else {
      const updated: UserProgress = {
        ...currentProgress,
        orundum,
        lastLoginDate: lastLogin || todayStr,
        ownedSkins,
        activeSkin,
        ownedSouvenirs,
        ownedFrames,
        activeFrame,
        points,
        unlockedBadges,
        hasInitializedDeveloperOrundum: hasInitDev
      };
      saveProgress(updated);
      return updated;
    }
  };

  // Save progress changes to user-specific slots
  const saveProgress = (updated: UserProgress) => {
    const { updated: finalProgress, newlyUnlocked } = checkAndUnlockBadges(updated);
    setProgress(finalProgress);
    if (currentUser) {
      localStorage.setItem(`lexiquiz_tactical_progress_${currentUser}`, JSON.stringify(finalProgress));
    } else {
      localStorage.setItem('lexiquiz_tactical_progress', JSON.stringify(finalProgress));
    }

    if (newlyUnlocked.length > 0) {
      newlyUnlocked.forEach((badgeId) => {
        const badgeObj = TACTICAL_BADGES.find(b => b.id === badgeId);
        const badgeName = badgeObj ? badgeObj.nameChinese : badgeId;
        setTimeout(() => {
          setToastMessage({
            text: `MILESTONE_UNLOCKED // 解鎖戰術徽章：【${badgeName}】！請前往檔案室審閱。`,
            isCorrect: true
          });
        }, 1200);
      });
    }
  };

  // Auth Operations
  const handleLoginSuccess = (username: string) => {
    setCurrentUser(username);
    localStorage.setItem('lexiquiz_tactical_current_user', username);

    const savedProgress = localStorage.getItem(`lexiquiz_tactical_progress_${username}`);
    const isDev = username.toUpperCase() === 'DEVELOPER';
    if (savedProgress) {
      try {
        const parsed = JSON.parse(savedProgress);
        checkDailyLoginBonus(username, parsed);
      } catch (err) {
        console.error(err);
      }
    } else {
      // Seed initial mock statistics so the dashboard starts highly visual and engaging
      const freshSeed: UserProgress = {
        completedWordIds: [],
        missedWords: {
          'OPS-BASIC-01': 3,
          'OPS-BASIC-03': 1,
          'OPS-INT-02': 2
        },
        lastSyncTimes: {
          'OPS-[#00e0b3]': 'JUST_NOW'
        },
        currentStreak: 0,
        combatEfficiency: 100,
        reEducationCount: 3,
        totalAttempts: 3,
        correctAttempts: 3,
        orundum: isDev ? 900000 : 1200,
        lastLoginDate: new Date().toISOString().split('T')[0],
        ownedSkins: ['CLASSIC'],
        activeSkin: 'CLASSIC',
        ownedSouvenirs: [],
        ownedFrames: ['CLASSIC'],
        activeFrame: 'CLASSIC',
        points: 30,
        unlockedBadges: ['INIT_LINK'],
        hasInitializedDeveloperOrundum: isDev ? true : undefined
      };
      saveProgress(freshSeed);
      localStorage.setItem(`lexiquiz_tactical_progress_${username}`, JSON.stringify(freshSeed));
    }
  };

  // Logout operations
  const handleLogout = () => {
    setConfirmDialog({
      isOpen: true,
      title: 'PRTS TERMINATION // 終止系統鏈接',
      message: '確定要登出當前系統鏈接，返回登錄認證介面嗎？此操作將暫時中斷神經同步，當前會話狀態將被妥善保存。',
      onConfirm: () => {
        setCurrentUser(null);
        localStorage.removeItem('lexiquiz_tactical_current_user');
        setIsQuizActive(false);
        setActiveTab('DASHBOARD');
        setConfirmDialog(p => ({ ...p, isOpen: false }));
      }
    });
  };

  // Reset metrics option (available in Settings or debug)
  const handleResetTelemetry = () => {
    const isDev = currentUser?.toUpperCase() === 'DEVELOPER';
    const fresh: UserProgress = {
      completedWordIds: [],
      missedWords: {},
      lastSyncTimes: {},
      currentStreak: 0,
      combatEfficiency: 0,
      reEducationCount: 0,
      totalAttempts: 0,
      correctAttempts: 0,
      orundum: isDev ? 900000 : 1200,
      lastLoginDate: new Date().toISOString().split('T')[0],
      ownedSkins: ['CLASSIC'],
      activeSkin: 'CLASSIC',
      ownedSouvenirs: [],
      ownedFrames: ['CLASSIC'],
      activeFrame: 'CLASSIC',
      points: 0,
      unlockedBadges: ['INIT_LINK'],
      hasInitializedDeveloperOrundum: isDev ? true : undefined
    };
    saveProgress(fresh);
    setIsQuizActive(false);
    setActiveTab('DASHBOARD');
  };

  // Trigger Quiz Launch
  const handleInitializeOperation = () => {
    // Filter words matching the level and fill to exact selected plan quantity (5, 10, 20)
    const selected = quizMode === 'STRUCTURE'
      ? selectGrammarQuestions(currentLevel, quizLength)
      : selectLevelWords(currentLevel, quizLength);

    if (selected.length === 0) {
      alert(`未檢測到與該級別相關的戰術演練數據: ${currentLevel}`);
      return;
    }

    setQuizWords(selected);
    setCurrentQuizIndex(0);
    setConsecutiveCorrect(0);
    setSessionCorrectCount(0);
    setSessionEarnedOrundum(0);
    setIsQuizActive(true);
    setToastMessage(null);
  };

  // Launch a challenge from Leaderboard on a specific level
  const handleStartChallenge = (level: WordLevel) => {
    setCurrentLevel(level);
    // Filter words matching the level and fill to exact selected plan quantity (5, 10, 20)
    const selected = quizMode === 'STRUCTURE'
      ? selectGrammarQuestions(level, quizLength)
      : selectLevelWords(level, quizLength);

    if (selected.length === 0) {
      alert(`未檢測到與該級別相關的戰術演練數據: ${level}`);
      return;
    }

    setQuizWords(selected);
    setCurrentQuizIndex(0);
    setConsecutiveCorrect(0);
    setSessionCorrectCount(0);
    setSessionEarnedOrundum(0);
    setIsQuizActive(true);
    setToastMessage(null);
  };

  // Initialize single word custom quiz from Notebook Review
  const handleLaunchSingleWordQuiz = (word: VocabularyWord) => {
    // Start a 1-unit custom target loop
    setQuizWords([word]);
    setCurrentQuizIndex(0);
    setConsecutiveCorrect(0);
    setSessionCorrectCount(0);
    setSessionEarnedOrundum(0);
    setIsQuizActive(true);
    setToastMessage(null);
  };

  // Handle Answer completed
  const handleAnswerSubmit = (isCorrectAnswer: boolean, chosenOption: string) => {
    const currentWord = quizWords[currentQuizIndex];
    let levelShiftMessage = '';
    let updatedQuizWords = [...quizWords];

    const nextSessionCorrectCount = sessionCorrectCount + (isCorrectAnswer ? 1 : 0);
    let questionReward = 0;
    if (isCorrectAnswer) {
      questionReward = 10;
    }
    const nextSessionEarnedOrundum = sessionEarnedOrundum + questionReward;
    setSessionCorrectCount(nextSessionCorrectCount);
    setSessionEarnedOrundum(nextSessionEarnedOrundum);

    if (isCorrectAnswer) {
      const nextConsecutive = consecutiveCorrect + 1;
      setConsecutiveCorrect(nextConsecutive);

      if (nextConsecutive >= 3) {
        // Elevate level
        const currentWordLevelIndex = LEVEL_SEQUENCE.indexOf(currentWord.level);
        if (currentWordLevelIndex < LEVEL_SEQUENCE.length - 1) {
          const nextLevel = LEVEL_SEQUENCE[currentWordLevelIndex + 1];
          setConsecutiveCorrect(0);
          setCurrentLevel(nextLevel);
          
          // Repopulate future questions with nextLevel words
          const remainingCount = quizWords.length - (currentQuizIndex + 1);
          if (remainingCount > 0) {
            const nextLevelWords = quizMode === 'STRUCTURE'
              ? selectGrammarQuestions(nextLevel, remainingCount)
              : selectLevelWords(nextLevel, remainingCount);
            updatedQuizWords.splice(currentQuizIndex + 1, remainingCount, ...nextLevelWords);
            setQuizWords(updatedQuizWords);
          }
          levelShiftMessage = ` // 雙向升級！連續答對 ${nextConsecutive} 題，系統自動升階至【${nextLevel}】！`;
        } else {
          // Already Max level
          setConsecutiveCorrect(0);
        }
      }
    } else {
      setConsecutiveCorrect(0);
      const consolidationId = CONSOLIDATION_MAP[currentWord.id];
      if (consolidationId) {
        const simplerWord = VOCABULARY_DATABASE.find(w => w.id === consolidationId);
        if (simplerWord) {
          const remainingCount = quizWords.length - (currentQuizIndex + 1);
          if (remainingCount > 0) {
            // Inject simplerWord next
            updatedQuizWords[currentQuizIndex + 1] = simplerWord;
            
            // Downgrade all subsequent questions (currentQuizIndex + 2 onwards) to the lower difficulty level
            const currentWordLevelIndex = LEVEL_SEQUENCE.indexOf(currentWord.level);
            if (currentWordLevelIndex > 0) {
              const prevLevel = LEVEL_SEQUENCE[currentWordLevelIndex - 1];
              setCurrentLevel(prevLevel);
              const rebuildCount = quizWords.length - (currentQuizIndex + 2);
              if (rebuildCount > 0) {
                const prevLevelWords = quizMode === 'STRUCTURE'
                  ? selectGrammarQuestions(prevLevel, rebuildCount)
                  : selectLevelWords(prevLevel, rebuildCount);
                updatedQuizWords.splice(currentQuizIndex + 2, rebuildCount, ...prevLevelWords);
              }
            }
            setQuizWords(updatedQuizWords);
            levelShiftMessage = ` // 降級防線！下一題注入同義/關聯基礎詞【${simplerWord.word}】`;
          }
        }
      } else {
        const currentWordLevelIndex = LEVEL_SEQUENCE.indexOf(currentWord.level);
        if (currentWordLevelIndex > 0) {
          const prevLevel = LEVEL_SEQUENCE[currentWordLevelIndex - 1];
          setCurrentLevel(prevLevel);
          const remainingCount = quizWords.length - (currentQuizIndex + 1);
          if (remainingCount > 0) {
            const prevLevelWords = quizMode === 'STRUCTURE'
              ? selectGrammarQuestions(prevLevel, remainingCount)
              : selectLevelWords(prevLevel, remainingCount);
            updatedQuizWords.splice(currentQuizIndex + 1, remainingCount, ...prevLevelWords);
            setQuizWords(updatedQuizWords);
          }
          levelShiftMessage = ` // 難度防線！系統調降至【${prevLevel}】`;
        }
      }
    }

    // Visual alert toast feedback matching mockup
    setToastMessage({
      text: isCorrectAnswer 
        ? `Target_Eliminated // 答對同步成功${levelShiftMessage}` 
        : `Target_Mismatch // 答錯 (正確答案: ${currentWord.correctAnswer})${levelShiftMessage}`,
      isCorrect: isCorrectAnswer
    });

    // Fade toast after 4.5s
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);

    // Update statistics
    const updatedMissed = { ...progress.missedWords };
    const updatedSyncTimes = { ...progress.lastSyncTimes };
    let completedIds = [...progress.completedWordIds];

    if (!completedIds.includes(currentWord.id)) {
      completedIds.push(currentWord.id);
    }

    if (isCorrectAnswer) {
      // Reduce the missed count if correct, simulating correct mastering of errors
      if (updatedMissed[currentWord.id]) {
        updatedMissed[currentWord.id] -= 1;
        if (updatedMissed[currentWord.id] <= 0) {
          delete updatedMissed[currentWord.id];
          delete updatedSyncTimes[currentWord.id];
        } else {
          updatedSyncTimes[currentWord.id] = 'RE-EXAMINED_JUST_NOW';
        }
      }
    } else {
      // Increment missed count
      updatedMissed[currentWord.id] = (updatedMissed[currentWord.id] || 0) + 1;
      updatedSyncTimes[currentWord.id] = 'JUST_NOW';
    }

    const newAttempts = progress.totalAttempts + 1;
    const newCorrect = progress.correctAttempts + (isCorrectAnswer ? 1 : 0);
    const newEfficiency = Math.round((newCorrect / newAttempts) * 100);

    const isLastQuestion = currentQuizIndex + 1 >= quizWords.length;
    let newStreak = progress.currentStreak;

    // Quiz completed cleanly, increment concurrent streak!
    if (isLastQuestion && !isCorrectAnswer && quizWords.length > 1) {
      // If failed the final but quiz is large, maintain streak
    } else if (isLastQuestion && isCorrectAnswer) {
      newStreak += 1;
    }

    const isDevActive = currentUser?.toUpperCase() === 'DEVELOPER';
    const currentOrundum = progress.orundum !== undefined ? progress.orundum : (isDevActive ? 900000 : 1200);
    
    // Calculate level difficulty multiplier: 100% for BASIC, and +10% for each higher level
    const levelIndex = LEVEL_SEQUENCE.indexOf(currentLevel);
    const multiplier = 1 + levelIndex * 0.1;
    const finalEarnedOrundum = Math.round(nextSessionEarnedOrundum * multiplier);
    const completedOrundumBonus = isLastQuestion ? finalEarnedOrundum : 0;

    // Gamification Points Calculation
    const currentPoints = progress.points !== undefined ? progress.points : 30;
    let earnedPointsThisQuestion = 0;
    if (isCorrectAnswer) {
      const nextConsecutive = consecutiveCorrect + 1;
      earnedPointsThisQuestion = 10 + (nextConsecutive * 3);
    }
    const completionPointsBonus = isLastQuestion ? (nextSessionCorrectCount * 15) : 0;
    const finalPoints = currentPoints + earnedPointsThisQuestion + completionPointsBonus;

    const updated: UserProgress = {
      completedWordIds: completedIds,
      missedWords: updatedMissed,
      lastSyncTimes: updatedSyncTimes,
      currentStreak: newStreak,
      combatEfficiency: newEfficiency,
      reEducationCount: Object.keys(updatedMissed).length,
      totalAttempts: newAttempts,
      correctAttempts: newCorrect,
      orundum: currentOrundum + completedOrundumBonus,
      lastLoginDate: progress.lastLoginDate || new Date().toISOString().split('T')[0],
      ownedSkins: progress.ownedSkins || ['CLASSIC'],
      activeSkin: progress.activeSkin || 'CLASSIC',
      ownedSouvenirs: progress.ownedSouvenirs || [],
      ownedFrames: progress.ownedFrames || ['CLASSIC'],
      activeFrame: progress.activeFrame || 'CLASSIC',
      points: finalPoints,
      unlockedBadges: progress.unlockedBadges || ['INIT_LINK']
    };

    saveProgress(updated);

    // Move to next question or complete quiz
    if (isLastQuestion) {
      const finalAccuracy = Math.round((nextSessionCorrectCount / quizWords.length) * 100);
      const multiplierPct = 100 + levelIndex * 10;
      setToastMessage({
        text: `TRAINING_COMPLETE // 學習同步完成！答對率: ${finalAccuracy}% (${nextSessionCorrectCount}/${quizWords.length})，難度加成: ${multiplierPct}%，累計發放 +${finalEarnedOrundum} 合成玉、+${completionPointsBonus} 認知積分！`,
        isCorrect: true
      });
      setTimeout(() => {
        setIsQuizActive(false);
        setActiveTab('INTEL'); // jump to intel evaluation showing AI evaluation advice
      }, 3500);
    } else {
      setCurrentQuizIndex(prev => prev + 1);
    }
  };

  // Math helper metrics
  const wordsInLevel = quizMode === 'STRUCTURE'
    ? SENTENCE_STRUCTURE_DATABASE.filter(w => w.level === currentLevel)
    : VOCABULARY_DATABASE.filter(w => w.level === currentLevel);
  const completedWordsInLevel = wordsInLevel.filter(
    w => progress.completedWordIds.includes(w.id) && !progress.missedWords[w.id]
  ).length;

  // Active custom skin configuration
  const currentSkinId = progress.activeSkin || 'CLASSIC';
  const activeSkinConfig = SHOP_SKINS.find(s => s.id === currentSkinId) || SHOP_SKINS[0];

  if (!currentUser) {
    return <Auth onSuccess={handleLoginSuccess} />;
  }

  return (
    <div 
      className="bg-[#131313] text-[#e5e2e1] font-sans min-h-screen flex flex-col relative selection:bg-[var(--theme-color,#00e0b3)] selection:text-[#002118]"
      style={{
        '--theme-color': activeSkinConfig.primaryColor,
        '--theme-color-bg': activeSkinConfig.bgColor,
        '--theme-color-glow': activeSkinConfig.glowColor
      } as CSSProperties}
    >
      {/* Repeating background micro terminal grid CRT simulation line texture */}
      <div className="fixed inset-0 pointer-events-none bg-scanline z-40 opacity-5" />

      {/* Lungmen Skin Ambient Atmosphere Layer */}
      {currentSkinId === 'LUNGMEN' && (
        <div id="lungmen-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          {/* Neon Grid Border Trim */}
          <div className="absolute inset-5 border border-[var(--theme-color,#ff6a00)]/10 rounded-sm pointer-events-none hidden md:block">
            {/* Corner Bracket Details */}
            <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-[var(--theme-color,#ff6a00)]/40" />
            <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-[var(--theme-color,#ff6a00)]/40" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-[var(--theme-color,#ff6a00)]/40" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-[var(--theme-color,#ff6a00)]/40" />
            
            {/* Fine print labels */}
            <span className="absolute top-1 left-3 font-mono text-[8px] text-[var(--theme-color,#ff6a00)]/40 tracking-wider">L.G.D. SYSTEM SECURITY FRAMEWAY v4.2</span>
            <span className="absolute bottom-1 right-3 font-mono text-[8px] text-[var(--theme-color,#ff6a00)]/40 tracking-wider">AUTHENTIC COMM PATH // CLS-LVL: SECURE</span>
          </div>

          {/* Symmetrical Oriental Octagonal Trellis/Lattice Border Watermarks */}
          <div className="absolute top-0 bottom-0 left-0 w-24 opacity-[0.04] bg-[radial-gradient(circle_at_center,var(--theme-color,#ff6a00)_1px,transparent_1px)] bg-[size:16px_16px] hidden xl:block" />
          <div className="absolute top-0 bottom-0 right-0 w-24 opacity-[0.04] bg-[radial-gradient(circle_at_center,var(--theme-color,#ff6a00)_1px,transparent_1px)] bg-[size:16px_16px] hidden xl:block" />

          {/* Oriental traditional mountain/wave vector panel - Inspired by Image 1 (Wei Yenwu's office backboard panels) */}
          <div className="absolute bottom-16 left-4 w-96 h-48 opacity-[0.05] text-[var(--theme-color,#ff6a00)] hidden lg:block transition-all pointer-events-none">
            <svg viewBox="0 0 400 200" fill="none" stroke="currentColor" strokeWidth="1.2" className="w-full h-full">
              {/* Sun/Core Sphere */}
              <circle cx="200" cy="80" r="28" strokeDasharray="3 3" />
              {/* Mountain Silhouettes */}
              <path d="M10 180 L80 100 L140 150 L220 60 L310 160 L390 120 L390 180 Z" strokeWidth="1" />
              <path d="M50 180 L120 120 L200 170 L280 90 L350 180 Z" strokeWidth="1.5" />
              {/* Traditional Wave Swirls */}
              <path d="M 10 185 Q 30 175 50 185 T 90 185 T 130 185 T 170 185 T 210 185 T 250 185 T 290 185 T 330 185 T 370 185" />
              <path d="M 20 192 Q 40 182 60 192 T 100 192 T 140 192 T 180 192 T 220 192 T 260 192 T 300 192 T 340 192 T 380 192" />
              {/* Traditional Cloud wisps */}
              <path d="M 60 40 Q 80 30 100 40 T 140 40" strokeDasharray="2 2" />
              <path d="M 260 50 Q 280 40 300 50 T 340 50" strokeDasharray="2 2" />
            </svg>
            <div className="text-[8px] font-mono tracking-widest text-[var(--theme-color,#ff6a00)]/30 text-center uppercase mt-1">龍門山河萬家燈火 · TRADITIONAL LANDSCAPE EMBLEM</div>
          </div>

          {/* Large Lungmen Guard Dragon Emblem Watermark bottom-right */}
          <div className="absolute -bottom-16 -right-16 w-80 h-80 opacity-5 sm:opacity-[0.12] text-[var(--theme-color,#ff6a00)] pointer-events-none transform rotate-12 transition-all">
            <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full text-current">
              {/* Central Spear Horn */}
              <path d="M50 10 L54 35 L46 35 Z" fill="currentColor" opacity="0.3" />
              <path d="M50 10 L50 35" />
              {/* Symmetric Outer Horns Left */}
              <path d="M42 22 L36 8 L32 20 L24 14 L28 32 L16 28 L22 41" />
              {/* Symmetric Outer Horns Right */}
              <path d="M58 22 L64 8 L68 20 L76 14 L72 32 L84 28 L78 41" />
              {/* Cheeks / Side spikes Left */}
              <path d="M22 55 L16 57 L28 65 L22 67 L34 71 L30 73 M22 71 L26 73" />
              {/* Cheeks / Side spikes Right */}
              <path d="M78 55 L84 57 L72 65 L78 67 L66 71 L70 73 M78 71 L74 73" />
              {/* Symmetrical Eyes (very sharp triangles or polygons) */}
              <polygon points="44,52 35,50 42,46" fill="currentColor" />
              <polygon points="56,52 65,50 58,46" fill="currentColor" />
              {/* Brow structure */}
              <path d="M38 42 L50 48 L62 42" />
              <path d="M34 46 L50 53 L66 46" />
              {/* Forehead Plates */}
              <path d="M46 25 L50 21 L54 25 L50 35 Z" />
              {/* Jaw / Chin Spikes */}
              <path d="M38 71 L50 64 L62 71" />
              <path d="M44 73 L50 85 L56 73" />
              <path d="M47 80 L50 88 L53 80" />
              <path d="M38 67 L50 78 L62 67" />
            </svg>
          </div>

          {/* Little Lungmen watermark top-left for military terminal style */}
          <div className="absolute top-28 left-8 text-[9px] font-mono tracking-widest text-[var(--theme-color,#ff6a00)]/25 uppercase font-black hidden lg:flex flex-col gap-1 select-none text-left bg-black/40 p-3 border border-[#ff6a00]/10 rounded">
            <span className="text-[#ff6a00] font-black border-b border-[#ff6a00]/30 pb-1 mb-1">L.G.D. COGNITIVE SUBNET // 龍門專網</span>
            <span>SECURE TERMINAL: L.G.D._NET_LUMINOUS_v4.2</span>
            <span>SECTOR: LUNGMEN EXECUTIVE_CHAMBER_01</span>
            <span>STATUS: COGNITIVE OVERLAY ON</span>
            <span>OFFICER ROSTER: CHE'N // HOSHIGUMA // SWIRE</span>
          </div>

          {/* Traditional vermilion "龍門" Chinese Seal Stamp Watermark - Top Right */}
          <div className="absolute top-28 right-8 w-20 h-20 opacity-[0.08] text-[var(--theme-color,#ff6a00)] border-4 border-double border-current flex flex-col justify-center items-center font-bold font-mono tracking-tighter rounded-sm hidden lg:flex select-none transform rotate-3">
            <span className="text-xl font-black">龍門</span>
            <span className="text-[8px] leading-none uppercase tracking-widest font-black border-t border-current mt-1 pt-0.5">近衛局</span>
          </div>

          {/* Floating Embers */}
          <div className="absolute inset-0 z-0">
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="absolute w-[3px] h-[3px] bg-[var(--theme-color,#ff6a00)] rounded-full animate-pulse opacity-45"
                style={{
                  bottom: `${8 + (i * 11) % 85}%`,
                  left: `${12 + (i * 19) % 78}%`,
                  animationDuration: `${2.5 + i * 0.6}s`,
                  filter: 'blur(0.5px)',
                  boxShadow: `0 0 6px var(--theme-color,#ff6a00)`,
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* CLASSIC Skin Ambient Atmosphere Layer */}
      {currentSkinId === 'CLASSIC' && (
        <div id="classic-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          <div className="absolute inset-5 border border-[#00e0b3]/5 rounded-sm pointer-events-none hidden md:block">
            {/* Double brackets corners */}
            <div className="absolute top-0 left-0 w-6 h-6 border-t border-l border-[#00e0b3]/30" />
            <div className="absolute top-0 right-0 w-6 h-6 border-t border-r border-[#00e0b3]/30" />
            <div className="absolute bottom-0 left-0 w-6 h-6 border-b border-l border-[#00e0b3]/30" />
            <div className="absolute bottom-0 right-0 w-6 h-6 border-b border-r border-[#00e0b3]/30" />
            <span className="absolute top-1 left-2.5 font-mono text-[7px] text-[#00e0b3]/25 tracking-widest">PRTS CONTEXT GATEWAYS v12.0 // NODE_STABLE_ONLINE</span>
            <span className="absolute bottom-1 right-2.5 font-mono text-[7px] text-[#00e0b3]/25 tracking-widest">RHODES ISLAND TACTICAL COMMAND MAIN LINK</span>
          </div>
          <div className="absolute top-24 left-6 text-[8px] font-mono tracking-wider text-[#00e0b3]/15 uppercase hidden lg:block bg-black/10 p-2.5 border border-[#00e0b3]/5 rounded">
            <span className="text-[#00e0b3] font-bold block mb-0.5">PRTS_SUBNET // 羅德島通訊</span>
            <span>SECTOR: RI_ENGINEERING_DEEP_LEVEL</span>
            <span>STATUS: TELEMETRY_ACTIVE</span>
          </div>
          {/* Subtle side graticule rule markers */}
          <div className="absolute left-4 top-1/2 -translate-y-1/2 w-1.5 h-32 border-l border-[#00e0b3]/15 opacity-60 flex flex-col justify-between py-1 hidden xl:flex">
            <div className="w-1.5 h-[1px] bg-[#00e0b3]/40" />
            <div className="w-1 h-[1px] bg-[#00e0b3]/20" />
            <div className="w-1.5 h-[1px] bg-[#00e0b3]/40" />
            <div className="w-1 h-[1px] bg-[#00e0b3]/20" />
            <div className="w-1.5 h-[1px] bg-[#00e0b3]/40" />
          </div>
        </div>
      )}

      {/* AMBER Skin Ambient Atmosphere Layer */}
      {currentSkinId === 'AMBER' && (
        <div id="amber-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          <div className="absolute inset-5 border border-[#ffb870]/10 rounded-sm pointer-events-none hidden md:block">
            <div className="absolute top-0 left-0 w-7 h-7 border-t border-l border-[#ffb870]/40" />
            <div className="absolute top-0 right-0 w-7 h-7 border-t border-r border-[#ffb870]/40" />
            <span className="absolute top-1 left-3 font-mono text-[8px] text-[#ffb870]/30 tracking-widest">RI_AMBER_TACTICAL_TELEMETRY // RESISTANCE WAVE: 585nm</span>
            <span className="absolute bottom-1 right-3 font-mono text-[8px] text-[#ffb870]/30 tracking-widest">DIAGNOSTIC ENGINE CONNECTED</span>
          </div>
          <div className="absolute top-24 left-6 text-[8px] font-mono tracking-wider text-[#ffb870]/20 uppercase hidden lg:block bg-black/20 p-2.5 border border-[#ffb870]/10 rounded">
            <span className="text-[#ffb870] font-bold block mb-0.5">WARM EMBERS TERMINAL // 羅德暖陽</span>
            <span>DECODER_WAVELENGTH: SUN_AMBER</span>
            <span>OPERATIONAL TEMPERATURE: NORMAL</span>
          </div>
        </div>
      )}

      {/* CRIMSON Skin Ambient Atmosphere Layer */}
      {currentSkinId === 'CRIMSON' && (
        <div id="crimson-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          <div className="absolute inset-5 border border-[#ff4b4b]/10 rounded-sm pointer-events-none hidden md:block">
            <div className="absolute top-0 top-0 left-0 w-8 h-8">
              <div className="absolute top-0 left-0 w-4 h-[1.5px] bg-[#ff4b4b]/40" />
              <div className="absolute top-0 left-0 w-[1.5px] h-4 bg-[#ff4b4b]/40" />
              <circle cx="2" cy="2" r="1.5" fill="#ff4b4b" />
            </div>
            <div className="absolute top-0 top-0 right-0 w-8 h-8">
              <div className="absolute top-0 right-0 w-4 h-[1.5px] bg-[#ff4b4b]/40" />
              <div className="absolute top-0 right-0 w-[1.5px] h-4 bg-[#ff4b4b]/40" />
              <circle cx="30" cy="2" r="1.5" fill="#ff4b4b" />
            </div>
            <span className="absolute top-1.5 left-4 font-mono text-[7px] text-[#ff4b4b]/45 tracking-widest animate-pulse">ALERT STAT: SYRACUSE TACTICAL OUTPOST DETECTOR ACTIVE</span>
          </div>
          <div className="absolute top-24 left-6 text-[8px] font-mono tracking-wider text-[#ff4b4b]/30 uppercase hidden lg:block bg-black/35 p-3 border border-[#ff4b4b]/20 rounded">
            <span className="text-[#ff4b4b] font-black block border-b border-[#ff4b4b]/20 pb-0.5 mb-1 animate-pulse">▲ RISK LEVEL: CRITICAL</span>
            <span>COGNITIVE CORE INTENSITY: MAXIMUM</span>
            <span>SECTOR: SYRACUSE RE_SEC_08</span>
          </div>
          {/* Side targets flashing overlay */}
          <div className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-16 border-y border-r border-[#ff4b4b]/20 flex flex-col items-center justify-around py-1 hidden xl:flex text-[8px] text-[#ff4b4b]/30 font-mono">
            <span>S1</span>
            <div className="w-1.5 h-1.5 rounded-full bg-[#ff4b4b]/40 animate-ping" />
            <span>OK</span>
          </div>
        </div>
      )}

      {/* GOLD Skin Ambient Atmosphere Layer */}
      {currentSkinId === 'GOLD' && (
        <div id="gold-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          <div className="absolute inset-5 border border-[#ffd700]/10 rounded-sm pointer-events-none hidden md:block">
            {/* Elegant gilded crowns or brackets */}
            <div className="absolute top-0 left-0 w-9 h-9 border-t-2 border-l-2 border-[#ffd700]/40 rounded-tl" />
            <div className="absolute top-0 right-0 w-9 h-9 border-t-2 border-r-2 border-[#ffd700]/40 rounded-tr" />
            <div className="absolute bottom-0 left-0 w-9 h-9 border-b-2 border-l-2 border-[#ffd700]/40 rounded-bl" />
            <div className="absolute bottom-0 right-0 w-9 h-9 border-b-2 border-r-2 border-[#ffd700]/40 rounded-br" />
            <span className="absolute top-1 left-4 font-mono text-[8px] text-[#ffd700]/40 tracking-wider font-extrabold">VICTORIAL DIGITIZED COMMAND FRAMEWAY v7.1</span>
            <span className="absolute bottom-1 right-4 font-mono text-[8px] text-[#ffd700]/40 tracking-wider">SECURE LINK: ROYAL AUTHENTICATORS</span>
          </div>
          {/* Victorian crest design top right */}
          <div className="absolute top-24 right-8 w-16 h-16 opacity-10 text-[#ffd700] border-2 border-[#ffd700] flex flex-col justify-center items-center font-bold font-mono tracking-tighter rounded-sm hidden lg:flex select-none transform rotate-3">
            <span className="text-lg leading-none font-black">ROYAL</span>
            <span className="text-[7px] leading-none uppercase tracking-widest font-black border-t border-current mt-1 pt-0.5">VICTORIA</span>
          </div>
          <div className="absolute top-28 left-6 text-[8px] font-mono tracking-wider text-[#ffd700]/30 uppercase hidden lg:block bg-[#1a1202]/50 p-2.5 border border-[#ffd700]/20 rounded">
            <span className="text-[#ffd700] font-bold block mb-0.5">ELITE ARCHIVE STATUS</span>
            <span>SEC_SYSTEM: ROYAL_REGULATORS</span>
            <span>CLEARANCE: GOLDEN EXECUTIVE</span>
          </div>
        </div>
      )}

      {/* PURPLE Skin Ambient Atmosphere Layer */}
      {currentSkinId === 'PURPLE' && (
        <div id="purple-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          <div className="absolute inset-5 border border-[#cc55ff]/10 rounded-sm pointer-events-none hidden md:block">
            <div className="absolute top-1/2 left-2 w-32 h-32 rounded-full border border-[#cc55ff]/5 opacity-40 -translate-y-1/2 -ml-16 pointer-events-none" />
            <div className="absolute top-1/2 right-2 w-32 h-32 rounded-full border border-[#cc55ff]/5 opacity-40 -translate-y-1/2 -mr-16 pointer-events-none" />
            <span className="absolute top-1 left-3 font-mono text-[8px] text-[#cc55ff]/40 tracking-widest font-black">LATERANO RESERVED SPECTRUM CHANNEL // HALO RESONANT WAVE</span>
            <span className="absolute bottom-1 right-3 font-mono text-[8px] text-[#cc55ff]/40 tracking-widest">COGNITIVE STATUS: UNCONDITIONAL</span>
          </div>
          <div className="absolute top-26 left-6 text-[8px] font-mono tracking-wider text-[#cc55ff]/30 uppercase hidden lg:block bg-black/20 p-2.5 border border-[#cc55ff]/10 rounded">
            <span className="text-[#cc55ff] font-bold block mb-0.5">LATERANO RESONANCE // 聖潔霓虹</span>
            <span>SECTOR: SANCTUARIES_04</span>
            <span>COGNITIVE: SECURE SYNCED</span>
          </div>
        </div>
      )}

      {/* SKIN_AMIYA_CHIMERA (阿米婭 · 奇美拉晶藍UI - Epic #00ccff) */}
      {currentSkinId === 'SKIN_AMIYA_CHIMERA' && (
        <div id="chimera-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          {/* Cyan double outer boundary grid with futuristic corner pieces */}
          <div className="absolute inset-5 border border-[#00ccff]/12 rounded-sm pointer-events-none hidden md:block">
            <div className="absolute top-0 left-0 w-10 h-10 border-t-2 border-l-2 border-[#00ccff]/50 rounded-tl-sm" />
            <div className="absolute top-0 right-0 w-10 h-10 border-t-2 border-r-2 border-[#00ccff]/50 rounded-tr-sm" />
            <div className="absolute bottom-0 left-0 w-10 h-10 border-b-2 border-l-2 border-[#00ccff]/50 rounded-bl-sm" />
            <div className="absolute bottom-0 right-0 w-10 h-10 border-b-2 border-r-2 border-[#00ccff]/50 rounded-br-sm" />
            
            {/* Fine print tracking lines */}
            <span className="absolute top-1.5 left-3 font-mono text-[8px] text-[#00ccff]/40 tracking-widest leading-none font-bold">
              PRTS_CHIMERA_SYS_NET v8.35 // SYST: OVERFLOW_SHIELD_DEACTIVATING
            </span>
            <span className="absolute bottom-1.5 right-3 font-mono text-[8px] text-[#00ccff]/40 tracking-widest leading-none font-bold">
              SECURITY CONSTRAINT STATUS: UNLOCKED // TARGET: DOCTOR
            </span>
          </div>

          {/* Left panel diagnostics representing the constraint ring of Amiya (spinning circles and pulse ripples) */}
          <div className="absolute top-1/4 left-8 w-48 h-48 opacity-[0.14] text-[#00ccff] hidden xl:block transition-all pointer-events-none">
            <svg viewBox="0 0 200 200" fill="none" stroke="currentColor" strokeWidth="1" className="w-full h-full">
              {/* Core central ring */}
              <circle cx="100" cy="100" r="30" strokeDasharray="3 3" className="animate-spin-slow" />
              <circle cx="100" cy="100" r="45" strokeWidth="1.5" />
              {/* Outer orbit rings with tags */}
              <circle cx="100" cy="100" r="60" strokeDasharray="10 5" className="animate-spin-slow" style={{ animationDuration: '10s' }} />
              <circle cx="100" cy="100" r="75" strokeWidth="0.8" />
              {/* Ring tick lines */}
              <path d="M100 10 L100 25 M100 175 L100 190 M10 100 L25 100 M175 100 L190 100" />
              <path d="M40 40 L55 55 M145 145 L160 160 M40 160 L55 145 M145 40 L160 55" strokeWidth="0.5" />
            </svg>
            <div className="text-[8px] font-mono tracking-widest text-[#00ccff]/40 text-left uppercase mt-2 pl-4">
              AMIYA_RING_CONSTRAINT_GRAPH // 奇美拉環形能級阻尼
            </div>
          </div>

          {/* Right panel crystal structure visual representing originium growth */}
          <div className="absolute bottom-24 right-8 w-56 h-40 opacity-[0.10] text-[#00ccff] hidden lg:block pointer-events-none">
            <svg viewBox="0 0 200 150" fill="none" stroke="currentColor" strokeWidth="1" className="w-full h-full">
              {/* Isometric Crystal cluster chains */}
              <polygon points="40,110 55,40 70,110 55,120" />
              <polygon points="70,110 80,60 90,110 80,115" />
              <polygon points="20,110 30,75 40,110 30,115" strokeDasharray="1 1" />
              <polygon points="85,110 105,25 125,110 105,120" strokeWidth="1.5" />
              <polygon points="120,110 135,50 150,110 135,115" />
              <polygon points="145,110 160,70 175,110 160,115" strokeDasharray="2 1" />
              {/* Horizontal substrate grid */}
              <line x1="10" y1="110" x2="190" y2="110" strokeWidth="2" strokeDasharray="8 4" />
              <line x1="10" y1="118" x2="190" y2="118" strokeWidth="0.5" />
            </svg>
            <div className="text-[7px] font-mono tracking-widest text-[#00ccff]/30 text-right uppercase mt-1">
              BLACK_CRYSTAL_COGNITIVE_ARRAY // 源石生長結晶模擬
            </div>
          </div>

          {/* Symmetrical digital grids */}
          <div className="absolute top-28 left-6 text-[8px] font-mono tracking-wider text-[#00ccff]/30 uppercase hidden lg:block bg-[#001c24]/60 p-3 border border-[#00ccff]/25 rounded-md shadow-lg backdrop-blur-md">
            <span className="text-[#00ccff] font-extrabold block border-b border-[#00ccff]/30 pb-0.5 mb-1.5 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00ccff] animate-ping" />
              CHIMERA RESONATOR_ACTIVE
            </span>
            <span>BANDWIDTH: CRYSTALLIZED_DENSE</span>
            <span>AMPLIFIER CLEARANCE LEVEL: S5</span>
            <span>DEC_COGNITION: COMPLETE</span>
          </div>

          {/* Floating crystal sparks */}
          <div className="absolute inset-0">
            {[...Array(14)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 bg-[#00ccff] opacity-40 animate-pulse"
                style={{
                  top: `${15 + (i * 13) % 70}%`,
                  left: `${10 + (i * 23) % 80}%`,
                  transform: 'rotate(45deg)',
                  animationDuration: `${2.0 + i * 0.4}s`,
                  boxShadow: '0 0 6px #00ccff',
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* SKIN_CHEN_DRAGON (陳 · 龍炎赤霄重載UI - Epic #ff2255) */}
      {currentSkinId === 'SKIN_CHEN_DRAGON' && (
        <div id="chen-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          <div className="absolute inset-5 border border-[#ff2255]/12 rounded-sm pointer-events-none hidden md:block">
            {/* Highly detailed sharp military corners */}
            <div className="absolute top-0 left-0 w-8 h-8">
              <div className="absolute top-0 left-0 w-8 h-1 bg-[#ff2255]/70" />
              <div className="absolute top-0 left-0 w-1 h-8 bg-[#ff2255]/70" />
              <div className="absolute top-2 left-2 w-2 h-[1px] bg-[#ff2255]" />
              <div className="absolute top-2 left-2 w-[1px] h-2 bg-[#ff2255]" />
            </div>
            <div className="absolute top-0 right-0 w-8 h-8">
              <div className="absolute top-0 right-0 w-8 h-1 bg-[#ff2255]/70" />
              <div className="absolute top-0 right-0 w-1 h-8 bg-[#ff2255]/70" />
              <div className="absolute top-2 right-2 w-2 h-[1px] bg-[#ff2255]" />
              <div className="absolute top-2 right-2 w-[1px] h-2 bg-[#ff2255]" />
            </div>
            <div className="absolute bottom-0 left-0 w-8 h-8">
              <div className="absolute bottom-0 left-0 w-8 h-1 bg-[#ff2255]/70" />
              <div className="absolute bottom-0 left-0 w-1 h-8 bg-[#ff2255]/70" />
              <div className="absolute bottom-2 left-2 w-2 h-[1px] bg-[#ff2255]" />
              <div className="absolute bottom-2 left-2 w-[1px] h-2 bg-[#ff2255]" />
            </div>
            <div className="absolute bottom-0 right-0 w-8 h-8">
              <div className="absolute bottom-0 right-0 w-8 h-1 bg-[#ff2255]/70" />
              <div className="absolute bottom-0 right-0 w-1 h-8 bg-[#ff2255]/70" />
              <div className="absolute bottom-2 right-2 w-2 h-[1px] bg-[#ff2255]" />
              <div className="absolute bottom-2 right-2 w-[1px] h-2 bg-[#ff2255]" />
            </div>

            <span className="absolute top-1.5 left-4 font-mono text-[8px] text-[#ff2255]/40 tracking-widest font-black uppercase">
              L.G.D. CH\'EN EXECUTIVE SUPERVISION SYSTEM_v9.2
            </span>
            <span className="absolute bottom-1.5 right-4 font-mono text-[8px] text-[#ff2255]/40 tracking-widest leading-none font-bold">
              WEAPON ENGAGEMENT SYSTEM: CHIXIAO READY.
            </span>
          </div>

          {/* Left panel representing Chi Xiao Saber slash shockwaves */}
          <div className="absolute top-1/3 left-6 w-64 h-32 opacity-[0.12] text-[#ff2255] hidden xl:block pointer-events-none">
            <svg viewBox="0 0 300 150" fill="none" stroke="currentColor" strokeWidth="1" className="w-full h-full">
              {/* Fast energetic slash trajectories with angle of -15 degrees */}
              <line x1="10" y1="120" x2="280" y2="30" strokeWidth="2.5" />
              <line x1="30" y1="125" x2="250" y2="45" strokeWidth="0.8" strokeDasharray="6 3" />
              {/* Glowing slash rings representing sword discharge expansion */}
              <path d="M 50 100 A 60 60 0 0 1 200 60" strokeWidth="1" strokeDasharray="3 3" />
              <path d="M 80 110 A 50 50 0 0 1 220 70" strokeWidth="1.5" />
              {/* Target graticules */}
              <circle cx="150" cy="75" r="14" strokeWidth="1" />
              <line x1="150" y1="55" x2="150" y2="95" strokeDasharray="2 2" />
              <line x1="130" y1="75" x2="170" y2="75" strokeDasharray="2 2" />
            </svg>
            <div className="text-[7px] font-mono tracking-widest text-[#ff2255]/55 text-left uppercase mt-1 pl-6">
              CHIXIAO_SABER_DISCHARGE // 赤霄刀意氣勁波段
            </div>
          </div>

          {/* Right panel warning tactical screen */}
          <div className="absolute bottom-28 right-8 text-[8px] font-mono tracking-wider text-[#ff2255]/30 uppercase hidden lg:block bg-[#240008]/70 p-4 border border-[#ff2255]/30 rounded-md shadow-[0_0_20px_rgba(255,34,85,0.1)]">
            <div className="text-[#ff2255] font-black border-b border-[#ff2255]/30 pb-1 mb-1.5 flex items-center justify-between">
              <span>▲ WARNING SYSTEM</span>
              <span className="animate-pulse bg-[#ff2255] text-black px-1 leading-none font-sans font-black mini text-[7px] rounded-sm">CRITICAL</span>
            </div>
            <span>TARGET ACQUISITION: LOCKED</span>
            <div className="h-1 bg-[#ff2255]/10 rounded-full overflow-hidden mt-1.5">
              <div className="h-full bg-[#ff2255] w-4/5 animate-pulse" />
            </div>
            <span className="block mt-1">L.G.D._OFFICER_CH\'EN // CHATTING ENCRYPTED_ON</span>
          </div>

          {/* Slashed target watermarks */}
          <div className="absolute -bottom-8 -left-8 w-64 h-64 text-[#ff2255] opacity-5 transform -rotate-12">
            <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="50" cy="50" r="40" />
              <polygon points="50,10 90,50 50,90 10,50" strokeDasharray="4 2" />
              <line x1="10" y1="90" x2="90" y2="10" strokeWidth="3" />
            </svg>
          </div>

          {/* Fast red high-speed sparks */}
          <div className="absolute inset-0">
            {[...Array(15)].map((_, i) => (
              <div
                key={i}
                className="absolute w-[4px] h-[1.5px] bg-[#ff2255] opacity-50"
                style={{
                  top: `${10 + (i * 123) % 80}%`,
                  left: `${5 + (i * 87) % 90}%`,
                  transform: 'rotate(-15deg)',
                  boxShadow: '0 0 6px #ff2255',
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* SKIN_TEXAS_WOLF (德克薩斯 · 荒野雨夜UI - Legendary #ffaa00) */}
      {currentSkinId === 'SKIN_TEXAS_WOLF' && (
        <div id="texas-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          {/* Double yellow golden glowing tactical borders */}
          <div className="absolute inset-4 border border-[#ffaa00]/15 rounded-md pointer-events-none hidden md:block">
            <div className="absolute inset-[3px] border border-[#ffaa00]/5 rounded" />
            
            {/* Animated Caution Stripe corner ribbons */}
            <div className="absolute top-0 left-0 w-36 h-5 bg-gradient-to-r from-[#ffaa00]/25 via-[#ffaa00]/5 to-transparent flex items-center px-2 overflow-hidden">
              <div className="flex gap-1 animate-hazard-slide shrink-0 mr-2">
                {[...Array(12)].map((_, i) => (
                  <div key={i} className="w-1.5 h-4 bg-[#ffaa00]/50 -skew-x-12" />
                ))}
              </div>
              <span className="font-mono text-[8px] text-[#ffaa00] font-black tracking-widest uppercase shrink-0">P.L. FAST DELIV</span>
            </div>

            <div className="absolute bottom-0 right-0 w-44 h-5 bg-gradient-to-l from-[#ffaa00]/25 via-[#ffaa00]/5 to-transparent flex justify-end items-center px-2 overflow-hidden">
              <span className="font-mono text-[8px] text-[#ffaa00] font-black tracking-widest uppercase mr-2">[ COURIER STATUS: MAX_DRIVE ]</span>
              <div className="flex gap-1 animate-hazard-slide shrink-0">
                {[...Array(12)].map((_, i) => (
                  <div key={i} className="w-1.5 h-4 bg-[#ffaa00]/50 -skew-x-12" />
                ))}
              </div>
            </div>

            {/* Top right / Bottom left fine telemetry lines */}
            <span className="absolute top-1.5 right-4 font-mono text-[8px] text-[#ffaa00]/55 tracking-widest font-black uppercase flex items-center gap-1.5">
              <span className="w-1 h-1 rounded-full bg-[#ffaa00] animate-ping" />
              PENGUIN LOGISTICS HUD // SECURE TERMINAL LINK CODES v15.82
            </span>
            <span className="absolute bottom-1.5 left-4 font-mono text-[8px] text-[#ffaa00]/55 tracking-widest uppercase">
              COGNITIVE FREQUENCY: EQUALIZED // SIGNAL ACCURACY: 99.89% // NO_PACKET_LOSS
            </span>
          </div>

          {/* Left panel representing Syracuse/Wilderness shipping dashboard navigation coordinate plot */}
          <div className="absolute top-[22%] left-8 w-72 h-56 opacity-25 text-[#ffaa00] hidden xl:block bg-[#1f1500]/65 border border-[#ffaa00]/20 p-4 rounded shadow-[0_0_25px_rgba(255,170,0,0.05)] backdrop-blur-md">
            <div className="border-b border-[#ffaa00]/20 pb-1.5 mb-2 flex items-center justify-between font-mono text-[9px] font-black">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-[#ffaa00] rounded-full animate-pulse" />
                LUPUS ROUTE ENGINE
              </span>
              <span className="text-[#ffaa00]/60 text-[8px]">ACTIVE_MONITOR</span>
            </div>
            
            <svg viewBox="0 0 240 120" fill="none" stroke="currentColor" strokeWidth="1" className="w-full h-28">
              {/* Plotting coordinate grid */}
              <line x1="10" y1="10" x2="230" y2="10" strokeDasharray="3 3" opacity="0.3" />
              <line x1="10" y1="60" x2="230" y2="60" strokeDasharray="1 1" opacity="0.5" />
              <line x1="10" y1="110" x2="230" y2="110" strokeDasharray="3 3" opacity="0.3" />
              <line x1="60" y1="10" x2="60" y2="110" strokeDasharray="3 3" opacity="0.3" />
              <line x1="120" y1="10" x2="120" y2="110" strokeDasharray="1 1" opacity="0.5" />
              <line x1="180" y1="10" x2="180" y2="110" strokeDasharray="3 3" opacity="0.3" />
              
              {/* Courier route path animation trace */}
              <path d="M 20 95 L 75 45 L 130 85 L 185 30 L 225 65" strokeWidth="2" strokeDasharray="300" strokeDashoffset="300" className="animate-path-draw" />
              
              {/* Active pointer coordinates marker */}
              <g className="animate-marker-pulse">
                <circle cx="185" cy="30" r="4.5" fill="#ffaa00" />
                <circle cx="185" cy="30" r="10" stroke="#ffaa00" strokeWidth="1" className="animate-ping" />
              </g>

              {/* Auxiliary telemetry trace representation */}
              <path d="M 20 60 Q 60 20 120 70 T 220 50" strokeWidth="0.8" strokeDasharray="5 5" opacity="0.7" />
            </svg>

            {/* Dynamic metrics with flashing keyframe numbers */}
            <div className="grid grid-cols-2 gap-1.5 mt-2 pt-2 border-t border-[#ffaa00]/15 font-mono text-[8px]">
              <div>
                <span className="text-[#ffaa00]/50 block">VELOCITY RATE:</span>
                <span className="font-extrabold text-[#ffaa00] block animate-pulse">142.6 KM/H</span>
              </div>
              <div>
                <span className="text-[#ffaa00]/50 block">CARGO FREI_ID:</span>
                <span className="font-extrabold text-[#ffaa00] block">PL_TX_#99042</span>
              </div>
              <div className="col-span-2 text-[7.5px] text-[#ffaa00]/40 flex items-center justify-between border-t border-dashed border-[#ffaa00]/10 pt-1 mt-0.5">
                <span>COORD: 39°54\'N,116°23\'E</span>
                <span className="animate-pulse">ONLINE [SECURED]</span>
              </div>
            </div>
          </div>

          {/* Right panel: Giant holographic Texas double swords & Wolf insignia with concentric rotate locator */}
          <div className="absolute bottom-20 right-10 w-80 h-80 opacity-20 text-[#ffaa00] hidden lg:block pointer-events-none">
            {/* Center targeting locator loop */}
            <div className="absolute inset-0 flex items-center justify-center">
              <svg viewBox="0 0 240 240" fill="none" stroke="currentColor" className="w-full h-full">
                {/* Clockwise rotating outer gear-ring */}
                <circle cx="120" cy="120" r="100" strokeWidth="1.2" strokeDasharray="20 10" className="animate-spin" style={{ animationDuration: '60s' }} />
                {/* Counter-clockwise rotating inner ticks */}
                <circle cx="120" cy="120" r="85" strokeWidth="1" strokeDasharray="3 6" className="animate-reverse-spin" style={{ animationDuration: '40s' }} />
                {/* Solid core boundaries */}
                <circle cx="120" cy="120" r="70" strokeWidth="0.7" strokeDasharray="40 5" />
                <path d="M120 10 L120 40 M120 200 L120 230 M10 120 L40 120 M200 120 L230 120" strokeWidth="1.5" />
              </svg>
            </div>

            {/* The sharp Wolf polygon insignia overlapping in the exact center */}
            <div className="absolute inset-0 flex items-center justify-center p-14 animate-pulse" style={{ animationDuration: '5s' }}>
              <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
                {/* Precision Wolf contour layout */}
                <path d="M 50 5 L 85 30 L 72 62 L 50 95 L 28 62 L 15 30 Z" className="drop-shadow-[0_0_15px_rgba(255,170,0,0.4)]" />
                <path d="M 50 5 L 50 95" strokeDasharray="2 4" strokeWidth="1" />
                <polygon points="43,42 28,47 37,52" fill="currentColor" opacity="0.8" />
                <polygon points="57,42 72,47 63,52" fill="currentColor" opacity="0.8" />
                <path d="M 28 20 L 50 35 L 72 20" strokeWidth="1.2" />
                <line x1="33" y1="62" x2="67" y2="62" strokeWidth="0.8" strokeDasharray="1 1" />
              </svg>
            </div>
          </div>

          {/* Symmetrical digital coordinates background watermark */}
          <div className="absolute top-26 right-8 text-[8px] font-mono tracking-wider text-[#ffaa00]/30 uppercase hidden lg:block bg-[#241300]/60 p-3 border border-[#ffaa00]/20 rounded-md backdrop-blur-md">
            <span className="text-[#ffaa00] font-extrabold block border-b border-[#ffaa00]/20 pb-0.5 mb-1.5">
              ▲ TEXAS WOLF TRANSMISSION
            </span>
            <span>WILD_RAINCOAT_SPECTRA: S3</span>
            <span>SHADOW RESOLVER_ACTIVE: 76.4%</span>
            <span>THIN_BLADE_COHERENCY: PERFECT</span>
          </div>

          {/* Golden wet rain drop simulation and splash ripples */}
          <div className="absolute inset-0 z-0">
            {[...Array(20)].map((_, i) => (
              <div key={i} className="absolute pointer-events-none">
                {/* Simulated high-speed slanted golden raindrop */}
                <div
                  className="w-[1.5px] h-9 bg-gradient-to-b from-[#ffaa00]/55 to-transparent"
                  style={{
                    position: 'absolute',
                    top: '-50px',
                    left: `${5 + (i * 19)%90}%`,
                    transform: 'rotate(12deg)',
                    animation: `texasRainFall ${1.0 + (i % 4) * 0.25}s linear infinite`,
                    animationDelay: `${i * 0.12}s`,
                    opacity: 0.7
                  }}
                />
                
                {/* Splash splash ripple simulation at the bottom boundary */}
                <div 
                  className="rounded-full border border-[#ffaa00]/30 animate-pulse"
                  style={{
                    position: 'absolute',
                    bottom: `${10 + (i * 123) % 25}%`,
                    left: `${5 + (i * 19)%90}%`,
                    width: '12px',
                    height: '4px',
                    transform: 'scale(0)',
                    animation: `texasRainSplash ${1.0 + (i % 4) * 0.25}s linear infinite`,
                    animationDelay: `${i * 0.12}s`,
                    opacity: 0.15
                  }}
                />
              </div>
            ))}
          </div>

          <style>{`
            @keyframes texasRainFall {
              0% { transform: translateY(-50px) translateX(-10px) rotate(12deg); opacity: 0; }
              10% { opacity: 0.7; }
              90% { opacity: 0.7; }
              100% { transform: translateY(110vh) translateX(220px) rotate(12deg); opacity: 0; }
            }
            @keyframes texasRainSplash {
              0% { transform: scale(0); opacity: 0; }
              85% { transform: scale(0); opacity: 0; }
              90% { transform: scale(0.6); opacity: 0.6; }
              98% { transform: scale(1.8); opacity: 0; }
              100% { transform: scale(1.8); opacity: 0; }
            }
            .animate-hazard-slide {
              animation: hazardSlideLeft 12s linear infinite;
            }
            @keyframes hazardSlideLeft {
              0% { transform: translateX(0); }
              100% { transform: translateX(-40px); }
            }
            .animate-path-draw {
              stroke-dasharray: 600;
              stroke-dashoffset: 600;
              animation: drawCourierPath 8s cubic-bezier(0.4, 0, 0.2, 1) infinite;
            }
            @keyframes drawCourierPath {
              0% { stroke-dashoffset: 600; }
              60% { stroke-dashoffset: 0; }
              90% { stroke-dashoffset: 0; opacity: 1; }
              100% { stroke-dashoffset: 0; opacity: 0; }
            }
            .animate-marker-pulse {
              animation: markerPulse 8s ease-in-out infinite;
            }
            @keyframes markerPulse {
              0%, 60% { opacity: 0; transform: scale(0.3); }
              61%, 90% { opacity: 1; transform: scale(1); }
              100% { opacity: 0; transform: scale(0.3); }
            }
            .animate-reverse-spin {
              animation: spinReverse 40s linear infinite;
            }
            @keyframes spinReverse {
              0% { transform: rotate(360deg); }
              100% { transform: rotate(0deg); }
            }
          `}</style>
        </div>
      )}

      {/* SKIN_MOSTIMA_TIME (莫斯提馬 · 歲月晶弦UI - Legendary #6f00ff) */}
      {currentSkinId === 'SKIN_MOSTIMA_TIME' && (
        <div id="mostima-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          {/* Symmetrical fine temporal layout and corners */}
          <div className="absolute inset-5 border border-[#6f00ff]/15 rounded-sm pointer-events-none hidden md:block">
            <div className="absolute top-0 left-0 w-16 h-16 pointer-events-none">
              {/* Complex astronomical corner dial */}
              <svg viewBox="0 0 60 60" fill="none" stroke="currentColor" className="w-full h-full text-[#6f00ff]/65 animate-spin-slow">
                <circle cx="30" cy="30" r="26" strokeDasharray="3 2" strokeWidth="1" />
                <circle cx="30" cy="30" r="18" strokeWidth="0.8" />
                <circle cx="30" cy="30" r="10" strokeDasharray="1 4" strokeWidth="1.5" />
                <line x1="30" y1="4" x2="30" y2="56" />
                <line x1="4" y1="30" x2="56" y2="30" />
              </svg>
            </div>
            <div className="absolute top-0 right-0 w-16 h-16 pointer-events-none">
              <svg viewBox="0 0 60 60" fill="none" stroke="currentColor" className="w-full h-full text-[#6f00ff]/65 animate-spin-slow" style={{ animationDirection: 'reverse', animationDuration: '15s' }}>
                <circle cx="30" cy="30" r="26" strokeDasharray="4 2" strokeWidth="1" />
                <circle cx="30" cy="30" r="18" strokeWidth="0.8" />
                <circle cx="30" cy="30" r="12" strokeDasharray="2 2" />
                <line x1="30" y1="4" x2="30" y2="56" />
                <line x1="4" y1="30" x2="56" y2="30" />
              </svg>
            </div>

            <span className="absolute top-2 left-18 font-mono text-[8px] text-[#6f00ff]/65 tracking-[0.25em] font-extrabold uppercase animate-pulse">
              [ CHRONOS FLUX TERMINAL ] // CHRONO_LEVEL: SECURE_WAVE // OVERCLOCKING TEMPORAL COORDINATION v825.1
            </span>
            <span className="absolute bottom-2 right-4 font-mono text-[8px] text-[#6f00ff]/65 tracking-[0.15em] font-black uppercase">
              LATERANO BLACK_HOLE DIVISION // COORDINATES EQUATED / STATE: SYNCED
            </span>
          </div>

          {/* Left panel: Chronological horizontal wave tracker and timeline vectors */}
          <div className="absolute top-1/4 left-8 w-72 h-56 opacity-25 text-[#6f00ff] hidden xl:block bg-[#070014]/75 border border-[#6f00ff]/20 p-4 rounded shadow-[0_0_20px_rgba(111,0,255,0.1)] backdrop-blur-md">
            <div className="border-b border-[#6f00ff]/20 pb-1.5 mb-2 flex items-center justify-between font-mono text-[9px] font-bold">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#6f00ff] animate-ping" />
                TIME_RIFT STATS
              </span>
              <span>TEMPORAL_DRAG_OK</span>
            </div>

            <svg viewBox="0 0 240 100" fill="none" stroke="currentColor" strokeWidth="1" className="w-full h-24">
              {/* Symmetrical horizontal timeline paths */}
              <line x1="10" y1="50" x2="230" y2="50" strokeWidth="1.2" />
              <line x1="10" y1="20" x2="230" y2="20" strokeDasharray="4 4" opacity="0.4" />
              <line x1="10" y1="80" x2="230" y2="80" strokeDasharray="4 4" opacity="0.4" />
              
              {/* Expanding time waves representation (sine wave pulses) */}
              <path d="M 10 50 Q 30 15 50 50 T 90 50 T 130 50 T 170 50 T 210 50" strokeWidth="1.5" className="animate-time-pulse" />
              <path d="M 10 50 Q 25 80 40 50 T 70 50 T 100 50 T 130 50 T 160 50 T 190 50 T 220 50" strokeWidth="0.7" strokeDasharray="2 1" className="animate-time-pulse" style={{ animationDelay: '0.5s' }} />

              {/* Dial coordinates indicator */}
              <circle cx="120" cy="50" r="2.5" fill="#6f00ff" />
              <rect x="110" y="40" width="20" height="20" stroke="#6f00ff" strokeWidth="0.5" strokeDasharray="2 2" className="animate-spin" style={{ transformOrigin: '120px 50px', animationDuration: '8s' }} />
            </svg>

            <div className="grid grid-cols-2 gap-1 mt-1 font-mono text-[8px] text-[#6f00ff]/80">
              <div>
                <span className="text-[#6f00ff]/40 block text-[7.5px]">TEMPORAL SCALE:</span>
                <span className="font-extrabold block">T_RATIO: 1:-7200s</span>
              </div>
              <div>
                <span className="text-[#6f00ff]/40 block text-[7.5px]">RIFT INTEGRITY:</span>
                <span className="font-extrabold block text-green-400 animate-pulse">STABLE (99.98%)</span>
              </div>
            </div>
          </div>

          {/* Right panel: Giant holographic rotating Astronomical Astrolabe representing Mostima's ultimate time distortion */}
          <div className="absolute top-[20%] right-10 w-96 h-96 opacity-[0.22] text-[#6f00ff] hidden lg:block pointer-events-none">
            <svg viewBox="0 0 300 300" fill="none" stroke="currentColor" strokeWidth="1.2" className="w-full h-full">
              {/* Celestial grid layer */}
              <circle cx="150" cy="150" r="140" strokeDasharray="20 40" strokeWidth="0.8" className="animate-spin-slow" style={{ animationDuration: '90s' }} />
              
              {/* Outer Rune coordinate disc rotating clockwise */}
              <circle cx="150" cy="150" r="125" strokeDasharray="5 15" strokeWidth="1.5" className="animate-spin-slow" style={{ animationDuration: '45s' }} />
              
              {/* Inner chronological gears rotating counter-clockwise */}
              <circle cx="150" cy="150" r="105" strokeDasharray="24 6" strokeWidth="1" className="animate-reverse-spin" style={{ animationDuration: '24s' }} />
              <circle cx="150" cy="150" r="85" strokeWidth="1.5" />
              
              {/* Concentric planetary orbits and constellation nodes */}
              <g className="animate-spin-slow" style={{ animationDuration: '30s', transformOrigin: '150px 150px' }}>
                <circle cx="150" cy="90" r="4" fill="currentColor" />
                <line x1="150" y1="150" x2="150" y2="90" strokeDasharray="3 3" />
                <circle cx="110" cy="110" r="3" fill="currentColor" />
                <line x1="150" y1="150" x2="110" y2="110" strokeDasharray="3 3" />
                <path d="M 150 90 A 60 60 0 0 1 110 110" strokeWidth="0.5" strokeDasharray="1 1" />
              </g>

              {/* Central Chronos compass needles */}
              <line x1="150" y1="150" x2="150" y2="60" strokeWidth="3" className="animate-spin" style={{ transformOrigin: '150px 150px', animationDuration: '12s' }} />
              <line x1="150" y1="150" x2="220" y2="150" strokeWidth="1.5" className="animate-spin" style={{ transformOrigin: '150px 150px', animationDuration: '72s' }} />
              <circle cx="150" cy="150" r="8" fill="currentColor" />
              <circle cx="150" cy="150" r="14" stroke="currentColor" strokeWidth="1" className="animate-ping" style={{ animationDuration: '4s' }} />
            </svg>
          </div>

          {/* Symmetrical warning telemetry logs in Lateran timezone */}
          <div className="absolute bottom-28 right-8 text-[8px] font-mono tracking-wider text-[#6f00ff]/30 uppercase hidden lg:block bg-[#0e0024]/60 p-4 border border-[#6f00ff]/20 rounded-md backdrop-blur-md">
            <span className="text-[#6f00ff] font-extrabold block border-b border-[#6f00ff]/20 pb-0.5 mb-1.5">
              ▲ CHRONO QUANTUM RESONANCES
            </span>
            <span>CLOCK DRIFT: 0.000ms [CORRECTED]</span>
            <span>TEMPORAL INTEGRITY: 100% SECURE</span>
            <span>ACTIVE INDEX: LATERANO_FLUX_Z4</span>
          </div>

          {/* Floating astronomical stardust orbiting slowly in a 3D gravity spiral path */}
          <div className="absolute inset-0">
            {[...Array(24)].map((_, i) => (
              <div
                key={i}
                className="absolute w-[3.5px] h-[3.5px] rounded-full animate-pulse"
                style={{
                  top: `${15 + (i * 19) % 70}%`,
                  left: `${15 + (i * 29) % 70}%`,
                  backgroundColor: i % 2 === 0 ? '#6f00ff' : '#00ccff',
                  boxShadow: `0 0 12px ${i % 2 === 0 ? '#6f00ff' : '#00ccff'}, 0 0 24px ${i % 2 === 0 ? '#6f00ff' : '#00ccff'}`,
                  animation: `timeGravityVortex${i % 4} ${4.5 + (i % 5) * 1.5}s infinite linear`,
                  animationDelay: `${i * 0.25}s`,
                }}
              />
            ))}
          </div>

          <style>{`
            @keyframes timeGravityVortex0 {
              0% { transform: rotate(0deg) translate(0px, 0px) scale(0.6); opacity: 0; }
              15% { opacity: 0.8; }
              50% { transform: rotate(180deg) translate(-30px, -20px) scale(1.1); opacity: 0.6; }
              85% { opacity: 0.8; }
              100% { transform: rotate(360deg) translate(0px, 0px) scale(0.6); opacity: 0; }
            }
            @keyframes timeGravityVortex1 {
              0% { transform: rotate(0deg) translate(0px, 0px) scale(0.6); opacity: 0; }
              15% { opacity: 0.8; }
              50% { transform: rotate(180deg) translate(15px, -10px) scale(1.1); opacity: 0.6; }
              85% { opacity: 0.8; }
              100% { transform: rotate(360deg) translate(0px, 0px) scale(0.6); opacity: 0; }
            }
            @keyframes timeGravityVortex2 {
              0% { transform: rotate(0deg) translate(0px, 0px) scale(0.6); opacity: 0; }
              15% { opacity: 0.8; }
              50% { transform: rotate(180deg) translate(-15px, 10px) scale(1.1); opacity: 0.6; }
              85% { opacity: 0.8; }
              100% { transform: rotate(360deg) translate(0px, 0px) scale(0.6); opacity: 0; }
            }
            @keyframes timeGravityVortex3 {
              0% { transform: rotate(0deg) translate(0px, 0px) scale(0.6); opacity: 0; }
              15% { opacity: 0.8; }
              50% { transform: rotate(180deg) translate(30px, 20px) scale(1.1); opacity: 0.6; }
              85% { opacity: 0.8; }
              100% { transform: rotate(360deg) translate(0px, 0px) scale(0.6); opacity: 0; }
            }
            .animate-time-pulse {
              animation: timelineSine 5s ease-in-out infinite;
            }
            @keyframes timelineSine {
              0%, 100% { transform: scaleY(1); opacity: 0.5; }
              50% { transform: scaleY(1.4); opacity: 0.8; }
            }
          `}</style>
        </div>
      )}

      {/* SKIN_W_EMBER (W · 烈焰啟示錄動態系統UI - Limited #ff3000) */}
      {currentSkinId === 'SKIN_W_EMBER' && (
        <div id="w-ember-ambient-layer" className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
          {/* Symmetrical active brutality hazard continuous scrolling alert frames */}
          <div className="absolute top-4 left-4 right-4 h-1 px-1 flex gap-1 pointer-events-none overflow-hidden hidden md:flex">
            <div className="w-full h-full bg-gradient-to-r from-[#ff3000]/40 via-[#ff3000]/10 to-[#ff3000]/40 flex gap-2 animate-alert-move">
              {[...Array(80)].map((_, i) => (
                <div key={i} className="w-4 h-full bg-[#ff3000] skew-x-12 shrink-0 opacity-45" />
              ))}
            </div>
          </div>
          <div className="absolute bottom-4 left-4 right-4 h-1 px-1 flex gap-1 pointer-events-none overflow-hidden hidden md:flex">
            <div className="w-full h-full bg-gradient-to-r from-[#ff3000]/40 via-[#ff3000]/10 to-[#ff3000]/40 flex gap-2 animate-alert-move" style={{ animationDirection: 'reverse' }}>
              {[...Array(80)].map((_, i) => (
                <div key={i} className="w-4 h-full bg-[#ff3000] skew-x-12 shrink-0 opacity-45" />
              ))}
            </div>
          </div>

          <div className="absolute inset-5 border border-[#ff3000]/25 rounded-md pointer-events-none hidden md:block">
            {/* Highly customized heavy tactical warning corners */}
            <div className="absolute top-0 left-0 w-16 h-16 flex flex-col justify-start">
              <span className="text-[14px] text-[#ff3000] font-black tracking-tighter leading-none animate-pulse">▲ ▲ ▲</span>
              <span className="text-[8px] text-[#ff3000] font-mono leading-none font-extrabold mt-1">SARKAZ_MERC_W</span>
            </div>
            <div className="absolute top-0 right-0 w-16 h-16 flex flex-col justify-start items-end">
              <span className="text-[14px] text-[#ff3000] font-black tracking-tighter leading-none animate-pulse">▲ ▲ ▲</span>
              <span className="text-[8px] text-[#ff3000] font-mono leading-none font-extrabold mt-1 text-right">LIVE_SYS_W_99</span>
            </div>
            <div className="absolute bottom-0 left-0 w-16 h-16 flex flex-col justify-end">
              <span className="text-[8px] text-[#ff3000] font-mono leading-none font-bold mb-1">DETONATE_TRG</span>
              <span className="text-[14px] text-[#ff3000] font-black tracking-tighter leading-none animate-pulse">▼ ▼ ▼</span>
            </div>
            <div className="absolute bottom-0 right-0 w-16 h-16 flex flex-col justify-end items-end">
              <span className="text-[8px] text-[#ff3000] font-mono leading-none font-bold mb-1 text-right">TER_ENGAGE_ON</span>
              <span className="text-[14px] text-[#ff3000] font-black tracking-tighter leading-none animate-pulse">▼ ▼ ▼</span>
            </div>

            <span className="absolute top-2 left-18 font-mono text-[9px] text-[#ff3000] tracking-[0.2em] font-black uppercase flex items-center gap-1.5 animate-pulse">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff3000] animate-ping" />
              SARKAZ HIGH-ALERT WARFARE HUB // SYSTEM ID: W_EMBER_APOCALYPSE // HAZARDOUS UNIT
            </span>
            <span className="absolute bottom-2 right-18 font-mono text-[9px] text-[#ff3000]/65 tracking-[0.1em] font-black uppercase">
              LIMIT CLEARANCE LEVEL: MAXIMUM COGNITIVE // FUSE STATUS: [ ARMED ] // PRESS TO LAUNCH
            </span>
          </div>

          {/* Left panel: Simulated dynamic explosive shockwave equalizer bars and core frequency */}
          <div className="absolute top-[22%] left-10 w-72 h-64 opacity-25 text-[#ff3000] hidden xl:block bg-[#1f0500]/80 border border-[#ff3000]/30 p-4 rounded shadow-[0_0_35px_rgba(255,48,0,0.15)] backdrop-blur-md">
            <div className="border-b border-[#ff3000]/40 pb-1.5 mb-3 flex items-center justify-between font-mono text-[9px] font-black">
              <span className="flex items-center gap-1 text-red-500">
                <span className="w-2 h-2 bg-red-600 rounded-full animate-ping" />
                THERMITE BLAST GRAPH
              </span>
              <span>TRG_RESONANCE_OK</span>
            </div>

            {/* Simulated Live Equalizer Spectrum representation */}
            <div className="flex items-end justify-between gap-1 w-full h-24 mb-2.5 px-1 border-b border-dashed border-[#ff3000]/20 pb-1">
              {[12, 45, 87, 34, 56, 95, 78, 62, 45, 91, 56, 32, 74, 98, 45, 23, 67].map((h, i) => (
                <div
                  key={i}
                  className="w-full bg-[#ff3000] rounded-sm"
                  style={{
                    height: `${h}%`,
                    animation: `emberEqualizer ${1.5 + (i % 4) * 0.3}s ease-in-out infinite alternate`,
                    animationDelay: `${i * 0.05}s`
                  }}
                />
              ))}
            </div>

            <div className="grid grid-cols-2 gap-1.5 font-mono text-[8px]">
              <div>
                <span className="text-[#ff3000]/40 block text-[7.5px]">CHARGE POWER:</span>
                <span className="font-extrabold text-red-500 animate-pulse block">100% MAXIMUM ARMED</span>
              </div>
              <div>
                <span className="text-[#ff3000]/40 block text-[7.5px]">BLAST FUSE RATE:</span>
                <span className="font-extrabold block">T-MINUS 1.4 SECS</span>
              </div>
            </div>
          </div>

          {/* Right panel: Tactical scanning radar telemetry system locking onto targets */}
          <div className="absolute bottom-[18%] right-10 w-80 h-80 opacity-30 text-[#ff3000] hidden lg:block pointer-events-none">
            <svg viewBox="0 0 300 300" fill="none" stroke="currentColor" strokeWidth="1.2" className="w-[110%] h-[110%]">
              {/* Radar circular scope sweep */}
              <circle cx="150" cy="150" r="130" strokeWidth="1" strokeDasharray="5 15" className="animate-spin-slow" style={{ animationDuration: '30s' }} />
              <circle cx="150" cy="150" r="105" strokeWidth="1.5" />
              <circle cx="150" cy="150" r="70" strokeWidth="0.8" strokeDasharray="20 5" />
              
              {/* Spinning alert radar sweeping needle */}
              <g className="animate-spin" style={{ transformOrigin: '150px 150px', animationDuration: '6s' }}>
                <line x1="150" y1="150" x2="150" y2="20" strokeWidth="2.5" />
                {/* Simulated radar echo gradient */}
                <path d="M 150 20 A 130 130 0 0 1 240 70 L 150 150 Z" fill="#ff3000" opacity="0.08" stroke="none" />
              </g>

              {/* Symmetrical target indicators locking brackets */}
              <g className="animate-pulse" style={{ animationDuration: '2s' }}>
                <path d="M 90 90 L 80 90 L 80 100 M 210 90 L 220 90 L 220 100 M 80 200 L 80 210 L 90 210 M 220 200 L 220 210 L 210 210" strokeWidth="2.5" />
                <text x="110" y="80" fill="#ff3000" fontSize="8" fontFamily="monospace" fontWeight="900" letterSpacing="2">[ TARGET_LOCK: ACTIVE ]</text>
                <circle cx="150" cy="150" r="12" strokeWidth="2" strokeDasharray="3 3" />
              </g>
            </svg>
          </div>

          {/* Symmetrical digital coordinates background watermark */}
          <div className="absolute top-26 right-8 text-[8px] font-mono tracking-wider text-[#ff3000]/30 uppercase hidden lg:block bg-[#240500]/60 p-4 border border-[#ff3000]/30 rounded-md backdrop-blur-md">
            <span className="text-[#ff3000] font-extrabold block border-b border-[#ff3000]/30 pb-1 mb-2">
              ☢ WARNING: SARKAZ MERC_SYS_W
            </span>
            <span className="text-[#ff3000] font-bold block mb-1">TRG_STATE: REPLICA_LAUNCH_ON</span>
            <span>BLAST DETONATOR: MAXIMUM CHARGED</span>
            <div className="mt-2 text-[7.5px] text-gray-400 font-bold border border-red-900 border-dashed p-1.5 leading-normal bg-black/40">
              - "Ready to make some beautiful fireworks for you, Doctor? Let\'s go!" 
              <span className="block text-[#ff3000] font-black mt-0.5 text-right">// LOL_APOC_READY</span>
            </div>
          </div>

          {/* Parallax layered continuous active burning flame ember particles drifting up */}
          <div className="absolute inset-0">
            {/* Layer 1: Front heavy embers (large, fast, blurred) */}
            {[...Array(12)].map((_, i) => (
              <div
                key={`front-${i}`}
                className="absolute rounded-full animate-bounce-slow"
                style={{
                  bottom: '-15px',
                  left: `${2 + (i * 27) % 96}%`,
                  width: '6px',
                  height: '6px',
                  backgroundColor: '#ff3000',
                  boxShadow: '0 0 12px #ff3000, 0 0 24px #ff7a00',
                  filter: 'blur(1px)',
                  animationName: 'emberDriftingUp',
                  animationDuration: `${2.2 + (i % 3) * 0.6}s`,
                  animationIterationCount: 'infinite',
                  animationTimingFunction: 'ease-out',
                  animationDelay: `${i * 0.15}s`,
                }}
              />
            ))}

            {/* Layer 2: Mid-range standard embers */}
            {[...Array(16)].map((_, i) => (
              <div
                key={`mid-${i}`}
                className="absolute rounded-full animate-bounce-slow"
                style={{
                  bottom: '-10px',
                  left: `${5 + (i * 17) % 90}%`,
                  width: '3.5px',
                  height: '3.5px',
                  backgroundColor: '#ff5a00',
                  boxShadow: '0 0 8px #ff5a00, 0 0 16px #ffbe00',
                  animationName: 'emberDriftingUp',
                  animationDuration: `${3.2 + (i % 4) * 0.8}s`,
                  animationIterationCount: 'infinite',
                  animationTimingFunction: 'ease-out',
                  animationDelay: `${i * 0.22}s`,
                }}
              />
            ))}

            {/* Layer 3: Background fine dust embers */}
            {[...Array(16)].map((_, i) => (
              <div
                key={`back-${i}`}
                className="absolute rounded-full animate-bounce-slow"
                style={{
                  bottom: '-10px',
                  left: `${1 + (i * 23) % 98}%`,
                  width: '2px',
                  height: '2px',
                  backgroundColor: '#ffaa00',
                  boxShadow: '0 0 6px #ff7a00',
                  animationName: 'emberDriftingUp',
                  animationDuration: `${4.5 + (i % 3) * 1.2}s`,
                  animationIterationCount: 'infinite',
                  animationTimingFunction: 'ease-out',
                  animationDelay: `${i * 0.3}s`,
                }}
              />
            ))}
          </div>

          <style>{`
            @keyframes emberDriftingUp {
              0% { transform: translateY(0) scale(1) rotate(0deg); opacity: 0; }
              15% { opacity: 0.9; }
              85% { opacity: 0.7; }
              100% { transform: translateY(-800px) scale(0.5) rotate(270deg); opacity: 0; }
            }
            @keyframes emberEqualizer {
              0% { height: 10%; }
              100% { height: 95%; }
            }
            .animate-alert-move {
              animation: slideAlertStripes 5s linear infinite;
            }
            @keyframes slideAlertStripes {
              0% { background-position: 0px 0; }
              100% { background-position: 120px 0; }
            }
          `}</style>
        </div>
      )}

      {/* Main Header navigation and status controls */}
      <Header
        learnerName="DOCTOR"
        isDebugMode={isDebugMode}
        onToggleDebug={() => setIsDebugMode(!isDebugMode)}
        onOpenSettings={() => {
          setConfirmDialog({
            isOpen: true,
            title: 'PURGE COGNITIVE DATA // 抹除戰術認知存檔',
            message: '確定要初始化重置所有戰術學習統計數據與錯誤記錄嗎？此操作將永久抹除神經網絡同步數據，本操作不可逆。',
            onConfirm: () => {
              handleResetTelemetry();
              setConfirmDialog(p => ({ ...p, isOpen: false }));
            }
          });
        }}
        activeTab={activeTab}
        currentUser={currentUser}
        onLogout={handleLogout}
        activeFrame={progress.activeFrame || 'CLASSIC'}
        onClickAvatar={() => {
          // Play micro sound / alert feedback or just change active tab
          setActiveTab('PROFILE');
        }}
      />

      {/* Content wrapper */}
      <main className="flex-grow pt-24 pb-32 px-4 sm:px-6 z-10 w-full max-w-7xl mx-auto">
        
        {isQuizActive ? (
          // Quiz runner interface
          <Quiz
            currentWord={quizWords[currentQuizIndex]}
            currentIndex={currentQuizIndex}
            totalWords={quizWords.length}
            onNext={handleAnswerSubmit}
            consecutiveCorrect={consecutiveCorrect}
            sessionEarnedOrundum={sessionEarnedOrundum}
            sessionCorrectCount={sessionCorrectCount}
          />
        ) : (
          // Navigation Tab dispatcher
          <div className="animate-fade-in transition-all duration-300">
            {activeTab === 'DASHBOARD' && (
              <Dashboard
                currentLevel={currentLevel}
                onSelectLevel={setCurrentLevel}
                quizLength={quizLength}
                onSelectLength={setQuizLength}
                progress={progress}
                onInitialize={handleInitializeOperation}
                wordsTotalInLevel={wordsInLevel.length}
                wordsMasteredInLevel={completedWordsInLevel}
                quizMode={quizMode}
                onSelectMode={setQuizMode}
              />
            )}

            {activeTab === 'INTEL' && (
              <Intel
                progress={progress}
                currentLevel={currentLevel}
              />
            )}

            {activeTab === 'ARCHIVES' && (
              <Archives
                words={VOCABULARY_DATABASE}
                progress={progress}
                onReviewWord={handleLaunchSingleWordQuiz}
              />
            )}

            {activeTab === 'SHOP' && (
              <Shop
                progress={progress}
                onUpdateProgress={saveProgress}
              />
            )}

            {activeTab === 'LEADERBOARD' && (
              <Leaderboard
                progress={progress}
                currentUser={currentUser}
                onStartChallenge={handleStartChallenge}
              />
            )}

            {activeTab === 'PROFILE' && (
              <Profile
                progress={progress}
                currentUser={currentUser || 'DOCTOR'}
                onUpdateProgress={saveProgress}
                onNavigateToShop={() => setActiveTab('SHOP')}
              />
            )}

            {activeTab === 'CUSTOM' && (
              <CustomStudy
                onNotifyToast={(text, isCorrect) => {
                  setToastMessage({ text, isCorrect });
                  setTimeout(() => setToastMessage(null), 3500);
                }}
              />
            )}
          </div>
        )}
      </main>

      {/* Bottom Floating Toast diagnostics feedback alert */}
      {toastMessage && (
        <div 
          className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-[#201f1f] border px-8 py-4 sm:min-w-[400px] flex items-center gap-4 animate-pulse z-[60] font-mono border-l-4"
          style={{
            borderColor: 'var(--theme-color, #00e0b3)',
            boxShadow: '0 0 35px var(--theme-color-glow, rgba(0,224,179,0.25))'
          }}
        >
          <div 
            className="w-1 h-8" 
            style={{ backgroundColor: toastMessage.isCorrect ? 'var(--theme-color, #00e0b3)' : '#ff9800' }}
          />
          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: 'var(--theme-color, #00e0b3)' }}>SYSTEM_FEEDBACK</span>
            <span className="text-sm font-bold text-white tracking-wider uppercase font-mono mt-0.5">
              {toastMessage.text}
            </span>
          </div>
        </div>
      )}

      {/* Interactive Floating Debug Log panel if enabled */}
      {isDebugMode && (
        <div 
          className="fixed bottom-20 left-4 right-4 md:left-auto md:right-8 md:w-96 bg-[#0e0e0e]/95 border-2 text-xs font-mono font-bold p-4 p-b-2 shadow-2xl z-[70] transition-all space-y-2"
          style={{
            borderColor: 'var(--theme-color, #00e0b3)',
            color: 'var(--theme-color, #00e0b3)'
          }}
        >
          <div className="flex justify-between items-center border-b pb-1.5 mb-1" style={{ borderBottomColor: 'var(--theme-color-bg)' }}>
            <span className="tracking-widest flex items-center gap-2">
              <Terminal className="w-4 h-4 animate-pulse" style={{ color: 'var(--theme-color, #00e0b3)' }} />
              PRTS_DEBUG_CONSOLE_v1
            </span>
            <button onClick={() => setIsDebugMode(false)} className="hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="max-h-40 overflow-y-auto space-y-1 text-[10px] text-[#b9cbc2]/80 uppercase no-scrollbar">
            <p className="text-[#ff9800]">&gt; [ALERT] EXECUTING PERSISTENT TELEMETRY CHECKS...</p>
            <p>&gt; CURRENT_STREAK: {progress.currentStreak} CONCURRENT RUNS</p>
            <p>&gt; COMBAT_EFFICIENCY: {progress.combatEfficiency}% RATIO</p>
            <p>&gt; BUFFERED_MISSED_WORDS: {JSON.stringify(progress.missedWords)}</p>
            <p>&gt; SECTOR_TARGET_LOAD: {currentLevel} MODULE</p>
            <p>&gt; DECISION_GATEWAY: LOCAL_STORAGE_STANDBY</p>
            <p>&gt; COGNITIVE ENGINES OPERATIONAL</p>
          </div>

          <button
            onClick={handleResetTelemetry}
            className="w-full text-center mt-2 bg-[#93000a]/15 text-[#ffb4ab] border border-[#ffb4ab]/30 hover:bg-[#93000a] hover:text-white py-1 uppercase text-[9px] transition-all"
          >
            FORCE_RESET_DATABASE_VALUES()
          </button>
        </div>
      )}

      {/* Bottom Fixed Navigation bar (Mobile and Small desktop) */}
      {!isQuizActive && (
        <nav className="fixed bottom-0 left-0 right-0 z-50 flex justify-around items-center bg-[#0e0e0e] h-16 pb-safe border-t border-[#3a4a44]/80 shadow-2xl">
          {/* DASHBOARD TAB button */}
          <button
            onClick={() => setActiveTab('DASHBOARD')}
            className={`flex-1 h-full flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeTab === 'DASHBOARD'
                ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] text-[var(--theme-color,#00e0b3)] border-t-2 border-[var(--theme-color,#00e0b3)]'
                : 'text-[#b9cbc2]/70 hover:text-white'
            }`}
          >
            <BookOpen className="w-5 h-5 animate-pulse" />
            <span className="font-mono text-[9px] font-bold mt-1 tracking-widest uppercase">DASHBOARD // 控制面板</span>
          </button>

          {/* INTEL TAB button */}
          <button
            onClick={() => setActiveTab('INTEL')}
            className={`flex-1 h-full flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeTab === 'INTEL'
                ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] text-[var(--theme-color,#00e0b3)] border-t-2 border-[var(--theme-color,#00e0b3)]'
                : 'text-[#b9cbc2]/70 hover:text-white'
            }`}
          >
            <Shield className="w-5 h-5 focus:outline-none" />
            <span className="font-mono text-[9px] font-bold mt-1 tracking-widest uppercase">INTEL // 學習分析</span>
          </button>

          {/* ARCHIVES TAB button */}
          <button
            onClick={() => setActiveTab('ARCHIVES')}
            className={`flex-1 h-full flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeTab === 'ARCHIVES'
                ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] text-[var(--theme-color,#00e0b3)] border-t-2 border-[var(--theme-color,#00e0b3)]'
                : 'text-[#b9cbc2]/70 hover:text-white'
            }`}
          >
            <BarChart2 className="w-5 h-5" />
            <span className="font-mono text-[9px] font-bold mt-1 tracking-widest uppercase">ARCHIVES // 核心存檔</span>
          </button>

          {/* CUSTOM TAB button */}
          <button
            onClick={() => setActiveTab('CUSTOM')}
            className={`flex-1 h-full flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeTab === 'CUSTOM'
                ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] text-[var(--theme-color,#00e0b3)] border-t-2 border-[var(--theme-color,#00e0b3)]'
                : 'text-[#b9cbc2]/70 hover:text-white'
            }`}
          >
            <Layers className="w-5 h-5 focus:outline-none" />
            <span className="font-mono text-[9px] font-bold mt-1 tracking-widest uppercase">CUSTOM // 自訂學習</span>
          </button>

          {/* SHOP TAB button */}
          <button
            onClick={() => setActiveTab('SHOP')}
            className={`flex-1 h-full flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeTab === 'SHOP'
                ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] text-[var(--theme-color,#00e0b3)] border-t-2 border-[var(--theme-color,#00e0b3)]'
                : 'text-[#b9cbc2]/70 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-5 h-5 animate-pulse" />
            <span className="font-mono text-[9px] font-bold mt-1 tracking-widest uppercase">SHOP // 採購中心</span>
          </button>

          {/* LEADERBOARD TAB button */}
          <button
            onClick={() => setActiveTab('LEADERBOARD')}
            className={`flex-1 h-full flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeTab === 'LEADERBOARD'
                ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] text-[var(--theme-color,#00e0b3)] border-t-2 border-[var(--theme-color,#00e0b3)]'
                : 'text-[#b9cbc2]/70 hover:text-white'
            }`}
          >
            <Trophy className="w-5 h-5" />
            <span className="font-mono text-[9px] font-bold mt-1 tracking-widest uppercase truncate max-w-[80px]">LEADERBOARD</span>
          </button>

          {/* PROFILE TAB button */}
          <button
            onClick={() => setActiveTab('PROFILE')}
            className={`flex-1 h-full flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeTab === 'PROFILE'
                ? 'bg-[var(--theme-color-bg,rgba(0,224,179,0.05))] text-[var(--theme-color,#00e0b3)] border-t-2 border-[var(--theme-color,#00e0b3)]'
                : 'text-[#b9cbc2]/70 hover:text-white'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="font-mono text-[9px] font-bold mt-1 tracking-widest uppercase truncate max-w-[80px]">PROFILE</span>
          </button>
        </nav>
      )}

      {/* Decorative Lateral status details representing crt indicators */}
      <div className="fixed top-24 right-4 z-0 opacity-10 pointer-events-none hidden lg:block font-mono text-[9px] text-[#00e0b3] space-y-1">
        <p>SYSTEM_LOAD: 42% ONLINE</p>
        <p>MEM_BUFFERST_STABLE: OK</p>
        <p>ENCRYPTION: AES_ACTIVE</p>
        <p>DEVICES: OPERATOR_READY</p>
      </div>
      
      <div className="fixed bottom-20 left-4 z-0 opacity-10 pointer-events-none hidden lg:block font-mono text-[8px] space-y-0.5 text-[#b9cbc2]">
        <p>LAT: 40.7128 N</p>
        <p>LONG: 74.0060 W</p>
        <p>ZONE: RHODES_ISLAND_03</p>
        <p>BITRATE: 4.8 GBPS_FLOW</p>
      </div>

      {/* Custom Tactical Confirmation Dialog Overlay */}
      {confirmDialog.isOpen && (
        <div className="fixed inset-0 bg-black/85 flex items-center justify-center p-4 z-[9999] backdrop-blur-sm font-mono animate-fade-in">
          <div className="relative w-full max-w-md bg-[#131313] border border-[#3a4a44] border-t-4 border-t-[#00e0b3] p-5 sm:p-6 shadow-[0_0_50px_rgba(0,224,179,0.15)] animate-in fade-in zoom-in-95 duration-150">
            
            {/* Top high-tech decoration bar */}
            <div className="flex justify-between items-center pb-3 border-b border-[#3a4a44]/50 mb-4">
              <span className="text-xs font-bold text-[#00e0b3] tracking-widest flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-[#ffb4ab]" />
                {confirmDialog.title || 'SYSTEM PROTOCOL ACTION'}
              </span>
              <button 
                onClick={() => setConfirmDialog(p => ({ ...p, isOpen: false }))}
                className="text-[#b9cbc2]/40 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content text */}
            <div className="text-xs text-[#e5e2e1] leading-relaxed mb-6 whitespace-pre-line">
              <p>{confirmDialog.message}</p>
            </div>

            {/* Actions block */}
            <div className="flex justify-end gap-3 font-mono text-[11px] tracking-wider">
              <button
                onClick={() => setConfirmDialog(p => ({ ...p, isOpen: false }))}
                className="px-4 py-2 border border-[#3a4a44] text-[#b9cbc2] hover:bg-[#1c221f] transition-all cursor-pointer rounded"
              >
                ABORT // 取消
              </button>
              <button
                onClick={confirmDialog.onConfirm}
                className="px-4 py-2 bg-[#93000a] text-white border border-[#ffb4ab]/30 hover:bg-[#b3141f] shadow-[0_0_15px_rgba(147,0,10,0.3)] transition-all cursor-pointer font-bold rounded"
              >
                CONFIRM_ACTION // 確認安全操作
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
