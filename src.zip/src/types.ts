export type WordLevel = 'BASIC' | 'INTERMEDIATE' | 'TOEIC' | 'TOEFL';

export interface VocabularyWord {
  id: string;
  word: string;
  meaning: string;
  level: WordLevel;
  sentence: string;
  sentenceChinese: string;
  choices: string[];
  correctAnswer: string; // must be uppercase, matching choices
  explanation: string;
  explanationChinese: string;
  decryptSig: string;
  refId: string;
  bonusCase: string;
  bonusCaseChinese: string;
  contextValue: number; // percentage (e.g. 66 for Context_Matrix)
  systemLoadValue: number; // percentage (e.g. 25 for System_Load)
}

export interface UserProgress {
  completedWordIds: string[]; // words answered in latest batch
  missedWords: { [wordId: string]: number }; // wordId -> missed count
  lastSyncTimes: { [wordId: string]: string }; // wordId -> custom display time (e.g. "12H_AGO")
  currentStreak: number;
  combatEfficiency: number; // percentage (e.g. 80)
  reEducationCount: number; // count of missed words
  totalAttempts: number;
  correctAttempts: number;
  orundum?: number; // 合成玉 Currency
  lastLoginDate?: string | null; // Last login timestamp string (YYYY-MM-DD) for daily bonus
  ownedSkins?: string[]; // IDs of owned UI skins
  activeSkin?: string; // ID of active UI skin
  ownedSouvenirs?: string[]; // IDs of owned commemorative souvenirs
  ownedFrames?: string[]; // IDs of owned avatar frames
  activeFrame?: string; // ID of active avatar frame
  ownedAvatars?: string[]; // IDs of owned custom avatars
  activeAvatar?: string; // ID of active custom avatar
  points?: number; // Tactical Cognitive Points (戰術認知積分)
  unlockedBadges?: string[]; // IDs of unlocked badges (解鎖徽章集)
  hasInitializedDeveloperOrundum?: boolean;
}

export interface CustomFlashcard {
  id: string;
  english: string;     // English side (英文面)
  translation: string; // Translation side (翻譯面)
  createdAt: number;
}

