const fs = require('fs');
const path = require('path');
const vm = require('vm');

function extractArray(filePath, varName) {
  let text = fs.readFileSync(filePath, 'utf8');
  text = text.replace(/import\s+[^;]+;\s*/g, '');
  text = text.replace(/export\s+const\s+([A-Za-z0-9_]+)\s*:\s*[^=]+=\s*/, 'const $1 = ');
  const match = text.match(new RegExp('const\\s+' + varName + '\\s*=\\s*(\[?[\s\S]*?\]);', 'm'));
  if (!match) throw new Error('Array not found: ' + varName);
  const code = match[0] + '\nmodule.exports = ' + varName + ';';
  const script = new vm.Script(code, { filename: filePath });
  const context = vm.createContext({ module: {}, exports: {} });
  script.runInContext(context);
  return context.module.exports;
}

function csvSafe(value) {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (str.includes('"') || str.includes(',') || str.includes('\n') || str.includes('\r')) {
    return '"' + str.replace(/"/g, '""') + '"';
  }
  return str;
}

function writeCsv(rows, headers, output) {
  const out = [headers.join(',')].concat(rows.map(row => headers.map(h => csvSafe(row[h] === undefined ? '' : row[h])).join(','))).join('\n');
  fs.writeFileSync(output, out, 'utf8');
}

function buildRow(item) {
  const row = { ...item };
  row.choices = JSON.stringify(item.choices || []);
  return row;
}

const vocab = extractArray(path.join(process.cwd(), 'src/data.ts'), 'VOCABULARY_DATABASE');
const sentence = extractArray(path.join(process.cwd(), 'src/sentenceData.ts'), 'SENTENCE_STRUCTURE_DATABASE');

const headers = ['id','word','meaning','level','sentence','sentenceChinese','choices','correctAnswer','explanation','explanationChinese','decryptSig','refId','bonusCase','bonusCaseChinese','contextValue','systemLoadValue'];

if (!fs.existsSync(path.join(process.cwd(), 'data'))) {
  fs.mkdirSync(path.join(process.cwd(), 'data'));
}

writeCsv(vocab.map(buildRow), headers, path.join(process.cwd(), 'data', 'vocabulary.csv'));
writeCsv(sentence.map(buildRow), headers, path.join(process.cwd(), 'data', 'sentence_structure.csv'));

console.log('wrote csv files', path.join(process.cwd(), 'data', 'vocabulary.csv'), path.join(process.cwd(), 'data', 'sentence_structure.csv'));
