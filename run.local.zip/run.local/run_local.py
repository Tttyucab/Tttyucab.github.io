#!/usr/bin/env python3
"""Run the Lexiquiz application locally and open http://localhost:3000 in the browser."""

import os
import shutil
import subprocess
import sys
import time
import webbrowser
from urllib.error import URLError
from urllib.request import urlopen

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
URL = "http://localhost:3000"
NPM_CMD = "npm.cmd" if os.name == "nt" else "npm"


def wait_for_server(url: str, timeout: int = 60) -> bool:
    start = time.time()
    while time.time() - start < timeout:
        try:
            with urlopen(url, timeout=5) as response:
                if response.status == 200:
                    return True
        except (URLError, OSError):
            pass
        time.sleep(1)
    return False


def main() -> int:
    print(f"Project path: {PROJECT_ROOT}")

    if not os.path.exists(os.path.join(PROJECT_ROOT, "package.json")):
        print("Error: package.json not found. Please run this script from the lexiquiz project folder.")
        return 1

    if shutil.which(NPM_CMD) is None:
        print(f"Error: '{NPM_CMD}' not found. Please install Node.js and npm first.")
        return 1

    if not os.path.isdir(os.path.join(PROJECT_ROOT, "node_modules")):
        print("Warning: node_modules folder is missing. Run 'npm install' before starting." )

    print("Starting development server...")
    try:
        proc = subprocess.Popen([NPM_CMD, "run", "dev"], cwd=PROJECT_ROOT)
    except Exception as exc:
        print(f"Failed to start npm dev server: {exc}")
        return 1

    try:
        if wait_for_server(URL, timeout=60):
            print(f"Server is available at {URL}")
            webbrowser.open(URL)
            print("Press Ctrl+C to stop the server.")
            proc.wait()
            return proc.returncode or 0
        print("Server did not start within 60 seconds.")
        return 1
    except KeyboardInterrupt:
        print("Shutting down server...")
        proc.terminate()
        proc.wait()
        return 0
    finally:
        if proc.poll() is None:
            proc.terminate()


if __name__ == "__main__":
    sys.exit(main())
